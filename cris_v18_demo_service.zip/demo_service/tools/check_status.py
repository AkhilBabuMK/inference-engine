# -*- coding: utf-8 -*-
"""
deploy/demo_service/tools/check_status.py -- READ-ONLY look at the bookkeeping in Redis (spec v3 sections 3, 6).

    python tools/check_status.py [REDIS_URL] [N_ROWS]

Shows: the newest batch, who listens on the wake-up channel, every model's row (state, last finished, last seen),
the last N status rows per model, and which batches are still waiting. Writes nothing.
"""
import sys
import redis

url = sys.argv[1] if len(sys.argv) > 1 else "redis://10.2.8.7:6379/0"
N = int(sys.argv[2]) if len(sys.argv) > 2 else 10
r = redis.Redis.from_url(url, decode_responses=True, socket_connect_timeout=10)
now = int(r.time()[0])

st = r.hgetall("irpilot:feed:status")
latest = int(st["batch_no"]) if st.get("batch_no") else 0
age = now - int(st["written_at"]) if st.get("written_at") else None
print(f"newest batch: {latest}  data_as_of {st.get('data_as_of')}  written {age} s ago")
print(f"listening on irpilot:trigger right now: {r.pubsub_numsub('irpilot:trigger')[0][1]} connection(s)")
models = sorted(r.smembers("irpilot:models"))
print(f"models that have started: {models or 'none yet'}\n")

for m in models:
    row = r.hgetall(f"irpilot:model:{m}")
    seen = now - int(row.get("last_seen", 0) or 0)
    last = int(row.get("last_finished") or 0)
    print(f"== {m}  version {row.get('version')}  on {row.get('host')}  enabled {row.get('enabled')}")
    print(f"   state {row.get('state')}  working on {row.get('batch_no') or '-'}  last finished {last} "
          f"({row.get('last_finished_status')})  last seen {seen} s ago{'  <-- DOWN?' if seen > 180 else ''}")
    waiting = [b for b in range(last + 1, latest + 1) if r.exists(f"irpilot:feed:batch:{b}")]
    print(f"   waiting batches: {waiting if waiting else 'none'}")
    print(f"   {'batch':>6}  {'status':11}  {'reason':32}  {'took':>6}  {'pax':>4}  output")
    for b in range(latest, max(0, latest - N), -1):
        s = r.hgetall(f"irpilot:status:{m}:{b}")
        if not s:
            print(f"   {b:>6}  (no row)")
            continue
        took = (int(s['finished_at']) - int(s['started_at'])) if s.get('finished_at') and s.get('started_at') else ''
        print(f"   {b:>6}  {s.get('status',''):11}  {s.get('reason','')[:32]:32}  {str(took):>6}  "
              f"{s.get('pax_read',''):>4}  {s.get('output_ref','')}")
    print()
