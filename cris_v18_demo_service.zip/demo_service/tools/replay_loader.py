# -*- coding: utf-8 -*-
"""
deploy/demo_service/tools/replay_loader.py -- a reference loader for the database team's side of
REDIS_API_SPEC_cris-v18.md (version 3, section 4): replays golden September records into a Redis as batches.

    python tools/replay_loader.py REDIS_URL GOLDEN_DIR START END STEP_MIN [SECONDS_BETWEEN]
      e.g. redis://localhost:6379/0 golden 2025-09-26T09:00 2025-09-26T12:00 5 60

Each batch (simulated moment D):
  * a record exists from its origin departure, or 6 h before its first corridor station, whichever is earlier;
  * it shows only what had happened by D (real times after D, or reported after D, are null);
  * it is removed in the first batch after 00:00 two days after the day it left the corridor;
  * one MULTI/EXEC: changed records + change table, removals, batch-log row (7-day expiry), feed:status;
    batch_no = newest + 1 under WATCH; then PUBLISH irpilot:trigger.
Goods and the reference lists are not replayed here (the demo model uses its own September copies).
"""
from __future__ import annotations

import copy
import json
import sys
import time
from pathlib import Path

import pandas as pd

TZ = "+05:30"


def _t(v):
    if v is None:
        return None
    t = pd.Timestamp(v)
    return t.tz_convert("Asia/Kolkata").tz_localize(None) if t.tzinfo is not None else t


def _iso(t):
    return None if t is None else pd.Timestamp(t).isoformat() + TZ


class Loader:
    def __init__(self, r, golden: Path, use_reported: bool = True):
        self.r, self.use_reported = r, use_reported
        self.full = [json.loads(f.read_text(encoding="utf-8")) for f in sorted(Path(golden).glob("*.json"))]
        self.last = {}                                  # run_id -> masked JSON last written (to find changes)

    @staticmethod
    def times(rec):
        corr = [s for s in rec["stops"] if s["on_corridor"]]
        sched = [_t(s["scheduled_arrival_time"] or s["scheduled_departure_time"]) for s in corr]
        origin = _t(rec["stops"][0]["scheduled_departure_time"] or rec["stops"][0]["scheduled_arrival_time"])
        first_corr = min(x for x in sched if x is not None)
        return origin, first_corr

    @staticmethod
    def mask(rec, D, use_reported=True):
        m = copy.deepcopy(rec)
        for s in m["stops"]:
            rep = _t(s.get("reported_at"))
            late = use_reported and rep is not None and rep > D
            had_dep = s.get("actual_departure_time") is not None
            # reported_at dates the row's LATEST event (departure if any, else arrival)
            if had_dep and (_t(s["actual_departure_time"]) > D or late):
                s["actual_departure_time"], s["departure_delay_min"] = None, None
            arr = _t(s.get("actual_arrival_time"))
            if arr is not None and (arr > D or (late and not had_dep)):
                s["actual_arrival_time"], s["arrival_delay_min"] = None, None
            if rep is not None and rep > D:
                s["reported_at"] = None
        first = next(i for i, s in enumerate(m["stops"]) if s["on_corridor"])
        obs = [s for s in m["stops"][:first] if s["arrival_delay_min"] is not None]
        dl = [s["arrival_delay_min"] for s in obs]
        m["upstream"] = {"has_upstream": bool(obs), "stops_observed": len(obs), "entry_delay_min": dl[-1] if dl else 0.0,
                         "entry_trend_min": round(dl[-1] - dl[max(0, len(dl) - 4)], 2) if dl else 0.0,
                         "last_report_station": obs[-1]["station_code"] if obs else None,
                         "last_report_time": obs[-1]["actual_arrival_time"] if obs else None}
        corr = [s for s in m["stops"] if s["on_corridor"]]
        corr_act = [_t(s["actual_arrival_time"] or s["actual_departure_time"]) for s in corr
                    if s["actual_arrival_time"] or s["actual_departure_time"]]
        m["corridor_date"] = (corr_act[0] if corr_act else Loader.times(rec)[1]).strftime("%Y-%m-%d")
        last_stop = [s for s in corr if not s["block_post"]][-1]
        left_at = max(corr_act) if corr_act and (last_stop["actual_arrival_time"] or last_stop["actual_departure_time"]) \
            else None
        return m, left_at

    def write(self, D: pd.Timestamp) -> int:
        r = self.r
        changed, removed, live = {}, [], set()
        for rec in self.full:
            origin, first_corr = self.times(rec)
            if D < min(origin or first_corr, first_corr - pd.Timedelta(hours=6)):
                continue                                  # not created yet
            m, left_at = self.mask(rec, D, self.use_reported)
            if left_at is not None and D >= pd.Timestamp(left_at.date()) + pd.Timedelta(days=2):
                if rec["run_id"] in self.last:
                    removed.append(rec["run_id"])
                continue
            live.add(rec["run_id"])
            key = json.dumps({k: v for k, v in m.items() if k not in ("batch_no", "updated_at")}, sort_keys=True)
            if self.last.get(rec["run_id"]) != key:
                changed[rec["run_id"]] = (m, key)
        with r.pipeline(transaction=True) as p:
            while True:
                try:
                    p.watch("irpilot:feed:status")
                    n = int(p.hget("irpilot:feed:status", "batch_no") or 0) + 1
                    now = int(p.time()[0])
                    p.multi()
                    for rid, (m, _) in changed.items():
                        m["batch_no"], m["updated_at"] = n, _iso(D)
                        p.set(f"irpilot:pax:run:{rid}", json.dumps(m))
                        p.zadd("irpilot:pax:changed", {rid: n})
                    for rid in removed:
                        p.delete(f"irpilot:pax:run:{rid}")
                        p.zrem("irpilot:pax:changed", rid)
                    p.hset(f"irpilot:feed:batch:{n}", mapping={
                        "batch_no": n, "data_as_of": _iso(D), "written_at": now, "pax_runs": len(live),
                        "goods_runs": 0, "pax_changed": len(changed), "goods_changed": 0, "removed": len(removed),
                        "refs_changed": "", "schema_version": "input-guide-5"})
                    p.expire(f"irpilot:feed:batch:{n}", 604800)
                    p.hset("irpilot:feed:status", mapping={"batch_no": n, "data_as_of": _iso(D), "written_at": now})
                    p.execute()
                    break
                except Exception as e:                    # WatchError: another writer -> stop (spec 4.1)
                    if type(e).__name__ == "WatchError":
                        raise SystemExit("second loader detected (WATCH); stopping")
                    raise
        for rid, (_, key) in changed.items():
            self.last[rid] = key
        for rid in removed:
            self.last.pop(rid, None)
        r.publish("irpilot:trigger", n)
        return n


def main():
    import redis
    url, golden, start, end, step = sys.argv[1:6]
    pause = float(sys.argv[6]) if len(sys.argv) > 6 else 0.0
    r = redis.Redis.from_url(url, decode_responses=True)
    L = Loader(r, Path(golden))
    D, E = pd.Timestamp(start), pd.Timestamp(end)
    while D <= E:
        n = L.write(D)
        print(f"batch {n}: data as of {D}", flush=True)
        D += pd.Timedelta(minutes=int(step))
        if pause:
            time.sleep(pause)


if __name__ == "__main__":
    main()
