# -*- coding: utf-8 -*-
"""
deploy/demo_service/tools/build_from_september.py

Builds, from v18's OWN September source (cris_pipeline.v14.sources.load_running_v14 = old CRIS export upstream +
ground truth on the corridor; reads the production folder's data read-only), two things the demo service needs:

    python tools/build_from_september.py habits
        -> tables/entry_habits.json : the entry rule's "usual change on the way in" (F1 rule R2), TRAINING DAYS ONLY
           (corridor date <= 2025-09-20). Same code as research_notes/entry_estimate_2026-11/f2_live_entry.py
           build_runs + habits (copied below, unchanged logic).

    python tools/build_from_september.py records FROM TO OUT_DIR
        -> one Redis-format record per run (input guide version 5, section 4) for every v18 run whose corridor date is
           in FROM..TO, with ALL real times filled (a replay loader hides the future). These are the golden records:
           what the database team's records should look like for the same runs (September match check), and the input
           of the local end-to-end test.

Run from jabalpur_scenario_gnn_v14/ (the worktree; its cris_pipeline equals tag cris-v18 for these files).
"""
from __future__ import annotations

import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
SERVICE = HERE.parent
WORKTREE = SERVICE.parents[1]
sys.path.insert(0, str(WORKTREE))

from cris_pipeline.config import CORRIDOR, CORRIDOR_ORDER, BLOCK_POSTS  # noqa: E402
from cris_pipeline.v14 import settings as S  # noqa: E402

TRAIN_LAST = "2025-09-20"
TZ = "+05:30"


def load():
    from cris_pipeline.v14.sources import load_running_v14
    from cris_pipeline.build_journeys import load_side_tables
    df = load_running_v14(verbose=False)
    df["record_update_timestamp"] = pd.to_datetime(df.record_update_timestamp, errors="coerce")
    coaches, _ = load_side_tables()
    return df, coaches


def journey_index(journeys: Path) -> list:
    """(train_no, journey_date, corridor_date, file) for every v18 journey file."""
    out = []
    for f in sorted(journeys.glob("*/*.json")):
        r = json.loads(f.read_text(encoding="utf-8"))
        if r.get("stops"):
            out.append((r["train_no"], r["journey_date"], r["corridor_date"], f))
    return out


# ── habits: copied from f2_live_entry.build_runs / habits (logic unchanged) ──────────────────────────────────────────

def build_runs(df: pd.DataFrame, journeys: Path) -> dict:
    groups = {k: g for k, g in df.groupby(["train_no", "train_date"], sort=False)}
    runs = {}
    for tn, jd, cd, f in journey_index(journeys):
        r = json.loads(f.read_text(encoding="utf-8"))
        g = groups.get((tn, jd))
        if g is None:
            continue
        in_corr = g.station_code.isin(CORRIDOR).to_numpy()
        if not in_corr.any():
            continue
        prefix = g.iloc[:int(np.argmax(in_corr))].copy()
        s0 = r["stops"][0]
        sch = s0["sched_arr_min"] if s0.get("sched_arr_min") is not None else s0.get("sched_dep_min")
        a = s0["actual_arr_min"] if s0.get("actual_arr_min") is not None else s0.get("actual_dep_min")
        up = prefix.copy()
        up["ev"] = up.actual_departure_time.fillna(up.actual_arrival_time)
        up["sch"] = pd.to_datetime(np.where(up.actual_departure_time.notna(), up.scheduled_departure_time,
                                            up.scheduled_arrival_time))
        up["delay"] = (up.ev - up.sch).dt.total_seconds() / 60
        up = up[up.ev.notna() & up.sch.notna()]
        runs[f"{f.parent.name}/{f.stem}"] = {
            "train": tn, "cdate": cd,
            "real_delay": (float(a) - float(sch)) if (a is not None and sch is not None) else None,
            "up": up[["station_code", "delay"]].reset_index(drop=True)}
    return runs


def habits(runs: dict):
    chg, chg_st = defaultdict(list), defaultdict(list)
    for r in runs.values():
        if r["cdate"] > TRAIN_LAST or r["real_delay"] is None:
            continue
        for x in r["up"].itertuples():
            chg[(r["train"], x.station_code)].append(r["real_delay"] - x.delay)
            chg_st[x.station_code].append(r["real_delay"] - x.delay)
    return ({k: float(np.mean(v)) for k, v in chg.items()},
            {k: float(np.mean(v)) for k, v in chg_st.items() if len(v) >= 5})


def cmd_habits() -> None:
    df, _ = load()
    runs = build_runs(df, Path(S.JOURNEYS_DIR))
    h, hs = habits(runs)
    out = {"what": "entry rule R2: usual change in delay from an upstream station to corridor entry",
           "built_from": "cris_pipeline.v14.sources.load_running_v14 + v18 journey files (data_v14/journeys)",
           "training_days_only": f"corridor_date <= {TRAIN_LAST}",
           "same_as": "research_notes/entry_estimate_2026-11/f2_live_entry.py habits() (F2, 2026-11-19)",
           "by_train_station": {f"{t}|{s}": round(v, 4) for (t, s), v in sorted(h.items(), key=lambda kv: str(kv[0]))},
           "by_station": {s: round(v, 4) for s, v in sorted(hs.items(), key=lambda kv: str(kv[0]))}}
    p = SERVICE / "tables" / "entry_habits.json"
    p.write_text(json.dumps(out, indent=0), encoding="utf-8")
    print(f"wrote {p}: {len(h):,} train-station values, {len(hs):,} station values from {len(runs):,} runs")


# ── golden records ────────────────────────────────────────────────────────────────────────────────────────────────

def _iso(ts):
    if ts is None or pd.isna(ts):
        return None
    return pd.Timestamp(ts).isoformat() + TZ


def _num(v, nd=2):
    return None if v is None or pd.isna(v) else round(float(v), nd)


def make_record(g: pd.DataFrame, coaches: dict, corridor_date: str) -> dict:
    """One run as the database team would write it (input guide v5, section 4), all real times filled."""
    g = g.sort_values("serial_number")
    tn, jd = g.train_no.iloc[0], str(g.train_date.iloc[0])
    corr_idx = [CORRIDOR_ORDER.index(c) for c in g.station_code if c in CORRIDOR]
    stops = []
    for r in g.itertuples():
        code = str(r.station_code)
        rut = getattr(r, "record_update_timestamp", None)
        stops.append({
            "serial_number": int(r.serial_number), "station_code": code,
            "on_corridor": code in CORRIDOR, "block_post": code in BLOCK_POSTS,
            "scheduled_arrival_time": _iso(r.scheduled_arrival_time),
            "scheduled_departure_time": _iso(r.scheduled_departure_time),
            "actual_arrival_time": _iso(r.actual_arrival_time),
            "actual_departure_time": _iso(r.actual_departure_time),
            "arrival_delay_min": _num(r.arr_delay), "departure_delay_min": _num(r.dep_delay),
            # raw flag kept as the source wrote it (1 / 0 / null), so the September match check can see it exactly
            "booked_halt": None if pd.isna(r.wtt_stop_flag) else bool(r.wtt_stop_flag),
            "allowance_min": round(((0.0 if pd.isna(r.traffic_allowance_seconds) else float(r.traffic_allowance_seconds))
                                    + (0.0 if pd.isna(r.engineering_allowance_seconds) else
                                       float(r.engineering_allowance_seconds))) / 60.0, 2),
            "reported_at": _iso(rut),
        })
    first = next(i for i, s in enumerate(stops) if s["on_corridor"])
    obs = [s for s in stops[:first] if s["arrival_delay_min"] is not None]
    d = [s["arrival_delay_min"] for s in obs]
    return {
        "run_id": f"{tn}:{jd}", "train_number": tn, "train_date": jd, "train_type": str(g.train_type.iloc[0]),
        "direction": "DN" if corr_idx and corr_idx[-1] > corr_idx[0] else "UP",
        "number_of_coaches": coaches.get(tn), "corridor_date": corridor_date,
        "upstream": {"has_upstream": bool(obs), "stops_observed": len(obs),
                     "entry_delay_min": d[-1] if d else 0.0,
                     "entry_trend_min": round(d[-1] - d[max(0, len(d) - 4)], 2) if d else 0.0,
                     "last_report_station": obs[-1]["station_code"] if obs else None,
                     "last_report_time": obs[-1]["actual_arrival_time"] if obs else None},
        "quality": {"implausible_jump": None},
        "batch_no": 0, "updated_at": None,
        "stops": stops,
    }


def cmd_records(d_from: str, d_to: str, out_dir: str) -> None:
    df, coaches = load()
    groups = {k: g for k, g in df.groupby(["train_no", "train_date"], sort=False)}
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    n = 0
    for tn, jd, cd, f in journey_index(Path(S.JOURNEYS_DIR)):
        if not (d_from <= cd <= d_to):
            continue
        g = groups.get((tn, jd))
        if g is None:
            continue
        rec = make_record(g, coaches, cd)
        (out / f"{tn}_{jd}.json").write_text(json.dumps(rec), encoding="utf-8")
        n += 1
    print(f"wrote {n:,} records (corridor dates {d_from}..{d_to}) to {out}")


def cmd_coaches() -> None:
    """tables/coaches.json: the coach table v18 was trained with (build_journeys.load_side_tables, the CRIS
    no_of_coaches_data.csv), train number (5 characters) -> coaches. The builder used coaches.get(train_no, 0)."""
    from cris_pipeline.build_journeys import load_side_tables
    from cris_pipeline.config import COACHES_CSV
    coaches, _ = load_side_tables()
    out = {"what": "number of coaches per train number, as used to build the v18 journey files",
           "source": str(COACHES_CSV.name), "missing_train": "0 (as in training)",
           "coaches": {k: int(v) for k, v in sorted(coaches.items())}}
    p = SERVICE / "tables" / "coaches.json"
    p.write_text(json.dumps(out, indent=0), encoding="utf-8")
    print(f"wrote {p}: {len(coaches):,} trains")


if __name__ == "__main__":
    if sys.argv[1] == "coaches":
        cmd_coaches()
    elif sys.argv[1] == "habits":
        cmd_habits()
    elif sys.argv[1] == "records":
        cmd_records(sys.argv[2], sys.argv[3], sys.argv[4])
    else:
        raise SystemExit(__doc__)
