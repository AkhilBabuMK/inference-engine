# -*- coding: utf-8 -*-
"""
deploy/demo_service/convert.py -- Redis train record (input guide v5, section 4) -> cris-v18 journey file.

The journey file is built by v18's OWN builder, copied unchanged from tag cris-v18 (v18_copies/build_journeys.py,
build_journey), fed with the record's stops as the rows it was trained on. Then one live rule is applied:

  * Only what was known at the forecast moment D is used: a real time later than D, or reported after D, is blanked.
  * Trains not yet on the corridor at D get their entry delay from F1/F2 rule R2: the delay at the latest upstream
    report known at D + this train's usual change from that station to the corridor (training days only,
    tables/entry_habits.json; station average if the train has none there; 0 if neither). F2 measured this rule
    (research_notes/entry_estimate_2026-11/f2_results.md: honest live number 8.86 min).

Fields the record does not carry and v18 does not read (verified by perturbation, serving_contract/
model_inputs_cris-v18.json): distance_from_source_km, ptt_stoppage_flag, train_sub_type, platform. They are filled with
neutral values (0 / False / "" / none).
"""
from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

import pandas as pd

HERE = Path(__file__).resolve().parent
_BJ = None


def _builder():
    """Load v18_copies/build_journeys.py as cris_pipeline.build_journeys (the package's cris_pipeline must be on
    sys.path: it supplies config.py, identical to the tag). build_topology comes from v18_copies too."""
    global _BJ
    if _BJ is None:
        for name in ("build_topology", "build_journeys"):
            full = f"cris_pipeline.{name}"
            if full in sys.modules:
                continue
            spec = importlib.util.spec_from_file_location(full, HERE / "v18_copies" / f"{name}.py")
            mod = importlib.util.module_from_spec(spec)
            sys.modules[full] = mod
            spec.loader.exec_module(mod)
        _BJ = sys.modules["cris_pipeline.build_journeys"]
    return _BJ


class Habits:
    def __init__(self, path: Path = HERE / "tables" / "entry_habits.json"):
        d = json.loads(Path(path).read_text(encoding="utf-8"))
        self.by_ts = d["by_train_station"]
        self.by_s = d["by_station"]

    def get(self, train: str, station: str) -> float:
        return float(self.by_ts.get(f"{train}|{station}", self.by_s.get(station, 0.0)))


def _ts(v):
    """ISO with +05:30 -> naive local Timestamp (the training data is naive local time)."""
    if v is None:
        return pd.NaT
    t = pd.Timestamp(v)
    if t.tzinfo is not None:
        t = t.tz_convert("Asia/Kolkata").tz_localize(None)
    return t


def record_to_rows(rec: dict, D: pd.Timestamp, use_reported: bool = True) -> pd.DataFrame:
    """The record's stops as the stop rows build_journey was trained on, with everything after D blanked.
    use_reported: also blank a time whose report (stops[].reported_at) came after D -- what a live system knew."""
    stops = sorted(rec["stops"], key=lambda s: s["serial_number"])
    tn = str(rec["train_number"])
    rows = []
    for s in stops:
        rep = _ts(s.get("reported_at"))
        aa, ad = _ts(s.get("actual_arrival_time")), _ts(s.get("actual_departure_time"))
        # reported_at is when the row was LAST updated: it dates the row's latest event (the departure if there is
        # one, else the arrival). An earlier event of the same row was reported earlier, so it is not held back.
        late_report = use_reported and pd.notna(rep) and rep > D
        if pd.notna(ad) and (ad > D or late_report):
            ad = pd.NaT
            late_report = False                   # the late report was the departure's
        if pd.notna(aa) and (aa > D or (late_report and pd.isna(_ts(s.get("actual_departure_time"))))):
            aa = pd.NaT
        bh = s.get("booked_halt")
        rows.append({
            "train_no": tn, "train_date": rec["train_date"], "train_type": rec.get("train_type") or "",
            "train_sub_type": "", "serial_number": int(s["serial_number"]), "station_code": s["station_code"],
            "scheduled_arrival_time": _ts(s.get("scheduled_arrival_time")),
            "scheduled_departure_time": _ts(s.get("scheduled_departure_time")),
            "actual_arrival_time": aa, "actual_departure_time": ad,
            # null flag = unknown in the source; the training rows had NaN there, which the builder read as True
            "wtt_stop_flag": float("nan") if bh is None else int(bool(bh)),
            "ptt_stoppage_flag": 0,
            "traffic_allowance_seconds": float(s.get("allowance_min") or 0.0) * 60.0,
            "engineering_allowance_seconds": 0.0,
            "distance_from_source_km": 0.0,
            "record_update_timestamp": rep,
            "train_source_station": stops[0]["station_code"], "train_destination_station": stops[-1]["station_code"],
        })
    df = pd.DataFrame(rows)
    df["arr_delay"] = (df.actual_arrival_time - df.scheduled_arrival_time).dt.total_seconds() / 60.0
    df["dep_delay"] = (df.actual_departure_time - df.scheduled_departure_time).dt.total_seconds() / 60.0
    return df


def entry_r2(rows: pd.DataFrame, journey: dict, D: pd.Timestamp, habits: Habits) -> str:
    """For a train not yet on the corridor at D: entry delay = last known upstream delay + usual change (rule R2).
    Returns how the entry was set (for the log)."""
    if any(x is not None and x <= _rel(D, journey) for s in journey["stops"]
           for x in (s.get("actual_arr_min"), s.get("actual_dep_min"))):
        return "on_corridor"                      # its upstream is the past: entry block as built
    e = journey["entry"]
    if not e.get("has_upstream"):
        return "timetable"
    from cris_pipeline.config import CORRIDOR
    in_corr = rows.station_code.isin(CORRIDOR).to_numpy()
    first = int(in_corr.argmax())
    up = rows.iloc[:first].copy()
    up["ev"] = up.actual_departure_time.fillna(up.actual_arrival_time)
    up["sch"] = up.scheduled_departure_time.where(up.actual_departure_time.notna(), up.scheduled_arrival_time)
    up = up[up.ev.notna() & up.sch.notna()]
    if not len(up):
        return "last_arrival"
    last = up.iloc[-1]
    delay = (last.ev - last.sch).total_seconds() / 60.0
    e["entry_delay_min"] = round(float(delay) + habits.get(journey["train_no"], last.station_code), 2)
    return "R2"


def _rel(D: pd.Timestamp, journey: dict) -> float:
    return (D - pd.Timestamp(journey["corridor_date"])).total_seconds() / 60.0


def convert(rec: dict, D: pd.Timestamp, habits: Habits, use_reported: bool = True) -> tuple[dict | None, str]:
    """-> (journey dict or None, note). None = the builder leaves this run out, exactly as in training."""
    bj = _builder()
    rows = record_to_rows(rec, D, use_reported)
    n = rec.get("number_of_coaches")
    j = bj.build_journey(rows, {str(rec["train_number"]): int(n) if n is not None else 0}, {})
    if j is None:
        return None, "no corridor stops / too few"
    if j.get("_rejected"):
        return None, "rejected: " + j["reason"]
    j["data_source"] = "irpilot-redis"
    j["redis_run_id"] = rec.get("run_id")
    how = entry_r2(rows, j, D, habits)
    return j, how


def write_folder(records: list, D: pd.Timestamp, habits: Habits, out: Path, use_reported: bool = True) -> dict:
    """Convert every record and write <train_no>/<corridor_date>.json (a second run of the same train on the same
    corridor date gets #2, as v18's builder does). Returns counts for the log."""
    out = Path(out)
    stats: dict = {}
    for rec in sorted(records, key=lambda r: str(r.get("run_id"))):
        j, how = convert(rec, D, habits, use_reported)
        key = how if j is not None else ("left_out: " + how.split(":")[0])
        stats[key] = stats.get(key, 0) + 1
        if j is None:
            continue
        d = out / j["train_no"]
        d.mkdir(parents=True, exist_ok=True)
        p = d / f"{j['corridor_date']}.json"
        k = 2
        while p.exists():
            p = d / f"{j['corridor_date']}#{k}.json"; k += 1
        p.write_text(json.dumps(j), encoding="utf-8")
    return stats
