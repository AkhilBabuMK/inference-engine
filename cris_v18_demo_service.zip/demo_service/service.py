# -*- coding: utf-8 -*-
"""
deploy/demo_service/service.py -- the cris-v18 forecaster as a Redis service (REDIS_API_SPEC_cris-v18.md, version 3).

    python service.py               run for ever (settings from environment variables, see README.md)
    python service.py --dry-run     read Redis and forecast, but write NOTHING to Redis and call no output API
                                    (forecasts are saved to OUTPUT_DIR); use this first against their Redis
    python service.py --once        handle at most one batch, then exit (tests)

What one batch does (spec section 7.1): claim the newest batch (script A; batches jumped over are logged 'skipped'),
read every passenger record (ZRANGE + MGET in groups of 50), check, convert each record into a cris-v18 journey file
(convert.py: v18's own builder + the live entry rule), forecast with the frozen v18 package from the batch's
data_as_of, send the result to the output API, close the batch (script D), drop everything.

Demo note: goods trains, maintenance blocks and speed restrictions are read and counted, but the model uses the
package's own September copies of them (answered "as of" the forecast moment, exactly as in the release runs). This
is right for the September replay; a real live feed needs converters for them first.
"""
from __future__ import annotations

import argparse
import contextlib
import io
import json
import logging
import logging.handlers
import os
import socket
import sys
import tempfile
import time
import traceback
import uuid
from pathlib import Path

import pandas as pd
import redis

HERE = Path(__file__).resolve().parent


# ── settings ──────────────────────────────────────────────────────────────────────────────────────────────────────

def env(name, default=None):
    v = os.environ.get(name)
    return default if v in (None, "") else v


class Settings:
    def __init__(self, a):
        self.redis_url = env("REDIS_URL", "redis://localhost:6379/0")
        self.model = env("MODEL_NAME", "cris-v18")
        self.version = env("MODEL_VERSION", "cris-v18-serving-1.0+demo-1")
        self.pkg = Path(env("V18_PACKAGE", str(HERE.parent / "cris_v18_package_unpacked" / "cris_v18" / "model")))
        self.output_url = env("OUTPUT_API_URL")
        self.output_token = env("OUTPUT_API_TOKEN")
        self.output_dir = Path(env("OUTPUT_DIR", str(HERE / "outputs")))
        self.save_outputs = env("SAVE_OUTPUTS", "1") == "1"
        self.log_dir = Path(env("LOG_DIR", str(HERE / "logs")))
        self.lease = int(env("LEASE_SECONDS", "600"))
        self.poll = int(env("POLL_SECONDS", "60"))
        self.threads = int(env("TORCH_THREADS", str(os.cpu_count() or 4)))
        self.host = env("HOST_NAME", socket.gethostname())
        # 1 = a time reported after the forecast moment is not yet known (input guide: stops[].reported_at)
        self.use_reported = env("RESPECT_REPORTED_AT", "1") == "1"
        self.dry_run = a.dry_run
        self.once = a.once


# ── logging: console + one file per day, kept 14 days ─────────────────────────────────────────────────────────────

def make_log(cfg: Settings) -> logging.Logger:
    cfg.log_dir.mkdir(parents=True, exist_ok=True)
    log = logging.getLogger("svc")
    log.setLevel(logging.INFO)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    fh = logging.handlers.TimedRotatingFileHandler(cfg.log_dir / f"{cfg.model}.log", when="midnight",
                                                   backupCount=14, encoding="utf-8")
    fh.setFormatter(fmt)
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)
    log.handlers = [fh, sh]
    return log


# ── Redis side ────────────────────────────────────────────────────────────────────────────────────────────────────

class Feed:
    """Reads their keys; runs our five scripts (lua/*.lua = copies of the spec's section 7.3)."""

    def __init__(self, cfg: Settings, log):
        self.cfg, self.log = cfg, log
        self.r = redis.Redis.from_url(cfg.redis_url, decode_responses=True, socket_timeout=30,
                                      health_check_interval=30)
        self.mkey = f"irpilot:model:{cfg.model}"
        self.instance = uuid.uuid4().hex[:12]
        self.s = {n: self.r.register_script((HERE / "lua" / f"{n}.lua").read_text(encoding="utf-8"))
                  for n in "HRAPD"}
        self.ps = None

    # scripts
    def hello(self, mode):
        return self.s["H"](keys=[self.mkey, "irpilot:models"], args=[self.cfg.model, self.cfg.version,
                                                                      self.cfg.host, mode])

    def recover(self):
        return self.s["R"](keys=[self.mkey], args=[self.cfg.model, self.cfg.host, self.instance])

    def claim(self, n):
        return self.s["A"](keys=[self.mkey], args=[self.cfg.model, n, self.cfg.lease, self.cfg.version,
                                                    self.cfg.host, self.instance])

    def pause_skip(self, n):
        return self.s["P"](keys=[self.mkey], args=[self.cfg.model, n])

    def close(self, n, status, reason, pax, goods, ref):
        return self.s["D"](keys=[self.mkey], args=[self.cfg.model, n, status, reason[:500], pax, goods, ref,
                                                    self.instance])

    # reads
    def latest(self):
        v = self.r.hget("irpilot:feed:status", "batch_no")
        return int(v) if v not in (None, "") else None

    def model_row(self):
        return self.r.hgetall(self.mkey)

    def batch_log(self, n):
        return self.r.hgetall(f"irpilot:feed:batch:{n}")

    def read_all(self, kind):
        """kind 'pax' or 'goods' -> list of (run_id, score, record or None). MGET in groups of 50."""
        rows = self.r.zrange(f"irpilot:{kind}:changed", 0, -1, withscores=True)
        out = []
        for i in range(0, len(rows), 50):
            part = rows[i:i + 50]
            vals = self.r.mget([f"irpilot:{kind}:run:{m}" for m, _ in part])
            out += [(m, int(s), v) for (m, s), v in zip(part, vals)]
        return out

    def refs(self):
        return {k: self.r.get(f"irpilot:ref:{k}") for k in ("maintenance", "tsr", "infra", "platforms")}

    # wake-up
    def wait(self, seconds):
        """Return when a message arrives on irpilot:trigger or after `seconds`."""
        end = time.time() + seconds
        try:
            if self.ps is None:
                self.ps = self.r.pubsub(ignore_subscribe_messages=True)
                self.ps.subscribe("irpilot:trigger")
            while time.time() < end:
                m = self.ps.get_message(timeout=min(1.0, max(0.0, end - time.time())))
                if m and m.get("type") == "message":
                    return m.get("data")
        except redis.RedisError as e:
            self.log.warning(f"listener: {e}; reconnecting")
            with contextlib.suppress(Exception):
                self.ps.close()
            self.ps = None
            time.sleep(min(5, max(0, end - time.time())))
        return None


# ── the forecaster ────────────────────────────────────────────────────────────────────────────────────────────────

class Forecaster:
    def __init__(self, cfg: Settings, log):
        self.use_reported = cfg.use_reported
        sys.path.insert(0, str(cfg.pkg)); sys.path.insert(0, str(cfg.pkg / "serving")); sys.path.insert(0, str(HERE))
        import torch
        torch.set_num_threads(cfg.threads)
        with contextlib.redirect_stdout(io.StringIO()):
            import forecast as F
        import convert as C
        self.C = C
        self.habits = C.Habits()
        self._empty = tempfile.mkdtemp(prefix="v18_empty_")
        t = time.time()
        with contextlib.redirect_stdout(io.StringIO()):
            self.fc = F.V18Forecaster(journeys=Path(self._empty))
        log.info(f"model loaded in {time.time() - t:.1f}s ({self.fc.weights}, package {F.PACKAGE_VERSION}, "
                 f"{cfg.threads} threads)")

    def run(self, records: list, D: pd.Timestamp) -> tuple[dict, dict, dict]:
        """-> (forecast, conversion counts, meta). meta: instance id -> Redis run_id and the journey's stations."""
        with tempfile.TemporaryDirectory(prefix="v18_batch_") as tmp:
            conv = self.C.write_folder(records, D, self.habits, Path(tmp), self.use_reported)
            meta = {}
            for f in Path(tmp).glob("*/*.json"):
                j = json.loads(f.read_text(encoding="utf-8"))
                meta[f"{f.parent.name}_{f.stem}"] = {"run_id": j.get("redis_run_id"),
                                                     "stations": [s["station_code"] for s in j["stops"]]}
            self.fc.journeys = Path(tmp)
            with contextlib.redirect_stdout(io.StringIO()):
                res = self.fc.forecast(D.strftime("%Y-%m-%d"), D.hour * 60 + D.minute)
        return res, conv, meta


# ── checks (spec 8.2, 8.3) ────────────────────────────────────────────────────────────────────────────────────────

class CheckFailed(Exception):
    pass


def parse_records(rows: list, kind: str) -> tuple[list, int]:
    recs, gone = [], 0
    for rid, score, raw in rows:
        if raw is None:
            gone += 1                              # removed between ZRANGE and MGET: not an error
            continue
        try:
            rec = json.loads(raw)
        except ValueError:
            raise CheckFailed(f"check failed: {kind} record {rid} is not valid JSON")
        key_id = rec.get("run_id") if kind == "pax" else rec.get("coa_train_id")
        if str(key_id) != str(rid):
            raise CheckFailed(f"check failed: {kind} record {rid} holds id {key_id}")
        if int(rec.get("batch_no") or 0) < score:
            raise CheckFailed(f"check failed: {kind} record {rid} batch_no {rec.get('batch_no')} < change table {score}")
        recs.append(rec)
    return recs, gone


def as_of(v: str) -> pd.Timestamp:
    t = pd.Timestamp(v)
    return t.tz_convert("Asia/Kolkata").tz_localize(None) if t.tzinfo is not None else t


# ── output ────────────────────────────────────────────────────────────────────────────────────────────────────────

CORRIDOR_ORDER = ["STA", "LGCE", "UHR", "MYR", "BUU", "GNWA", "UDR", "PKRD", "JKE", "PTWA", "KTE", "KTES", "MDRR",
                  "NWR", "SNRR", "SBD", "DDCE", "SHR", "GSPR", "DOE", "ADTL", "JBP"]


def heterogeneous_rows(cfg: Settings, res: dict, meta: dict, data_as_of: str) -> list:
    """The forecast as rows for POST /api/v1/forecast/heterogeneous-results (one row per train per station).
    Key = (instance_id, issued_at, station_id): instance_id = the Redis run_id (train:start date), issued_at = the
    batch's data_as_of, station_id = corridor position (STA 0 ... JBP 21)."""
    rows = []
    for t in res["trains"]:
        m = meta.get(t["run_id"], {})
        rid = m.get("run_id") or t["run_id"]
        stations = m.get("stations", [])
        for hop, s in enumerate(t["stops"], start=1):
            k = s["stop_index"]
            prev = stations[k - 1] if 0 < k <= len(stations) else None
            rows.append({
                "instance_id": rid,
                "issued_at": data_as_of,
                "station_id": CORRIDOR_ORDER.index(s["station"]),
                "hop": hop,
                "lead_min": s["minutes_ahead"],
                "pred_delay_min": s["forecast_delay_min"],
                "lo80": None, "hi80": None,                    # v18 gives one number, no interval
                "model_version": cfg.version,
                "train_number": t["train_no"],
                "start_date": rid.split(":")[1][:10] if ":" in rid else None,
                "block_section": f"{prev}-{s['station']}" if prev else None,
                "typical_runtime": None,
                "minutes_from_start": None,
                "scheduled_arrival": s["booked_arrival"],
                "actual_arrival": None,                         # not known at forecast time
            })
    return rows


def send_output(cfg: Settings, log, payload: dict, rows: list) -> str:
    name = f"{cfg.model}_batch{payload['batch_no']:07d}.json"
    if cfg.save_outputs or not cfg.output_url or cfg.dry_run:
        cfg.output_dir.mkdir(parents=True, exist_ok=True)
        (cfg.output_dir / name).write_text(json.dumps({**payload, "api_rows": rows}), encoding="utf-8")
    if cfg.dry_run or not cfg.output_url:
        return f"file:{name}"
    if not rows:
        return "no forecasts to send"
    import requests
    hdr = {"Content-Type": "application/json"}
    if cfg.output_token:
        hdr["Authorization"] = f"Bearer {cfg.output_token}"
    last = ""
    for attempt in range(3):
        try:
            resp = requests.post(cfg.output_url, data=json.dumps(rows), headers=hdr, timeout=60)
            if 200 <= resp.status_code < 300:
                body = {}
                with contextlib.suppress(Exception):
                    body = resp.json()
                n = body.get("inserted") if isinstance(body, dict) else None
                if n is not None and int(n) != len(rows):
                    log.warning(f"output API inserted {n} of {len(rows)} rows")
                return f"inserted {n}" if n is not None else f"http {resp.status_code}"
            last = f"{resp.status_code} {resp.text[:200]}"
            if attempt > 0 and "duplicate" in resp.text.lower():
                # the earlier attempt landed but its answer was lost: the rows are already in
                log.warning("output API: duplicate on retry, the earlier attempt had inserted the rows")
                return f"inserted {len(rows)} (earlier attempt)"
        except Exception as e:
            last = f"{type(e).__name__}: {e}"
        log.warning(f"output API attempt {attempt + 1}: {last}")
        if attempt < 2:
            time.sleep(10)
    raise RuntimeError(f"output API: {last} after 3 tries")


# ── one batch ─────────────────────────────────────────────────────────────────────────────────────────────────────

def process(cfg, log, feed: Feed, fc: Forecaster, n: int) -> tuple[str, str, int, int, str]:
    """-> (status, reason, pax_read, goods_read, output_ref). Never raises."""
    pax = goods = 0
    t0 = time.time()
    try:
        blog = feed.batch_log(n)
        if not blog:
            raise CheckFailed("error: batch log missing")
        D = as_of(blog["data_as_of"])
        prev = feed.batch_log(n - 1)
        if prev and as_of(prev["data_as_of"]) >= D:
            raise CheckFailed("check failed: data_as_of went back")
        recs, gone = parse_records(feed.read_all("pax"), "pax")
        g_recs, _ = parse_records(feed.read_all("goods"), "goods")
        refs = feed.refs()
        pax, goods = len(recs), len(g_recs)
        if not 150 <= pax <= 450:
            log.warning(f"batch {n}: {pax} passenger records, outside the usual 250-350")
        t_read = time.time() - t0
        res, conv, meta = fc.run(recs, D)
        payload = {"model": cfg.model, "model_version": cfg.version, "batch_no": n,
                   "data_as_of": blog["data_as_of"], "forecast": res}
        rows = heterogeneous_rows(cfg, res, meta, blog["data_as_of"])
        ref = send_output(cfg, log, payload, rows)
        log.info(f"batch {n} [{blog['data_as_of']}] completed: {pax} pax read ({gone} removed meanwhile), "
                 f"{goods} goods, refs {sorted(k for k, v in refs.items() if v)}, converted {conv}, "
                 f"{res['n_trains']} trains / {res['n_forecasts']} station forecasts, "
                 f"warnings {res['input_warnings']}, read {t_read:.1f}s, total {time.time() - t0:.1f}s -> {ref}")
        return "completed", "", pax, goods, ref
    except CheckFailed as e:
        log.error(f"batch {n} failed: {e}")
        return "failed", str(e), pax, goods, ""
    except Exception as e:
        log.error(f"batch {n} failed: {type(e).__name__}: {e}\n{traceback.format_exc()}")
        msg = str(e) if str(e).startswith("output API") else f"error: {type(e).__name__}: {e}"
        return "failed", msg, pax, goods, ""


# ── the loop (spec 7.1) ───────────────────────────────────────────────────────────────────────────────────────────

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--once", action="store_true")
    cfg = Settings(ap.parse_args())
    log = make_log(cfg)
    log.info(f"starting {cfg.model} {cfg.version} on {cfg.host} ({'DRY RUN: no Redis writes, no output API' if cfg.dry_run else 'live'})"
             f"; redis {cfg.redis_url.split('@')[-1]}; output {'file ' + str(cfg.output_dir) if not cfg.output_url else cfg.output_url}")
    feed = Feed(cfg, log)
    fc = Forecaster(cfg, log)
    if not cfg.dry_run:
        feed.hello("start")
        if feed.recover():
            log.warning("a claim left by a dead process was set failed")
    done_dry = None
    while True:
        try:
            if cfg.dry_run:
                latest = feed.latest()
                if latest is not None and latest != done_dry:
                    st, why, p, g, ref = process(cfg, log, feed, fc, latest)
                    log.info(f"[dry run] batch {latest}: {st} {why} {ref}")
                    done_dry = latest
                    if cfg.once:
                        return 0
                    continue
                if cfg.once and latest is None:
                    log.info("no batch in Redis yet"); return 0
                msg = feed.wait(cfg.poll)
                log.info(f"wake-up message: batch {msg}" if msg is not None else "no wake-up for 60 s: checking Redis myself")
                continue

            feed.hello("beat")
            if feed.recover():
                log.warning("an expired or dead claim was set failed")
            latest = feed.latest()
            row = feed.model_row()
            last = int(row.get("last_finished") or 0)
            if latest is None:
                log.info("no batch in Redis yet")
            elif latest < last:
                log.error(f"batch number went back: newest {latest} < last finished {last}; taking nothing")
            elif row.get("enabled") == "0":
                k = feed.pause_skip(latest)
                if k:
                    log.info(f"paused: {k} batch(es) logged skipped (up to {latest})")
            elif latest > last:
                res = feed.claim(latest)
                if int(res[0]) == 0:
                    log.info(f"claim of {latest} refused: {res[1]}")
                else:
                    if int(res[1]):
                        log.info(f"claimed {latest}; {res[1]} older batch(es) logged skipped")
                    st, why, p, g, ref = process(cfg, log, feed, fc, latest)
                    if not feed.close(latest, st, why, p, g, ref):
                        log.warning(f"batch {latest}: close refused (the lease had run out; it is already failed)")
                    if cfg.once:
                        return 0
                    continue                      # look again at once: a newer batch may be waiting
            if cfg.once:
                return 0
            msg = feed.wait(cfg.poll)
            log.info(f"wake-up message: batch {msg}" if msg is not None else "no wake-up for 60 s: checking Redis myself")
        except redis.RedisError as e:
            log.error(f"redis: {e}; retrying in 5 s")
            time.sleep(5)
        except KeyboardInterrupt:
            log.info("stopped by hand")
            return 0


if __name__ == "__main__":
    sys.exit(main())
