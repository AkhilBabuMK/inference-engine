-- KEYS[1] irpilot:model:{model}
-- ARGV[1] model   ARGV[2] newest batch_no
local m = KEYS[1]
if redis.call('HGET', m, 'state') == 'busy' then return 0 end
local now = tonumber(redis.call('TIME')[1])
local n = tonumber(ARGV[2])
local last = tonumber(redis.call('HGET', m, 'last_finished') or '0')
local from = last + 1
if last == 0 then from = n end
local pfx = 'irpilot:status:' .. ARGV[1] .. ':'
local skipped = 0
for b = math.max(from, n - 2100), n do
  local log = 'irpilot:feed:batch:' .. b
  if redis.call('EXISTS', log) == 1 and redis.call('EXISTS', pfx .. b) == 0 then
    redis.call('HSET', pfx .. b, 'batch_no', b, 'model', ARGV[1], 'status', 'skipped',
               'reason', 'model paused', 'finished_at', now)
    redis.call('EXPIRE', pfx .. b, 604800)
    skipped = skipped + 1
  end
end
if n > last then redis.call('HSET', m, 'last_finished', n, 'last_finished_status', 'skipped') end
redis.call('HSET', m, 'last_seen', now)
return skipped
