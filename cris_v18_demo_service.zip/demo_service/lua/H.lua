-- KEYS[1] irpilot:model:{model}   KEYS[2] irpilot:models
-- ARGV[1] model   ARGV[2] version   ARGV[3] host   ARGV[4] 'start' or 'beat'
local now = tonumber(redis.call('TIME')[1])
if ARGV[4] == 'start' then
  redis.call('HSET', KEYS[1], 'model', ARGV[1], 'version', ARGV[2], 'host', ARGV[3], 'process_started_at', now)
  redis.call('HSETNX', KEYS[1], 'enabled', '1')
  redis.call('HSETNX', KEYS[1], 'state', 'idle')
  redis.call('SADD', KEYS[2], ARGV[1])
end
redis.call('HSET', KEYS[1], 'last_seen', now)
return now
