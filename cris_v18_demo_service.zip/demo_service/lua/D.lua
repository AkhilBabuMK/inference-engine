-- KEYS[1] irpilot:model:{model}
-- ARGV[1] model   ARGV[2] N   ARGV[3] 'completed' or 'failed'   ARGV[4] reason ('' if none)
-- ARGV[5] pax_read   ARGV[6] goods_read   ARGV[7] output_ref ('' if none)   ARGV[8] my instance
local m = KEYS[1]
local row = 'irpilot:status:' .. ARGV[1] .. ':' .. ARGV[2]
if redis.call('HGET', row, 'status') ~= 'in_progress' then return 0 end
if redis.call('HGET', m, 'busy_instance') ~= ARGV[8] then return 0 end
local now = tonumber(redis.call('TIME')[1])
redis.call('HSET', row, 'status', ARGV[3], 'reason', ARGV[4], 'finished_at', now,
           'pax_read', ARGV[5], 'goods_read', ARGV[6], 'output_ref', ARGV[7])
redis.call('HSET', m, 'state', 'idle', 'batch_no', '', 'last_finished', ARGV[2],
           'last_finished_status', ARGV[3], 'last_seen', now)
return 1
