-- KEYS[1] irpilot:model:{model}
-- ARGV[1] model   ARGV[2] my host   ARGV[3] my instance
local m = KEYS[1]
if redis.call('HGET', m, 'state') ~= 'busy' then return 0 end
local now = tonumber(redis.call('TIME')[1])
local lease = tonumber(redis.call('HGET', m, 'lease_until') or '0')
local restarted = redis.call('HGET', m, 'busy_host') == ARGV[2]
                  and redis.call('HGET', m, 'busy_instance') ~= ARGV[3]
if lease >= now and not restarted then return 0 end      -- a live claim (maybe another copy): leave it
local n = redis.call('HGET', m, 'batch_no')
local row = 'irpilot:status:' .. ARGV[1] .. ':' .. n
local why = 'lease expired'
if restarted then why = 'model restarted' end
if redis.call('HGET', row, 'status') == 'in_progress' then
  redis.call('HSET', row, 'status', 'failed', 'reason', why, 'finished_at', now)
end
redis.call('HSET', m, 'state', 'idle', 'batch_no', '', 'last_finished', n, 'last_finished_status', 'failed')
return 1
