-- KEYS[1] irpilot:model:{model}
-- ARGV[1] model   ARGV[2] N   ARGV[3] lease seconds (600)   ARGV[4] version   ARGV[5] my host   ARGV[6] my instance
local m = KEYS[1]
local now = tonumber(redis.call('TIME')[1])
if redis.call('HGET', m, 'enabled') == '0' then return {0, 'paused'} end
if redis.call('HGET', m, 'state') == 'busy' then return {0, 'busy'} end
local n = tonumber(ARGV[2])
local last = tonumber(redis.call('HGET', m, 'last_finished') or '0')
if n <= last then return {0, 'not newer'} end
local pfx = 'irpilot:status:' .. ARGV[1] .. ':'
local started = tonumber(redis.call('HGET', m, 'process_started_at') or '0')
local skipped = 0
if last > 0 then                                          -- first start ever: skip nothing (7.2)
  for b = math.max(last + 1, n - 2100), n - 1 do          -- 2100 > 7 days of batches; older logs have expired
    local log = 'irpilot:feed:batch:' .. b
    if redis.call('EXISTS', log) == 1 and redis.call('EXISTS', pfx .. b) == 0 then
      local why = 'newer batch ' .. n .. ' taken'
      if tonumber(redis.call('HGET', log, 'written_at') or '0') < started then why = 'model was not running' end
      redis.call('HSET', pfx .. b, 'batch_no', b, 'model', ARGV[1], 'status', 'skipped',
                 'reason', why, 'finished_at', now)
      redis.call('EXPIRE', pfx .. b, 604800)
      skipped = skipped + 1
    end
  end
end
local lease = now + tonumber(ARGV[3])
redis.call('HSET', pfx .. n, 'batch_no', n, 'model', ARGV[1], 'status', 'in_progress',
           'started_at', now, 'model_version', ARGV[4])
redis.call('EXPIRE', pfx .. n, 604800)
redis.call('HSET', m, 'state', 'busy', 'batch_no', n, 'lease_until', lease,
           'busy_host', ARGV[5], 'busy_instance', ARGV[6], 'last_seen', now)
return {lease, skipped}
