# cris-v18 demo service (Redis)

Runs the frozen cris-v18 forecaster against the database team's Redis, exactly as described in
`serving_contract/REDIS_API_SPEC_cris-v18.md` (version 3): wakes on `irpilot:trigger` (or every 60 s), claims the
newest batch, reads every train record, forecasts, sends the result to the output API, and logs every batch in its own
status table (`completed` / `failed` / `skipped` with a reason). It keeps nothing between batches.

**It does not change the model.** The forecast is the cris-v18 package (`deploy/cris_v18_package/dist/cris_v18.zip`,
tag `cris-v18`) as released. The production folder `jabalpur_scenario_gnn/` is not used or touched.

## What is in this folder

| File | What it does |
|---|---|
| `service.py` | the loop: listen, claim, read, check, convert, forecast, send, close (spec section 7.1) |
| `convert.py` | one Redis record → one cris-v18 journey file, with v18's **own** builder (`v18_copies/`, copied unchanged from tag cris-v18) + the live entry rule (F2 rule R2) |
| `lua/*.lua` | the five scripts H, R, A, P, D, copied from the spec (section 7.3) |
| `tables/entry_habits.json` | the entry rule's "usual change on the way in", training days only (built by `tools/build_from_september.py habits`) |
| `tools/build_from_september.py` | builds the habit table and **golden records** (what the database team's records should look like for September runs) |
| `tools/replay_loader.py` | a reference loader for the database team's side (spec section 4): replays golden records into a Redis as batches |
| `tests/` | the checks below |

## Install on the VM

1. Python 3.14 (what the package was verified with). Unzip `cris_v18.zip` somewhere, e.g. `/opt/cris_v18`.
2. `pip install torch==2.11.0 --index-url https://download.pytorch.org/whl/cpu`, then
   `pip install -r /opt/cris_v18/requirements.txt`, then `pip install -r requirements.txt` (this folder).
3. Check the package: `python /opt/cris_v18/model/serving/verify.py` must print ALL PASS.
4. Copy this folder next to it.

## Settings (environment variables)

| Variable | Meaning | Default |
|---|---|---|
| `REDIS_URL` | `redis://USER:PASSWORD@HOST:PORT/DB` | `redis://localhost:6379/0` |
| `V18_PACKAGE` | the unpacked package's `model` folder, e.g. `/opt/cris_v18/model` | `../cris_v18_package_unpacked/cris_v18/model` |
| `MODEL_NAME` | name in all keys | `cris-v18` |
| `MODEL_VERSION` | written in the model row and status rows | `cris-v18-serving-1.0+demo-1` |
| `OUTPUT_API_URL` | their output API; empty = save to files only | (empty) |
| `OUTPUT_API_TOKEN` | sent as `Authorization: Bearer …` if set | (empty) |
| `OUTPUT_DIR`, `SAVE_OUTPUTS` | local copy of every forecast (1 = keep) | `./outputs`, `1` |
| `LOG_DIR` | one log file per day, kept 14 days | `./logs` |
| `RESPECT_REPORTED_AT` | 1 = a departure (or a lone arrival) reported after the forecast moment is not yet known | `1` |
| `TORCH_THREADS` | CPU threads for the model | all cores |
| `LEASE_SECONDS`, `POLL_SECONDS` | claim lease, backup check | `600`, `60` |

The output API format is still open (spec question 1). Until it is known, the service POSTs one JSON per batch:
`{"model", "model_version", "batch_no", "data_as_of", "forecast": <the package's forecast JSON>}` and takes
`output_ref` (or `id`, `ref`) from the answer.

## Run

```
python service.py --dry-run      # FIRST: reads their Redis and forecasts, writes NOTHING to Redis, no output API
python service.py                # the real run
```

Dry run against their Redis first: it proves the connection and their records without touching anything of theirs.
The log shows, per batch: records read, how each was converted (`on_corridor`, `R2` = outside with entry rule,
`timetable` = not started), trains and station forecasts made, warnings, and the time taken.

## Demo limits (say these plainly)

- **Goods trains, maintenance blocks, speed restrictions:** read and counted, but the model uses the package's own
  September copies (answered "as of" the forecast moment, as in the release runs). Right for the September replay; a
  real live feed needs converters first.
- **Accuracy:** the honest live figure for v18 is 8.86 min average error up to 4 h ahead on the test days 26–30 Sep
  (F2). Days 1–20 Sep were used to train it: forecasts there look better than real.
- **Records the database team's builder must match:** compare their records with the golden records
  (`tools/build_from_september.py records ...`) before trusting the demo numbers.

## Checks (all run on this machine, 2026-11-27)

| Check | Result |
|---|---|
| `tests/test_convert_parity.py` | golden records → journey files identical to the released v18 files on every field v18 reads: 363 / 364 runs (24–27 Sep); the one difference is special A17409, whose training file has "unknown" allowances |
| `serving_contract/verification/test_redis_scripts.py` | the five scripts, as written in the spec: 23 / 23 |
| `tests/test_e2e_fakeredis.py` | loader → service → status rows / skip / dry run on an in-memory Redis: ALL PASS |
| `tests/compare_f2.py` | whole Redis path vs F2 (v18 honest live) on 26 Sep, 16 moments, 1,226 scored arrivals: service covers 98.7 %, average error **9.61 min vs F2 9.70** on the same arrivals (with report times ignored: 99.3 %, 9.59 vs 9.71, 743 forecasts identical to F2). Rows: `tests/compare_f2_2025-09-26.csv` |

Why not every forecast is identical to F2: F2 started from the research files, which know a few things a live record
cannot (the train's final corridor date, departures that were never recorded); the service starts from what the record
shows at the moment. The average error is the same.

Note found while building: in the September data a stop's `reported_at` (CRIS `record_update_timestamp`) is when the
row was **last** updated, usually at the departure. It therefore only holds back the row's latest event; holding back
the arrival too hid trains that had already arrived (first run: 88 % coverage, 9.19 vs 8.83).
