# -*- coding: utf-8 -*-
"""
deploy/demo_service/tests/test_output_api.py -- the service against a stand-in for the backend's
POST /api/v1/forecast/heterogeneous-results (their spec, 2026-11-27): JSON array; instance_id, issued_at, station_id
required and together the primary key; a duplicate key refuses the insert; success = {"message": "Success",
"inserted": N}.

    python tests/test_output_api.py PKG GOLDEN_DIR WORK_DIR
"""
import json
import os
import sys
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

import fakeredis
import pandas as pd
import redis

PKG, GOLD, WORK = (Path(a).resolve() for a in sys.argv[1:4])
SERVICE = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(SERVICE), str(SERVICE / "tools")]

KEYS, POSTS = set(), []


class Stub(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        ok = self.path == "/api/v1/forecast/heterogeneous-results" and isinstance(body, list)
        bad = [r for r in body if not (isinstance(r.get("instance_id"), str) and isinstance(r.get("issued_at"), str)
                                       and isinstance(r.get("station_id"), int))] if ok else body
        keys = [(r["instance_id"], r["issued_at"], r["station_id"]) for r in body] if ok and not bad else []
        dup = len(set(keys)) != len(keys) or any(k in KEYS for k in keys)
        if not ok or bad:
            code, out = 422, {"detail": "invalid fields"}
        elif dup:
            code, out = 409, {"detail": "duplicate key value violates unique constraint"}
        else:
            KEYS.update(keys); POSTS.append(body)
            code, out = 200, {"message": "Success", "inserted": len(body)}
        data = json.dumps(out).encode()
        self.send_response(code); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)


srv = HTTPServer(("127.0.0.1", 0), Stub)
threading.Thread(target=srv.serve_forever, daemon=True).start()
url = f"http://127.0.0.1:{srv.server_port}/api/v1/forecast/heterogeneous-results"

server = fakeredis.FakeServer()
redis.Redis.from_url = staticmethod(lambda *a, **k: fakeredis.FakeRedis(server=server, decode_responses=True))
r = fakeredis.FakeRedis(server=server, decode_responses=True)
os.environ.update({"V18_PACKAGE": str(PKG), "OUTPUT_DIR": str(WORK / "outputs"), "LOG_DIR": str(WORK / "logs"),
                   "OUTPUT_API_URL": url, "HOST_NAME": "test-vm", "TORCH_THREADS": "4"})
import service  # noqa: E402
from replay_loader import Loader  # noqa: E402

FAILS = []


def check(name, cond, extra=""):
    print(("PASS " if cond else "FAIL ") + name + (f"  ({extra})" if extra else ""), flush=True)
    if not cond:
        FAILS.append(name)


L = Loader(r, GOLD)
for i, D in enumerate(("2025-09-26 10:00", "2025-09-26 10:01"), start=1):
    L.write(pd.Timestamp(D))
    sys.argv = ["service.py", "--once"]
    service.main()
    st = r.hgetall(f"irpilot:status:cris-v18:{i}")
    check(f"batch {i} completed and sent", st.get("status") == "completed" and st.get("output_ref", "").startswith("inserted"),
          f"{st.get('status')} {st.get('output_ref')} {st.get('reason', '')}")

rows = [x for p in POSTS for x in p]
check("two POSTs, one per batch", len(POSTS) == 2, str(len(POSTS)))
check("every row has the three key fields", all(x["instance_id"] and x["issued_at"] and isinstance(x["station_id"], int) for x in rows))
check("keys unique across batches (issued_at differs)", len(KEYS) == len(rows), f"{len(KEYS)} keys / {len(rows)} rows")
check("instance_id = Redis run_id (train:start date)", all(":" in x["instance_id"] for x in rows))
ex = rows[0]
print("\nexample row:", json.dumps(ex, indent=1))
print(f"\n{'ALL PASS' if not FAILS else str(len(FAILS)) + ' FAILED'}")
srv.shutdown()
sys.exit(1 if FAILS else 0)
