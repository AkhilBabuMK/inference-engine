# -*- coding: utf-8 -*-
"""
deploy/demo_service/tests/test_e2e_fakeredis.py -- the whole demo flow in one process, on an in-memory Redis.

    python tests/test_e2e_fakeredis.py PKG GOLDEN_DIR WORK_DIR [F2_DIR]

1. the reference loader writes batch 1 (26 Sep 10:00) as the database team would (spec section 4);
2. the service runs once: claims 1, reads, converts, forecasts, saves the output, closes 'completed';
3. the loader writes batches 2 (10:15) and 3 (10:30); the service runs once: logs 2 'skipped', completes 3;
4. a dry run on batch 4 (10:45) forecasts but writes nothing to Redis;
5. the forecasts at 10:00 and 10:30 are compared with F2's honest-live forecasts for the same moments
   (research_notes/entry_estimate_2026-11/f2_rows_*.csv) and with what really happened.
Needs: pip install "fakeredis[lua]" (only for this test).
"""
import glob
import json
import os
import sys
from pathlib import Path

import fakeredis
import pandas as pd
import redis

PKG, GOLD, WORK = (Path(a).resolve() for a in sys.argv[1:4])
F2 = Path(sys.argv[4]) if len(sys.argv) > 4 else None
SERVICE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SERVICE)); sys.path.insert(0, str(SERVICE / "tools"))

server = fakeredis.FakeServer()
redis.Redis.from_url = staticmethod(lambda *a, **k: fakeredis.FakeRedis(server=server, decode_responses=True))
r = fakeredis.FakeRedis(server=server, decode_responses=True)

os.environ.update({"V18_PACKAGE": str(PKG), "OUTPUT_DIR": str(WORK / "outputs"), "LOG_DIR": str(WORK / "logs"),
                   "MODEL_NAME": "cris-v18", "HOST_NAME": "test-vm", "TORCH_THREADS": "4"})
import service  # noqa: E402
from replay_loader import Loader  # noqa: E402

FAILS = []


def check(name, cond, extra=""):
    print(("PASS " if cond else "FAIL ") + name + (f"  ({extra})" if extra else ""), flush=True)
    if not cond:
        FAILS.append(name)


def run_service(*flags):
    sys.argv = ["service.py", "--once", *flags]
    return service.main()


def st(n):
    return r.hgetall(f"irpilot:status:cris-v18:{n}")


def compare(n, moment):
    out = json.loads((WORK / "outputs" / f"cris-v18_batch{n:07d}.json").read_text(encoding="utf-8"))["forecast"]
    got = {(t["run_id"], s["stop_index"]): s["forecast_delay_min"] for t in out["trains"]
           if t["on_corridor_at_moment"] for s in t["stops"]}
    if F2 is None:
        return out
    d = pd.concat([pd.read_csv(f) for f in glob.glob(str(F2 / "f2_rows_*.csv"))])
    t0 = int((pd.Timestamp(moment) - pd.Timestamp("2025-09-02")).total_seconds() // 60)
    d = d[d.t0 == t0]
    rows = [(x.live, got.get((x.iid, x.k)), x.actual) for x in d.itertuples()]
    m = [(a, b, c) for a, b, c in rows if b is not None and pd.notna(a)]
    same = sum(abs(a - b) < 0.01 for a, b, c in m)
    mae_f2 = sum(abs(a - c) for a, b, c in m) / max(len(m), 1)
    mae_us = sum(abs(b - c) for a, b, c in m) / max(len(m), 1)
    print(f"     {moment}: F2 keys {len(d)}, found {len(m)}, identical {same} "
          f"| error vs real: service {mae_us:.2f} min, F2 {mae_f2:.2f} min", flush=True)
    # informational only: tests/compare_f2.py is the accuracy check over a whole day
    print(f"     (service forecast {len(m)} of {len(d.dropna(subset=['live']))} F2 keys)")
    return out


L = Loader(r, GOLD)
n1 = L.write(pd.Timestamp("2025-09-26 10:00"))
run_service()
check("batch 1 completed", st(1).get("status") == "completed", st(1).get("reason", ""))
check("model row idle, last_finished 1", r.hget("irpilot:model:cris-v18", "last_finished") == "1"
      and r.hget("irpilot:model:cris-v18", "state") == "idle")
compare(1, "2025-09-26 10:00")

L.write(pd.Timestamp("2025-09-26 10:15")); L.write(pd.Timestamp("2025-09-26 10:30"))
run_service()
# batch 2 was written before this (second) service process started, so the right reason is "model was not running"
check("batch 2 skipped 'model was not running'", st(2).get("status") == "skipped"
      and st(2).get("reason") == "model was not running", str(st(2)))
check("batch 3 completed", st(3).get("status") == "completed", st(3).get("reason", ""))
check("status rows expire in 7 days", 0 < r.ttl("irpilot:status:cris-v18:3") <= 604800)
compare(3, "2025-09-26 10:30")

L.write(pd.Timestamp("2025-09-26 10:45"))
before = r.hgetall("irpilot:model:cris-v18")
run_service("--dry-run")
check("dry run wrote nothing to Redis", st(4) == {} and r.hgetall("irpilot:model:cris-v18") == before)
check("dry run saved its forecast", (WORK / "outputs" / "cris-v18_batch0000004.json").exists())

print(f"\n{'ALL PASS' if not FAILS else str(len(FAILS)) + ' FAILED: ' + '; '.join(FAILS)}")
sys.exit(1 if FAILS else 0)
