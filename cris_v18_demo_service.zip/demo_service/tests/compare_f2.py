# -*- coding: utf-8 -*-
"""
deploy/demo_service/tests/compare_f2.py -- does the Redis path give v18's honest-live accuracy?

Replays one test day through the reference loader (as Redis records), converts and forecasts with the service's own
code at several moments, and scores against what really happened on exactly the keys F2 scored
(research_notes/entry_estimate_2026-11/f2_rows_*.csv: same package, honest entry rule, from research files).

    python tests/compare_f2.py PKG GOLDEN_DIR F2_DIR DATE [STEP_HOURS]
Two variants: reported_at respected (what the service does by default) and ignored (closest to F2's inputs).
"""
import contextlib
import glob
import io
import json
import logging
import sys
import types
from pathlib import Path

import fakeredis
import pandas as pd

PKG, GOLD, F2 = (Path(a).resolve() for a in sys.argv[1:4])
DATE = sys.argv[4]
STEP = float(sys.argv[5]) if len(sys.argv) > 5 else 3.0
SERVICE = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(SERVICE), str(SERVICE / "tools")]
import service  # noqa: E402
from replay_loader import Loader  # noqa: E402

cfg = types.SimpleNamespace(pkg=PKG, threads=4, use_reported=True)
fc = service.Forecaster(cfg, logging.getLogger("x"))
f2 = pd.concat([pd.read_csv(f) for f in glob.glob(str(F2 / "f2_rows_*.csv"))])
rr = {v: fakeredis.FakeRedis(server=fakeredis.FakeServer(), decode_responses=True) for v in (True, False)}
LL = {v: Loader(rr[v], GOLD, use_reported=v) for v in (True, False)}
rows = []
D = pd.Timestamp(DATE)
while D < pd.Timestamp(DATE) + pd.Timedelta(days=1):
    t0 = int((D - pd.Timestamp("2025-09-02")).total_seconds() // 60)
    want = f2[(f2.t0 == t0) & f2.live.notna()]
    for variant in (True, False):
        r, L = rr[variant], LL[variant]
        L.write(D)
        recs = [json.loads(r.get(f"irpilot:pax:run:{m}")) for m in r.zrange("irpilot:pax:changed", 0, -1)]
        fc.use_reported = variant
        res, conv = fc.run(recs, D)
        got = {(t["run_id"], s["stop_index"]): s["forecast_delay_min"] for t in res["trains"]
               if t["on_corridor_at_moment"] for s in t["stops"]}
        for x in want.itertuples():
            rows.append({"moment": str(D), "reported_at": variant, "key": f"{x.iid}|{x.k}", "actual": x.actual,
                         "f2": x.live, "service": got.get((x.iid, x.k))})
    print(f"{D}: {len(want)} F2 keys, converted {conv}", flush=True)
    D += pd.Timedelta(hours=STEP)

d = pd.DataFrame(rows)
for variant, g in d.groupby("reported_at"):
    m = g[g.service.notna()]
    print(f"\nreported_at respected = {variant}: keys {len(g)}, forecast by service {len(m)} "
          f"({100 * len(m) / len(g):.1f}%), identical to F2 {int(((m.service - m.f2).abs() < 0.01).sum())}")
    print(f"  average error vs real, same keys: service {(m.service - m.actual).abs().mean():.2f} min, "
          f"F2 {(m.f2 - m.actual).abs().mean():.2f} min; mean |service - F2| {(m.service - m.f2).abs().mean():.2f}")
    per = m.assign(es=(m.service - m.actual).abs(), ef=(m.f2 - m.actual).abs()).groupby("moment")[["es", "ef"]].mean()
    print(per.round(2).to_string())
out = SERVICE / "tests" / f"compare_f2_{DATE}.csv"
d.to_csv(out, index=False)
print(f"\nrows -> {out}")
