# -*- coding: utf-8 -*-
"""
deploy/demo_service/tests/test_convert_parity.py

Build parity: golden Redis records (tools/build_from_september.py records ...) converted with nothing hidden
(D = far future) must give the SAME journey files as the released v18 files in the package, on every field v18 reads.
Fields the record does not carry and v18 does not read are listed and skipped (see convert.py).

    python tests/test_convert_parity.py PKG GOLDEN_DIR
PKG = unpacked package model folder (.../cris_v18/model).
"""
import json
import sys
from collections import Counter
from pathlib import Path

import pandas as pd

PKG = Path(sys.argv[1]).resolve()
GOLD = Path(sys.argv[2]).resolve()
SERVICE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PKG)); sys.path.insert(0, str(SERVICE))
import convert as C  # noqa: E402

NOT_CARRIED_TOP = {"train_sub_type", "data_source", "redis_run_id", "source", "destination"}
NOT_CARRIED_ENTRY = {"km_before_corridor"}
NOT_CARRIED_STOP = {"is_ptt_halt", "platform", "distance_km"}

H = C.Habits()
D = pd.Timestamp("2030-01-01")
official = {}
for f in (PKG / "data_v14" / "journeys").glob("*/*.json"):
    r = json.loads(f.read_text(encoding="utf-8"))
    official.setdefault((r["train_no"], r["journey_date"]), []).append(r)

n = same = 0
diffs = Counter()
examples = {}
for g in sorted(GOLD.glob("*.json")):
    rec = json.loads(g.read_text(encoding="utf-8"))
    j, how = C.convert(rec, D, H)
    offs = official.get((rec["train_number"], rec["train_date"]), [])
    if j is None or len(offs) != 1:
        diffs[f"unmatched ({how}, {len(offs)} official)"] += 1
        continue
    o = offs[0]
    n += 1
    bad = []
    for k in set(o) | set(j):
        if k in NOT_CARRIED_TOP or k in ("entry", "stops"):
            continue
        if o.get(k) != j.get(k):
            bad.append(k)
    for k in set(o["entry"]) - NOT_CARRIED_ENTRY:
        if abs(float(o["entry"][k]) - float(j["entry"].get(k) or 0)) > 1e-9:
            bad.append("entry." + k)
    if len(o["stops"]) != len(j["stops"]):
        bad.append("n_stops")
    else:
        for so, sj in zip(o["stops"], j["stops"]):
            for k in set(so) - NOT_CARRIED_STOP:
                a, b = so.get(k), sj.get(k)
                if isinstance(a, float) and isinstance(b, float) and abs(a - b) < 1e-9:
                    continue
                if a != b:
                    bad.append("stop." + k)
    if not bad:
        same += 1
    for b in set(bad):
        diffs[b] += 1
        examples.setdefault(b, f"{rec['run_id']}")
print(f"compared {n} runs: {same} identical on every field v18 reads ({100 * same / max(n, 1):.1f}%)")
for k, v in diffs.most_common():
    print(f"  differs: {k:35s} {v:4d}  e.g. {examples.get(k, '')}")
print("skipped (not carried by the record, not read by v18):", sorted(NOT_CARRIED_TOP | {"entry." + x for x in NOT_CARRIED_ENTRY} | {"stop." + x for x in NOT_CARRIED_STOP}))
sys.exit(0 if same == n and not diffs else 1)
