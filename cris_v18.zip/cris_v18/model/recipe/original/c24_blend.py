"""Behaviour-prior blend (PREREGISTRATION_holdload.md). Writes blended records for the training-day
and validation forecasts; the hold-load correction (c21) is then refitted on the blended
training-day records and applied to the blended validation records.
usage: python c24_blend.py <train_records> <val_records> <name>"""
import json, glob, os, sys, collections, numpy as np
D = r"C:/Users/Akhil/Downloads/HetroGnn4-rollout-fixed-claude/jabalpur_scenario_gnn_v14/data_v14/"
TRAIN_END = "2025-09-21"
ST = {}; by_leg = collections.defaultdict(lambda: collections.defaultdict(list)); legmean = collections.defaultdict(list)
for f in glob.glob(D + "journeys/*/*.json"):
    r = json.load(open(f)); d = os.path.basename(f)[:10]; ST[(r["train_no"], d)] = [s["station_code"] for s in r["stops"]]
    if d >= TRAIN_END: continue
    st = [s for s in r["stops"] if s["has_actual"] and s["arr_delay_min"] is not None]
    for a, b in zip(st, st[1:]):
        inc = b["arr_delay_min"] - a["arr_delay_min"]
        by_leg[(r["train_no"], a["station_code"], b["station_code"])][d].append(inc)
        legmean[(a["station_code"], b["station_code"])].append(inc)
LM = {k: float(np.mean(v)) for k, v in legmean.items()}

def prior_leg(tn, a, b, day):
    """mean change of this train on a->b over training days OTHER than `day`, shrunk to the leg mean"""
    base = LM.get((a, b), 0.0)
    v = [x for dd, L in by_leg.get((tn, a, b), {}).items() if dd != day for x in L]
    return (sum(v) + 3.0 * base) / (len(v) + 3.0)

def prior(tn, cd, k0, k1):
    stl = ST.get((tn, cd))
    if not stl: return None
    return sum(prior_leg(tn, stl[i], stl[i + 1], cd) for i in range(k0, k1))

LB = (0, 30, 60, 90, 120, 180, 240)
def bucket(lead):
    b = int(np.searchsorted(LB, max(lead, 0.0), side="right") - 1); return min(max(b, 0), len(LB) - 2)

def steps(path):
    recs = [x for x in json.load(open(D + path)) if x["already_running"]]
    J = collections.defaultdict(list)
    for x in recs: J[(x["iid"], x["t0"])].append(x)
    out = []
    for (iid, t0), xs in J.items():
        xs.sort(key=lambda x: x["stop_k"]); tn, cd = iid.split("_")
        stl = ST.get((tn, cd))
        prev = None
        for x in xs:
            lp = x["lead_min"] - x["actual"] + x["pred"]            # lead from the FORECAST arrival
            if prev is None:
                pinc = x["pred"] - x["persist"]
                # first forecast stop: the train is somewhere at/after stop k-1 at T0
                pr = prior(tn, cd, x["stop_k"] - 1, x["stop_k"]) if x["stop_k"] >= 1 else None
            else:
                pinc = x["pred"] - prev["pred"]
                pr = prior(tn, cd, prev["stop_k"], x["stop_k"])
            out.append(dict(rec=x, j=(iid, t0), b=bucket(lp), pinc=pinc, prior=pinc if pr is None else pr))
            prev = x
    return out

def blend(S, w):
    by = collections.defaultdict(list)
    for s in S: by[s["j"]].append(s)
    res = []
    for j, ss in by.items():
        cum = ss[0]["rec"]["persist"]
        for s in ss:
            wb = w[s["b"]]; cum += wb * s["pinc"] + (1 - wb) * s["prior"]
            res.append((s, cum))
    return res

TRS = steps(sys.argv[1]); VAS = steps(sys.argv[2]); name = sys.argv[3]
# fit w per bucket on TRAINING-day forecasts, bucket by bucket (earlier buckets fixed first)
w = [1.0] * (len(LB) - 1)
grid = [i / 10 for i in range(11)]
for b in range(len(LB) - 1):
    best = None
    for g in grid:
        ww = list(w); ww[b] = g
        e = [abs(c - s["rec"]["actual"]) for s, c in blend(TRS, ww) if s["b"] == b]
        m = float(np.mean(e)) if e else 0.0
        if best is None or m < best[0]: best = (m, g)
    w[b] = best[1]
print(f"{name}: model weight per lead bucket {list(zip([f'{LB[i]}-{LB[i+1]}' for i in range(len(LB)-1)], w))}  (1 = model only, 0 = behaviour only)")
for path, S, tag in ((sys.argv[1], TRS, "train"), (sys.argv[2], VAS, "val")):
    recs = json.load(open(D + path)); newp = {}
    for s, c in blend(S, w):
        r = s["rec"]; newp[(r["iid"], r["stop_k"], r["t0"])] = c
    for x in recs:
        k = (x["iid"], x["stop_k"], x["t0"])
        if k in newp: x["pred"] = newp[k]
    json.dump(recs, open(D + f"blend_{name}_{tag}.json", "w"))
print(f"wrote blend_{name}_train.json and blend_{name}_val.json")
