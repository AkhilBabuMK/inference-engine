"""Far-ahead expected-hold-load correction (PREREGISTRATION_holdload.md).
Fit on TRAINING-day rollouts only; choose statistic and shrinkage by cross-fitting inside the
training days; apply once to validation. usage: python c21_holdload.py <train_records> <val_records> <name>"""
import json, glob, os, sys, collections, numpy as np
D = r"C:/Users/Akhil/Downloads/HetroGnn4-rollout-fixed-claude/jabalpur_scenario_gnn_v14/data_v14/"
DIR = {}
for f in glob.glob(D + "journeys/*/*.json"):
    r = json.load(open(f)); DIR[f'{r["train_no"]}_{os.path.basename(f)[:10]}'] = r.get("direction", "?")
LB = (0, 30, 60, 90, 120, 180, 240)

def rows(path):
    out = []
    for x in json.load(open(D + path)):
        if not x["already_running"]:
            continue
        lp = x["lead_min"] - x["actual"] + x["pred"]          # lead from the FORECAST arrival (known at T0)
        b = int(np.searchsorted(LB, max(lp, 0.0), side="right") - 1); b = min(max(b, 0), len(LB) - 2)
        out.append(dict(key=(x["iid"], x["stop_k"], x["t0"]), day=x["iid"].split("_")[1], b=b,
                        dir=DIR.get(x["iid"], "?"), st=x["station"], ty=x["train_type"],
                        pred=x["pred"], act=x["actual"], lead=x["lead_min"], tn=x["train_no"]))
    return out

def fit(R, stat, k):
    agg = np.mean if stat == "mean" else np.median
    G = [collections.defaultdict(list) for _ in range(NLEV)]
    for r in R:
        res = r["act"] - r["pred"]
        G[0][(r["b"],)].append(res)
        G[1][(r["b"], r["dir"], r["ty"])].append(res)
        G[2][(r["b"], r["dir"], r["ty"], r["st"])].append(res)
        if NLEV > 3: G[3][(r["b"], r["dir"], r["ty"], r["st"], r["tn"])].append(res)
    T = [{g: (agg(v), len(v)) for g, v in Gi.items()} for Gi in G]
    return T, k

def apply(T, k, r):
    v0, _ = T[0].get((r["b"],), (0.0, 0))
    m1, n1 = T[1].get((r["b"], r["dir"], r["ty"]), (v0, 0)); v1 = (n1 * m1 + k * v0) / (n1 + k)
    m2, n2 = T[2].get((r["b"], r["dir"], r["ty"], r["st"]), (v1, 0)); v2 = (n2 * m2 + k * v1) / (n2 + k)
    if NLEV > 3:
        m3, n3 = T[3].get((r["b"], r["dir"], r["ty"], r["st"], r["tn"]), (v2, 0)); v2 = (n3 * m3 + k * v2) / (n3 + k)
    return r["pred"] + v2

TR = rows(sys.argv[1]); VA = rows(sys.argv[2]); name = sys.argv[3]
NLEV = int(sys.argv[4]) if len(sys.argv) > 4 else 3
days = sorted({r["day"] for r in TR}); folds = [days[i::4] for i in range(4)]
best = None
print(f"{name}: training-day forecast stops {len(TR)} over {len(days)} days | validation stops {len(VA)}")
for stat in ("mean", "median"):
    for k in (5, 20, 80, 320):
        e = []
        for hold in folds:
            tr = [r for r in TR if r["day"] not in hold]; te = [r for r in TR if r["day"] in hold]
            T, kk = fit(tr, stat, k)
            e += [abs(apply(T, kk, r) - r["act"]) for r in te]
        m = float(np.mean(e)); print(f"   cross-fit on training days: stat {stat:6} k {k:4} -> MAE {m:.3f}")
        if best is None or m < best[0]: best = (m, stat, k)
base_cf = float(np.mean([abs(r["pred"] - r["act"]) for r in TR]))
print(f"   uncorrected on training days {base_cf:.3f} | best correction: stat {best[1]}, k {best[2]} ({best[0]:.3f})")
if best[0] >= base_cf:
    print("   -> NO correction beats 'no correction' on the training days: correction NOT applied")
    sys.exit(0)
T, k = fit(TR, best[1], best[2])
corr ={r["key"]: apply(T, k, r) for r in VA}
recs = json.load(open(D + sys.argv[2]))
for x in recs:
    kk = (x["iid"], x["stop_k"], x["t0"])
    if kk in corr: x["pred"] = corr[kk]
json.dump(recs, open(D + f"holdload_{name}.json", "w"))
json.dump({"stat": best[1], "k": best[2], "fit_on": sys.argv[1], "levels": [
    {"|".join(map(str, g)): [float(v[0]), int(v[1])] for g, v in Ti.items()} for Ti in T]},
    open(D + f"holdload_{name}_table.json", "w"))
print(f"   wrote holdload_{name}.json (validation forecasts corrected with the training-day table)")
