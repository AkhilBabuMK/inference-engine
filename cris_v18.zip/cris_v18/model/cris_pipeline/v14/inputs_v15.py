# -*- coding: utf-8 -*-
"""
cris_pipeline/v14/inputs_v15.py
===============================
Input version 15 (STEP 1 of the input correction; plan: scratchpad STEP1_inputs.md).

What changes against v14 inputs, and why (all measured on validation snapshots, 2026-10-01):
  * Every "other trains" input was direction-blind: 48-51% of what overlap / higher-priority / queue
    counted were OPPOSITE-direction trains, which can neither block nor overtake on this double line, and
    the "faster train coming" signal had a real same-line faster train behind only 49% of the times it
    fired. v15 counts SAME-direction trains only.
  * The model had no input for the train in FRONT of it on its line, nor for a faster train BEHIND it on its
    line. A stalled train ahead moved its followers' forecast by 5% of what block working requires. v15
    adds both, from positions and clock ETAs known at t.
  * Dead / duplicate inputs (ev_has_next_jct constant, ev_queue_ahead == queue_ahead) are dropped, standing
    time is no longer capped at 45 min, and the per-section run time / slowness come from the timetable and
    training days instead of a topology value that was off by up to 8x.

Direction is the direction of the CURRENT LEG (sign of next station id - current id; ids run STA=0 ... JBP=21),
never the train's label: 4 runs in 32 days are round trips under one label.

Everything here reads only what build_snapshot already knows at t (positions, causal ETAs, observed delays,
timetable). Nothing reads a future timestamp.
"""
from __future__ import annotations

import json
import math
from collections import defaultdict
from pathlib import Path

HORIZON_MIN = 75.0                 # same horizon as the path ETAs they are built from
WINDOW_MIN = 20.0                  # "two trains at the same station within" (PRECEDENCE_WINDOW_MIN)
PRIORITY_MARGIN = 0.05
QUEUE_MIN = 15.0
FAST_BEHIND_WINDOW_MIN = 60.0
AHEAD_LINK_MIN = 30.0
# Graph v16 (step 3) needs to know WHICH trains are ahead / catching, not only their facts. Off: v15 snapshots unchanged.
RECORD_PAIRS = False

STATS_PATH = None                  # set by load_section_stats(); kept for the dataset meta
_SEC = None                        # {"a,b": {"booked_run": min, "slow": {"DN": r, "UP": r}}}


# ── section statistics (fitted on TRAINING days only) ─────────────────────────────────────────────

def fit_section_stats(journeys_dir: Path, fit_end: str, out_path: Path) -> dict:
    """Per section (undirected key 'lo,hi'): median BOOKED run (timetable) and, per direction, median
    real/booked run ratio. Only journeys whose corridor date is before fit_end are read."""
    booked = defaultdict(list)
    ratio = defaultdict(lambda: defaultdict(list))
    for train_dir in sorted(Path(journeys_dir).iterdir()):
        if not train_dir.is_dir():
            continue
        for f in sorted(train_dir.glob("*.json")):
            rec = json.loads(f.read_text(encoding="utf-8"))
            if rec.get("corridor_date", "9999") >= fit_end:
                continue
            st = rec.get("stops") or []
            for a, b in zip(st, st[1:]):
                ia, ib = a.get("station_id"), b.get("station_id")
                sd, sa = a.get("sched_dep_min", a.get("sched_arr_min")), b.get("sched_arr_min")
                if ia is None or ib is None or sd is None or sa is None or ia == ib:
                    continue
                bk = float(sa) - float(sd)
                if 0.5 <= bk <= 60.0:
                    booked[f"{min(ia, ib)},{max(ia, ib)}"].append(bk)
            # Slowness over consecutive REPORTED stops. Block posts never report, so a run is measured
            # between the stations on either side (e.g. BUU -> UDR across GNWA) and the ratio is given to
            # every section it spans; otherwise those sections would silently stay at 1.0.
            rep = [s for s in st if s.get("has_actual") and s.get("station_id") is not None]
            for a, b in zip(rep, rep[1:]):
                ia, ib = int(a["station_id"]), int(b["station_id"])
                sd, sa = a.get("sched_dep_min", a.get("sched_arr_min")), b.get("sched_arr_min")
                ad, aa = a.get("actual_dep_min"), b.get("actual_arr_min")
                if ia == ib or abs(ib - ia) > 3 or None in (sd, sa, ad, aa):
                    continue
                bk, real = float(sa) - float(sd), float(aa) - float(ad)
                if not (0.5 <= bk <= 60.0 and 0.5 <= real <= 180.0):
                    continue
                d = "DN" if ib > ia else "UP"
                lo, hi = min(ia, ib), max(ia, ib)
                for x in range(lo, hi):
                    ratio[f"{x},{x + 1}"][d].append(real / bk)
    med = lambda v: sorted(v)[len(v) // 2]
    out = {k: {"booked_run": round(med(v), 2),
               "slow": {d: round(med(r), 3) for d, r in ratio[k].items() if len(r) >= 30},
               "n": len(v)}
           for k, v in booked.items()}
    out["_meta"] = {"fit_end": fit_end, "rule": "median booked run; median real/booked per direction (n>=30)"}
    Path(out_path).write_text(json.dumps(out, indent=1), encoding="utf-8")
    return out


def load_section_stats(path: Path) -> dict:
    global _SEC, STATS_PATH
    _SEC = json.loads(Path(path).read_text(encoding="utf-8"))
    STATS_PATH = str(path)
    return _SEC


def _need_stats() -> dict:
    # A missing table must never silently turn every slowness into 1.0: the model would then see different
    # inputs in a forecast than it was trained on.
    if _SEC is None:
        raise RuntimeError("input v15: section statistics not loaded (load_section_stats / set_input_v15)")
    return _SEC


def stats_sha256(path: Path) -> str:
    import hashlib
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def section_booked_run(a: int, b: int, fallback: float) -> float:
    s = _need_stats().get(f"{min(a, b)},{max(a, b)}")
    return float(s["booked_run"]) if s else float(fallback)


def section_slowness(a: int, b: int) -> float:
    """Median real/booked running-time ratio on a->b in THIS direction (1.0 if unknown)."""
    s = _need_stats().get(f"{min(a, b)},{max(a, b)}")
    if not s:
        return 1.0
    return float(s["slow"].get("DN" if b > a else "UP", 1.0))


# ── per-train same-direction inputs ───────────────────────────────────────────────────────────────

def leg_sign(cur: int, nxt, label: str) -> int:
    """+1 travelling towards higher station ids (DN), -1 towards lower (UP)."""
    if nxt is not None and nxt != cur:
        return 1 if nxt > cur else -1
    return 1 if label == "DN" else -1


def augment(nodes: list, by_iid: dict) -> None:
    """Add the v15 fields to every train node, in place. Needs the private '_petas' list each node carries
    during build_snapshot (station -> clock ETA, current station at ETA 0 while standing)."""
    info = []
    for n in nodes:
        inst = by_iid[n["instance_id"]]
        s = leg_sign(n["current_station"], n["next_station"], inst["direction"])
        transit = bool(n["mode_in_transit"])
        prog = s * (float(n["current_station"]) + (0.5 * s if transit else 0.0))
        # how far this train is over its plan RIGHT NOW: standing past its booked dwell, or running past
        # its booked run. Both are clock minus timetable, known at t.
        if transit:
            over = float(n.get("minutes_over_scheduled_run", 0.0))
        else:
            st = inst["stops"][n["stop_idx"]]
            booked = max(0.0, float(st["sched_dep_abs"]) - float(st["sched_arr_abs"]))
            over = max(0.0, float(n.get("time_at_stop_min", 0.0)) - booked)
        info.append((s, prog, dict(n["_petas"]), float(n["priority"]), over, not transit, float(n["delay_min"])))
        n["v15_leg_sign"] = s
        nxt = n["next_station"]
        n["v15_next_slowness"] = section_slowness(n["current_station"], nxt) if nxt is not None else 1.0

    for i, a in enumerate(nodes):
        sa, pa, ea, pra, _, _, da = info[i]
        c = defaultdict(float)
        jct_gap = 90.0
        prec = HORIZON_MIN
        ahead = None                     # (distance, j)
        fast = []                        # (min_gap, passes, stops_until, prio_delta, j)
        upcoming = sorted(ea.items(), key=lambda kv: kv[1])
        for j, b in enumerate(nodes):
            if j == i:
                continue
            sb, pb, eb, prb, overb, standb, db = info[j]
            if sb != sa:
                continue                                  # the other line: cannot block or overtake here
            for s, x in ea.items():
                y = eb.get(s)
                if y is None:
                    continue
                if abs(x - y) <= WINDOW_MIN:
                    c["overlap"] += 1
                    if b["train_group"] == a["train_group"]:
                        c["same_group"] += 1
                    if prb > pra + PRIORITY_MARGIN:
                        c["hp"] += 1
                        if pb < pa:                       # comes from BEHIND on my line
                            prec = min(prec, x)
                if 0.0 <= (y - x) <= QUEUE_MIN:
                    c["queue"] += 1
                if s in _JUNCTIONS:
                    jct_gap = min(jct_gap, abs(x - y))
            if pb > pa and (ahead is None or pb - pa < ahead[0]):
                ahead = (pb - pa, j)
            if pb < pa and prb > pra + PRIORITY_MARGIN:
                gaps = [(k, eb[s] - x) for k, (s, x) in enumerate(upcoming) if s in eb]
                if gaps:
                    mg = min(g for _, g in gaps)
                    first = next((k for k, g in gaps if g < 0), None)
                    fast.append((mg, first is not None, first if first is not None else 10, prb - pra, j))
        a["v15_overlap"] = c["overlap"]
        a["v15_same_group_overlap"] = c["same_group"]
        a["v15_hp_overlap"] = c["hp"]
        a["v15_queue_ahead"] = c["queue"]
        a["v15_jct_gap"] = jct_gap
        a["v15_precedence_eta"] = prec
        # train AHEAD on my line
        if ahead is not None:
            j = ahead[1]
            _, _, eb, prb, overb, standb, db = info[j]
            com = next(((s, x) for s, x in upcoming if s in eb), None)
            a["v15_ahead_found"] = 1
            a["v15_ahead_gap"] = (com[1] - eb[com[0]]) if com else HORIZON_MIN
            a["v15_ahead_standing"] = int(standb)
            a["v15_ahead_overstay"] = overb
            a["v15_ahead_prio_delta"] = prb - pra
            a["v15_ahead_delay_delta"] = db - da
        else:
            a.update(v15_ahead_found=0, v15_ahead_gap=HORIZON_MIN, v15_ahead_standing=0, v15_ahead_overstay=0.0,
                     v15_ahead_prio_delta=0.0, v15_ahead_delay_delta=0.0)
        # faster train BEHIND on my line (the one closest to catching me)
        if fast:
            mg, passes, k, dp, _ = min(fast, key=lambda f: f[0])
            a.update(v15_fast_found=1, v15_fast_min_gap=mg, v15_fast_passes=int(passes),
                     v15_fast_stops_until=k, v15_fast_prio_delta=dp,
                     v15_fast_n60=sum(1 for f in fast if f[0] <= FAST_BEHIND_WINDOW_MIN))
        else:
            a.update(v15_fast_found=0, v15_fast_min_gap=HORIZON_MIN, v15_fast_passes=0, v15_fast_stops_until=10,
                     v15_fast_prio_delta=0.0, v15_fast_n60=0)
        if RECORD_PAIRS:
            # Graph v16: WHICH trains can physically act on this one, for direct train->train links.
            # ahead_of: the nearest train in front on my line, only if I would reach a station we both still have to
            #           reach within AHEAD_LINK_MIN of it (otherwise it cannot block me in the next stop or two).
            # catches:  every faster train behind on my line projected within FAST_BEHIND_WINDOW_MIN of me.
            a["v16_ahead"] = None
            if ahead is not None and a["v15_ahead_gap"] <= AHEAD_LINK_MIN:
                a["v16_ahead"] = {"iid": nodes[ahead[1]]["instance_id"], "gap": a["v15_ahead_gap"],
                                  "standing": a["v15_ahead_standing"], "overstay": a["v15_ahead_overstay"],
                                  "prio_delta": a["v15_ahead_prio_delta"], "delay_delta": a["v15_ahead_delay_delta"]}
            a["v16_catches"] = [{"iid": nodes[f[4]]["instance_id"], "min_gap": f[0], "passes": int(f[1]),
                                 "stops_until": f[2], "prio_delta": f[3]}
                                for f in sorted(fast, key=lambda f: f[0]) if f[0] <= FAST_BEHIND_WINDOW_MIN]


_JUNCTIONS: set = set()


def set_junctions(ids) -> None:
    global _JUNCTIONS
    _JUNCTIONS = set(ids)


# ── the v15 train input vector ────────────────────────────────────────────────────────────────────
# Positions 0-16 and 22-37 keep their v14 meaning (and scaling) except where marked CHANGED.
# Junction-event inputs: v14 positions 38-45 had a constant (44) and a duplicate of queue_ahead (41);
# the remaining six are kept, computed with SAME-direction conflict edges only.

V15_LABELS = [
    "delay_log", "delay_velocity", "eta_next", "eta_nearest_jct", "eta_second_jct", "jcts_remaining",
    "priority", "speed_dev", "stops_remaining", "route_progress", "in_transit", "at_booked_halt",
    "time_at_stop(CHANGED /60 cap 3)", "mins_since_departure", "mins_over_sched_run", "min_arr_delay_next",
    "n_coaches",
    "sd_overlap", "sd_same_group_overlap", "sd_higher_prio_overlap", "sd_queue_ahead", "sd_jct_gap_urgency",
    "freight_in_section", "freight_at_station", "freight_approaching",
    "section_disrupted", "next_section_slowness(CHANGED)", "entry_delay", "entry_trend", "has_upstream",
    "tod_sin", "tod_cos", "delay_observed", "sd_precedence_from_behind", "next_booked_halt", "next_sched_dwell",
    "next_allowance", "slack_ahead",
    "ev_jct_conflicts", "ev_higher_prio", "ev_min_gap", "ev_max_prio_delta",
    "ahead_found", "ahead_gap", "ahead_standing", "ahead_overstay", "ahead_prio_delta", "ahead_delay_delta",
    "fast_found", "fast_min_gap", "fast_passes", "fast_stops_until", "fast_prio_delta", "fast_n60",
]
V15_DIM = len(V15_LABELS)            # 54
# of scenario_events.event_features: drop 3 (= queue_ahead) and 6 (constant). Also drop 1 and 7 (cross-branch):
# with opposite-direction pairs removed they are 0 for every train (STEP1 check P6) -- in v14 the "cross-branch
# junction conflict" was entirely opposite-direction traffic, never a real branch conflict.
EVENT_KEEP = (0, 2, 4, 5)


def train_vector(n: dict, ev_row, f, slog, eta_norm) -> list:
    """`f`, `slog`, `eta_norm` are dataset_cris's own helpers, so shared positions scale identically."""
    th = math.tanh
    v = [
        slog(f(n.get("delay_min"))),
        th(f(n.get("delay_velocity")) / 5.0),
        eta_norm(n.get("eta_next_min")),
        eta_norm(n.get("eta_nearest_jct_min")),
        eta_norm(n.get("eta_second_jct_min")),
        min(f(n.get("jcts_remaining")) / 4.0, 1.0),
        f(n.get("priority"), 0.5),
        max(-1.0, min(1.0, f(n.get("speed_factor"), 1.0) - 1.0)),
        min(f(n.get("stops_remaining")) / 19.0, 1.0),
        f(n.get("route_progress_norm")),
        f(n.get("mode_in_transit")),
        f(n.get("at_booked_halt")),
        min(f(n.get("time_at_stop_min")) / 60.0, 3.0),                      # CHANGED: up to 180 min
        min(f(n.get("minutes_since_departure")) / 60.0, 1.5),
        min(f(n.get("minutes_over_scheduled_run")) / 30.0, 1.5),
        th(f(n.get("minimum_arrival_delay_next")) / 30.0),
        min(f(n.get("n_coaches")) / 24.0, 1.5),
        # same-direction counts: v14 divided by 6 and capped at 1.5 and saturated for 55-57% of trains;
        # with opposite-direction trains gone the counts halve, /6 is kept and the cap raised to 2.0
        min(f(n.get("v15_overlap")) / 6.0, 2.0),
        min(f(n.get("v15_same_group_overlap")) / 6.0, 2.0),
        min(f(n.get("v15_hp_overlap")) / 6.0, 2.0),
        min(f(n.get("v15_queue_ahead")) / 6.0, 2.0),
        1.0 - min(f(n.get("v15_jct_gap"), 90.0) / 90.0, 1.0),
        min(f(n.get("freight_in_section")) / 2.0, 1.5),
        min(f(n.get("freight_at_station")) / 3.0, 1.5),
        min(f(n.get("freight_approaching_next")) / 3.0, 1.5),
        f(n.get("section_disrupted")),
        min(f(n.get("v15_next_slowness"), 1.0) - 1.0, 2.0),                 # CHANGED: measured, my direction
        slog(f(n.get("entry_delay_min"))),
        th(f(n.get("entry_trend_min")) / 15.0),
        f(n.get("has_upstream")),
        f(n.get("tod_sin")),
        f(n.get("tod_cos"), 1.0),
        f(n.get("delay_observed"), 1.0),
        1.0 - min(f(n.get("v15_precedence_eta"), HORIZON_MIN) / HORIZON_MIN, 1.0),
        f(n.get("next_booked_halt")),
        min(f(n.get("next_sched_dwell_min")) / 10.0, 1.5),
        min(f(n.get("next_allowance_min")) / 10.0, 1.5),
        min(f(n.get("slack_ahead_min")) / 30.0, 1.5),
    ]
    v += [float(ev_row[k]) for k in EVENT_KEEP]
    v += [
        f(n.get("v15_ahead_found")),
        th(f(n.get("v15_ahead_gap"), HORIZON_MIN) / 20.0),          # minutes behind the train ahead; <0 = closing past it
        f(n.get("v15_ahead_standing")),
        min(f(n.get("v15_ahead_overstay")) / 30.0, 3.0),
        max(-1.0, min(1.0, f(n.get("v15_ahead_prio_delta")))),
        slog(f(n.get("v15_ahead_delay_delta"))),                   # -374..+400 min: signed log, not tanh
        f(n.get("v15_fast_found")),
        th(f(n.get("v15_fast_min_gap"), HORIZON_MIN) / 20.0),       # <0 = projected to pass me
        f(n.get("v15_fast_passes")),
        min(f(n.get("v15_fast_stops_until"), 10.0) / 10.0, 1.0),
        max(-1.0, min(1.0, f(n.get("v15_fast_prio_delta")))),
        min(f(n.get("v15_fast_n60")) / 3.0, 2.0),
    ]
    assert len(v) == V15_DIM, (len(v), V15_DIM)
    return v
