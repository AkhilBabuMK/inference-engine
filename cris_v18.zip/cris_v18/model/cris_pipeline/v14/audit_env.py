# -*- coding: utf-8 -*-
"""
cris_pipeline/v14/audit_env.py
==============================
Lets the existing leak audits (audit_causality, audit_raw_causality,
audit_trace_reads) run against the v14 data layer with `--v14`:

  * v14 journeys / topology / dataset paths
  * the v14 stores (FreightStore, EventStore) instead of the v13 overlays
  * the standing-delay convention the v14 dataset was BUILT with, read from
    its meta.json -- the audits used to run with the module default (off),
    so they audited a convention the v13 dataset did not use.
"""

from __future__ import annotations

import json

from .. import build_dataset as BD
from .settings import DATASET_DIR, JOURNEYS_DIR, TOPOLOGY_PATH


class _NoDetention:
    """v14 does not attach detention records to instances (nothing reads them)."""

    def get(self, *_a, **_k):
        return {}


def apply(args) -> tuple:
    """Point `args` at v14 and return (freight, disrupt, detent)."""
    args.journeys, args.topology, args.dataset = (
        str(JOURNEYS_DIR), str(TOPOLOGY_PATH), str(DATASET_DIR))
    meta = json.loads((DATASET_DIR / "meta.json").read_text(encoding="utf-8"))
    BD.HONEST_STANDING_DELAY = bool(meta.get("honest_standing_delay", False))
    BD.CLOCK_ETAS = bool(meta.get("clock_etas", False))
    BD._init_topology(json.loads(TOPOLOGY_PATH.read_text(encoding="utf-8")))
    from .events import EventStore
    from .freight import FreightStore
    pairs = {(int(s["from_id"]), int(s["to_id"])) for s in BD._SECTIONS.values()}
    print(f"  [v14] journeys/topology/dataset from data_v14; honest standing delay "
          f"{BD.HONEST_STANDING_DELAY}; clock ETAs {BD.CLOCK_ETAS}; FreightStore + EventStore")
    return FreightStore.load(), EventStore.load(pairs), _NoDetention()
