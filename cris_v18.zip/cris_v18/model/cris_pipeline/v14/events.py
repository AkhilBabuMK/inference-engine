# -*- coding: utf-8 -*-
"""
cris_pipeline/v14/events.py
===========================
Maintenance blocks, asset failures and speed restrictions, answered "as of"
a moment of knowledge.

Drop-in for overlays.DisruptionOverlay: same `state(date, key, minute)` call
returning (is_disrupted, run_multiplier), plus two things it never had:

  direction   a maintenance block closes ONE line. Trains are told about a
              block only if it is on their own line. (Section nodes, which
              stand for both lines, still see any block -- the per-line graph
              is stage 1.) Asset failures carry no direction in the register,
              so they apply to both lines.

  as_of       the moment knowledge stops. Training snapshots leave it None,
              meaning "now" = the snapshot time. A forecast issued at T0 sets
              it to T0, and every tick after T0 is then answered from what was
              known at T0 -- planned windows and projections, never the real
              clearance or real end.

KNOWLEDGE RULES (settings.py records the two that are choices)
  maintenance  known from its PLANNED start minus one day (pre-planned).
               Observed at t <= K: active iff start <= t < actual clearance.
               Projected at t  > K: if it had cleared by K, it is over;
               otherwise it runs to max(planned end, K).
  failure      known from its START (FAILURE_KNOWN_FROM="start") or its log
               time ("recorded"). Observed: active iff start <= t < end.
               Projected: over if it ended by K; else it lasts the training-
               period median duration from its start (at least until K).
               The true end is never read in a projection.
               Either way a failure counts only in its first FAILURE_EFFECT_MIN
               (60) minutes -- measured on training days, the effect on
               passenger trains is 2x in hour one and noise after 3 h, while
               register tickets stay open for days (settings.py).
  TSR          all 14 corridor restrictions were in force all month; the
               multiplier is the v13 one, unchanged.

Severity is 1.0 for every active event. v13 scaled failures by
`affected_trains`, a count made AFTER the event -- that input is removed.

Why "observed" may compare t with a real clearance time: at time t a
controller can see whether the block is still on. `t < clearance` is a fact
about the present; it does not reveal WHEN it will clear, and the overlay
perturbation audit proves it: shifting any clearance that lies beyond K leaves
every answer unchanged.
"""

from __future__ import annotations

from collections import defaultdict

import pandas as pd

from ..config import CORRIDOR_ORDER, MAINT_CSV
from ..overlays import DisruptionOverlay
from .baselines import load_baselines
from .settings import (FAILURE_EFFECT_MIN, FAILURE_KNOWN_FROM,
                       MAINTENANCE_KNOWN_FROM, ONTOLOGY_BUILD)

CODE_TO_ID = {c: i for i, c in enumerate(CORRIDOR_ORDER)}
DAY = pd.Timedelta(days=1)
_MAINT_FMT = "%d-%m-%y %H:%M:%S"


def _key(section_key: str) -> str:
    a, b = section_key.split("-")
    i, j = CODE_TO_ID[a], CODE_TO_ID[b]
    return f"{min(i, j)},{max(i, j)}"


class EventStore:
    directional = True       # build_snapshot passes the train's direction

    def __init__(self) -> None:
        self.by_key: dict[str, list[dict]] = defaultdict(list)
        self.tsr_multiplier: dict[str, float] = {}
        self.as_of: pd.Timestamp | None = None
        self.failure_median = pd.Timedelta(minutes=13.0)
        self.failure_cap = pd.Timedelta(minutes=FAILURE_EFFECT_MIN)
        self.n_blocks = self.n_failures = 0

    # ── loading ───────────────────────────────────────────────────────────────

    @classmethod
    def load(cls, section_pairs: set) -> "EventStore":
        st = cls()
        b = load_baselines()
        st.failure_median = pd.Timedelta(minutes=b["failure_duration_median_min"])

        d = pd.read_csv(ONTOLOGY_BUILD / "disruption.csv", low_memory=False)
        d = d[d.on_corridor.astype(bool)].copy()
        for c in ("started_at", "ended_at", "recorded_at"):
            d[c] = pd.to_datetime(d[c], errors="coerce")
        secs = pd.read_csv(ONTOLOGY_BUILD / "disruption_section.csv")
        keys = secs.groupby("disruption_id").section_key.apply(list).to_dict()

        raw = pd.read_csv(MAINT_CSV, low_memory=False)
        for r in d.itertuples():
            ks = [_key(k) for k in keys.get(r.disruption_id, [])]
            if not ks or pd.isna(r.started_at):
                continue
            if r.register == "maintenance_block":
                row = raw.iloc[int(r.source_row)]
                p_start = pd.to_datetime(row.permitted_start_time, format=_MAINT_FMT, errors="coerce")
                p_end = pd.to_datetime(row.permitted_end_time, format=_MAINT_FMT, errors="coerce")
                if pd.isna(p_start) or p_start != r.started_at:
                    continue        # 3 rows with no permitted window: cannot plan them
                ev = {"kind": "maintenance",
                      "line": r.line_direction if r.line_direction in ("UP", "DN") else None,
                      "start": p_start,
                      "planned_end": p_end if pd.notna(p_end) else p_start + pd.Timedelta(minutes=30),
                      "end": r.ended_at if pd.notna(r.ended_at) else p_end,
                      "known_from": (p_start - DAY if MAINTENANCE_KNOWN_FROM == "planned"
                                     else r.recorded_at)}
                st.n_blocks += 1
            else:
                end = (r.ended_at if pd.notna(r.ended_at) and r.ended_at > r.started_at
                       else r.started_at + pd.Timedelta(minutes=30))     # v13's default
                ev = {"kind": "failure", "line": None, "start": r.started_at, "end": end,
                      "known_from": (r.started_at if FAILURE_KNOWN_FROM == "start"
                                     else r.recorded_at)}
                st.n_failures += 1
            if pd.isna(ev["known_from"]):
                continue
            for k in ks:
                st.by_key[k].append(ev)

        # TSR: identical to v13 (all in force all month).
        legacy = DisruptionOverlay()
        legacy._load_tsr(section_pairs)
        st.tsr_multiplier = dict(legacy.tsr_multiplier)
        return st

    # ── the rule ──────────────────────────────────────────────────────────────

    def _active(self, e: dict, t: pd.Timestamp, K: pd.Timestamp) -> bool:
        if K < e["known_from"]:
            return False                                   # not known yet
        if t < e["start"]:
            return False
        if e["kind"] == "failure" and t >= e["start"] + self.failure_cap:
            return False                                   # past its first hour (settings)
        if t <= K:                                         # observed present
            return t < e["end"]
        # projection: t is after the moment knowledge stops
        if e["end"] <= K:
            return False                                   # it was over by K
        if e["kind"] == "maintenance":
            return t < max(e["planned_end"], K)
        return t < max(e["start"] + self.failure_median, K)

    def state(self, date: str, key: str, minute: float,
              direction: str | None = None) -> tuple[float, float]:
        t = pd.Timestamp(date) + pd.Timedelta(minutes=float(minute))
        K = t if self.as_of is None or t <= self.as_of else self.as_of
        sev = 0.0
        for e in self.by_key.get(key, ()):
            if direction is not None and e["line"] is not None and e["line"] != direction:
                continue                                   # the other line
            if self._active(e, t, K):
                sev = 1.0
                break
        mult = self.tsr_multiplier.get(key, 1.0)
        if sev > 0.0:
            mult = max(mult, 1.0 + sev)
        return sev, mult
