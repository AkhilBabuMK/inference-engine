# -*- coding: utf-8 -*-
"""
cris_pipeline/v14/baselines.py
==============================
Every statistic v14 LEARNS from data, fitted on the training period only.

The ontology's own baselines (station p80, section medians, type bands) were
fitted on all 30 days, test days included. Used as model inputs they would
hand the model a "normal" that already knows how the test days went. So v14
refits what it needs here, and every fit passes through
settings.assert_fit_window, which raises on a single row at or after FIT_END.

Stage 0 needs only the GOODS travel times the freight projection uses. They
are fitted exactly as measured in m9 (the numbers the freeze-90 decision rests
on), so the projection in freight.py behaves the way it was measured:

    goods_run[(from, to)]   median actual minutes, departure -> next arrival
    goods_dwell[station]    median actual minutes, arrival -> departure
    goods_run_all / goods_dwell_all   pooled medians, fallback for unseen keys

A goods leg or dwell counts toward the fit only if it ENDS before FIT_END, so
no fitted value contains a validation-period timestamp.

    python -m cris_pipeline.v14.baselines
"""

from __future__ import annotations

import json

import numpy as np
import pandas as pd

from .settings import (BASELINES_PATH, FIT_END, ONTOLOGY_BUILD, V14_DIR,
                       assert_fit_window, check_pinned_build)

M = pd.Timedelta(minutes=1)


def load_goods_stops() -> pd.DataFrame:
    g = pd.read_csv(ONTOLOGY_BUILD / "goods_stop.csv", low_memory=False)
    for c in ("sched_arrival", "actual_arrival", "sched_departure", "actual_departure"):
        g[c] = pd.to_datetime(g[c], errors="coerce")
    return g.sort_values(["goods_run_id", "stop_seq"]).reset_index(drop=True)


def fit_goods(g: pd.DataFrame) -> dict:
    run, dwell = {}, {}
    run_end, dwell_end = [], []
    for _, r in g.groupby("goods_run_id", sort=False):
        st = r.station_code.to_list()
        aa, ad = r.actual_arrival.to_list(), r.actual_departure.to_list()
        for i in range(len(r)):
            if pd.notna(aa[i]) and pd.notna(ad[i]) and ad[i] >= aa[i] and ad[i] < FIT_END:
                dwell.setdefault(st[i], []).append((ad[i] - aa[i]) / M)
                dwell_end.append(ad[i])
            if (i + 1 < len(r) and pd.notna(ad[i]) and pd.notna(aa[i + 1])
                    and aa[i + 1] > ad[i] and aa[i + 1] < FIT_END):
                run.setdefault(f"{st[i]}>{st[i + 1]}", []).append((aa[i + 1] - ad[i]) / M)
                run_end.append(aa[i + 1])
    assert_fit_window(pd.Series(run_end), "goods_run")
    assert_fit_window(pd.Series(dwell_end), "goods_dwell")
    return {
        "goods_run": {k: float(np.median(v)) for k, v in run.items()},
        "goods_dwell": {k: float(np.median(v)) for k, v in dwell.items()},
        "goods_run_all": float(np.median(sum(run.values(), []))),
        "goods_dwell_all": float(np.median(sum(dwell.values(), []))),
        "n_goods_run": sum(map(len, run.values())),
        "n_goods_dwell": sum(map(len, dwell.values())),
        "fit_end": str(FIT_END),
        "latest_event_used": str(max(run_end + dwell_end)),
    }


def fit_failure_duration() -> dict:
    """Median asset-failure duration, from failures that ENDED before FIT_END.

    Used only inside a forecast: a failure already active at the forecast
    moment T0 has an end nobody knows yet, so it is projected to last this
    long from its start. Its true end is never an input (settings.py).
    """
    d = pd.read_csv(ONTOLOGY_BUILD / "disruption.csv", low_memory=False)
    d = d[d.on_corridor.astype(bool) & (d.register == "asset_failure")]
    s, e = pd.to_datetime(d.started_at), pd.to_datetime(d.ended_at)
    ok = s.notna() & e.notna() & (e > s) & (e < FIT_END)
    assert_fit_window(e[ok], "failure_duration")
    return {"failure_duration_median_min": float(((e - s)[ok] / M).median()),
            "n_failures_fit": int(ok.sum()),
            "latest_failure_end_used": str(e[ok].max())}


def load_baselines() -> dict:
    b = json.loads(BASELINES_PATH.read_text(encoding="utf-8"))
    if (pd.Timestamp(b["latest_event_used"]) >= FIT_END
            or pd.Timestamp(b["latest_failure_end_used"]) >= FIT_END):
        raise AssertionError("LEAK: stored baselines contain a post-FIT_END event")
    return b


def main() -> None:
    check_pinned_build()
    V14_DIR.mkdir(parents=True, exist_ok=True)
    b = fit_goods(load_goods_stops()) | fit_failure_duration()
    print(f"failure duration median {b['failure_duration_median_min']:.1f} min "
          f"({b['n_failures_fit']} failures, latest end {b['latest_failure_end_used']})")
    BASELINES_PATH.write_text(json.dumps(b, indent=1), encoding="utf-8")
    print(f"goods baselines: {len(b['goods_run'])} legs ({b['n_goods_run']:,} runs), "
          f"{len(b['goods_dwell'])} stations ({b['n_goods_dwell']:,} dwells)")
    print(f"  pooled medians: run {b['goods_run_all']:.1f} min, dwell {b['goods_dwell_all']:.1f} min")
    print(f"  latest event used {b['latest_event_used']}  (must be < {FIT_END})")


if __name__ == "__main__":
    main()
