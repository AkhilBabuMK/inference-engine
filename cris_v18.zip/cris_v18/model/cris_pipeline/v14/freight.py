# -*- coding: utf-8 -*-
"""
cris_pipeline/v14/freight.py
============================
Goods-train occupancy, answered "as of" a moment of knowledge K.

Drop-in for overlays.FreightOverlay: same section_count / station_count /
approaching_count calls. Goods are never forecast targets; only the space
they occupy matters to passenger trains.

ONE LOCATOR FOR BOTH MODES
Observed occupancy (t <= K) and projected occupancy (t > K) come from the same
code over the same table (ontology goods_stop), so at t == K they agree
exactly -- tested, not assumed. An earlier version read the observed layer
from goods_leg and projected from goods_stop; the two tables describe goods
movements differently and disagreed on 7.1% of counts at the forecast moment.

WHAT IS READ AT TIME t (observed, K = t)
  standing   arrival <= t <= departure, with departure > arrival
  moving     departure <= t <= next arrival
These are facts about the present: whether a train has left, or has arrived
yet, is visible at t. WHICH piece of a multi-section jump a moving train is on
(goods never report at block posts, and sometimes skip stations) is estimated
from its departure and the training-period median running time for that jump
-- NOT from its actual arrival. v13's overlay used the actual arrival to cut
the jump, which reads the future; this does not.

PROJECTION (t > K), from each train's state at K only
  lag <= FREIGHT_FREEZE_MIN (90): standing trains stay; moving trains continue
    on median running and dwell times.
  lag  > 90: all trains continue on the medians (a standing one leaves after
    its station's median dwell, or at K if that has passed).
Measured (m9) as the most accurate of four rules at every horizon; this module
reproduces m9's numbers (55.9 / 40.9 / 30.1 / 54.7% at 30/60/120/240 min).
Goods not yet on the corridor at K are unknown and absent.

Known limitation (as v13): a train is placed only between two RECORDED events
(97.6% of goods arrivals are recorded). A run whose records stop is not
carried forward as a ghost.
"""

from __future__ import annotations

from collections import defaultdict

import pandas as pd

from ..config import CORRIDOR_ORDER
from .baselines import load_baselines, load_goods_stops
from .settings import FREIGHT_FREEZE_MIN, ONTOLOGY_BUILD

CODE_TO_ID = {c: i for i, c in enumerate(CORRIDOR_ORDER)}
M = pd.Timedelta(minutes=1)


def _k(a: str, b: str) -> str:
    i, j = CODE_TO_ID[a], CODE_TO_ID[b]
    return f"{min(i, j)},{max(i, j)}"


class FreightStore:
    def __init__(self) -> None:
        self.as_of: pd.Timestamp | None = None
        self.runs: list[dict] = []
        self.by_day: dict = defaultdict(list)
        self._cache_key = None
        self._cache = None
        self.n_runs = 0

    # ── loading ───────────────────────────────────────────────────────────────

    @classmethod
    def load(cls) -> "FreightStore":
        st = cls()
        b = load_baselines()
        st.run_med, st.dwell_med = b["goods_run"], b["goods_dwell"]
        st.run_all, st.dwell_all = b["goods_run_all"], b["goods_dwell_all"]
        sec = pd.read_csv(ONTOLOGY_BUILD / "section.csv")
        st.km = {r.section_key: float(r.distance_km) for r in sec.itertuples()}

        g = load_goods_stops()
        for _, r in g.groupby("goods_run_id", sort=False):
            aa, ad = r.actual_arrival.to_list(), r.actual_departure.to_list()
            times = [x for x in aa + ad if pd.notna(x)]
            if not times:
                continue
            run = {"codes": r.station_code.to_list(), "aa": aa, "ad": ad}
            st.runs.append(run)
            for d in pd.date_range(min(times).normalize(), max(times).normalize()):
                st.by_day[d].append(run)
        st.n_runs = len(st.runs)
        return st

    # ── one train ─────────────────────────────────────────────────────────────

    def _state_at(self, run: dict, K: pd.Timestamp):
        """('arr', i, arrival) standing at stop i, ('dep', i, departure) moving
        from stop i, or None. Reads only whether events have happened by K."""
        aa, ad = run["aa"], run["ad"]
        for i in range(len(aa)):
            if pd.notna(aa[i]) and pd.notna(ad[i]) and ad[i] > aa[i] and aa[i] <= K <= ad[i]:
                return ("arr", i, aa[i])
            if (i + 1 < len(aa) and pd.notna(ad[i]) and pd.notna(aa[i + 1])
                    and aa[i + 1] >= ad[i] and ad[i] <= K <= aa[i + 1]):
                return ("dep", i, ad[i])
        return None

    def _run_min(self, a: str, b: str) -> float:
        return self.run_med.get(f"{a}>{b}", self.run_all)

    def _dwell_min(self, a: str) -> float:
        return self.dwell_med.get(a, self.dwell_all)

    def _timeline(self, run, state, K, standing_moves: bool):
        """[(code, arr, dep)] from the state at K, on median times. dep None = frozen."""
        kind, i, t = state
        codes = run["codes"]
        if kind == "arr":
            if not standing_moves:
                return [(codes[i], t, None)]
            dep = max(t + pd.Timedelta(minutes=self._dwell_min(codes[i])), K)
            out = [(codes[i], t, dep)]
        else:
            dep = t
            out = [(codes[i], None, dep)]
        for k in range(i + 1, len(codes)):
            arr = dep + pd.Timedelta(minutes=self._run_min(codes[k - 1], codes[k]))
            if kind == "dep" and k == i + 1:
                # Moving at K means NOT arrived by K -- an observed fact. A
                # slower-than-median train must not be placed ahead of it.
                arr = max(arr, K + pd.Timedelta(seconds=1))
            dep = arr + pd.Timedelta(minutes=self._dwell_min(codes[k]))
            out.append((codes[k], arr, dep))
        return out

    def _pieces(self, a: str, b: str):
        i, j = CODE_TO_ID[a], CODE_TO_ID[b]
        step = 1 if j > i else -1
        p = [(CORRIDOR_ORDER[k], CORRIDOR_ORDER[k + step]) for k in range(i, j, step)]
        km = [self.km.get(f"{x}-{y}", self.km.get(f"{y}-{x}", 1.0)) for x, y in p]
        return p, km

    def _piece(self, a: str, b: str, frac: float):
        """The real section a train is on, `frac` of the way through a jump."""
        if a == b:
            return ("stn", a)          # the register lists one station twice in a row
        p, km = self._pieces(a, b)
        frac, acc, tot = min(max(frac, 0.0), 1.0), 0.0, sum(km)
        for (x, y), w in zip(p, km):
            acc += w
            if frac <= acc / tot + 1e-12:
                return ("sec", x, y)
        return ("sec", *p[-1])

    def _locate(self, run, state, K, t):
        """Location at t >= K from the state at K. At t == K this is the
        observed location, because the first moving leg is cut by median run
        time in both modes."""
        lag = (t - K) / M
        tl = self._timeline(run, state, K, standing_moves=lag > FREIGHT_FREEZE_MIN)
        for n, (code, arr, dep) in enumerate(tl):
            if dep is None:
                return ("stn", code)
            if arr is not None and t < arr:
                a, d0 = tl[n - 1][0], tl[n - 1][2]
                frac = (t - d0) / (arr - d0) if arr > d0 else 0.0
                return self._piece(a, code, frac)
            if t <= dep:
                return ("stn", code)
        return None                                     # beyond the corridor

    # ── counts ────────────────────────────────────────────────────────────────

    def _counts(self, t: pd.Timestamp, K: pd.Timestamp):
        ck = (K, t)
        if self._cache_key == ck:
            return self._cache
        sec, stn, inb = defaultdict(int), defaultdict(int), defaultdict(int)
        for run in self.by_day.get(K.normalize(), ()):
            s = self._state_at(run, K)
            if s is None:
                continue
            loc = self._locate(run, s, K, t)
            if loc is None:
                continue
            if loc[0] == "stn":
                stn[CODE_TO_ID[loc[1]]] += 1
            else:
                sec[_k(loc[1], loc[2])] += 1
                inb[CODE_TO_ID[loc[2]]] += 1           # far end, in travel order
        self._cache_key, self._cache = ck, (sec, stn, inb)
        return self._cache

    def _when(self, date: str, minute: float):
        t = pd.Timestamp(date) + pd.Timedelta(minutes=float(minute))
        K = t if self.as_of is None or t <= self.as_of else self.as_of
        return t, K

    def section_count(self, date: str, key: str, minute: float) -> int:
        return self._counts(*self._when(date, minute))[0].get(key, 0)

    def station_count(self, date: str, sid: int, minute: float) -> int:
        return self._counts(*self._when(date, minute))[1].get(sid, 0)

    def approaching_count(self, date: str, sid: int, minute: float,
                          window: float = 45.0) -> int:
        return self._counts(*self._when(date, minute))[2].get(sid, 0)
