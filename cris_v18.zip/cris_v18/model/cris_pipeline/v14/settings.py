# -*- coding: utf-8 -*-
"""
cris_pipeline/v14/settings.py
=============================
Every v14 decision that is a CHOICE rather than a fact lives here, named, so a
checkpoint can record exactly what it was built under.

Stage 0 of the ontology-grounded rebuild: the data layer only. The model,
feature widths and file formats are unchanged; what changes is where the data
comes from and what each input is allowed to know at the moment it is read.

THE ONE RULE EVERYTHING HERE ENFORCES
    A value may be read at time t only if it was knowable at time t.
    In a training snapshot "now" is t itself. In a forecast issued at T0,
    every tick after T0 may know only what was knowable at T0 (`as_of`).
"""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from ..config import PROJECT_DIR, REPO_ROOT

# ── Where things are ──────────────────────────────────────────────────────────

# The production checkout. READ ONLY from v14 -- nothing below writes there.
PROD_DIR = REPO_ROOT / "jabalpur_scenario_gnn"

# The ontology build this data layer is pinned to. Pinned, not "latest":
# a rebuild of the ontology must never silently change a trained model's data.
ONTOLOGY_DIR = REPO_ROOT / "corridor_ontology" / "objects"
ONTOLOGY_VERSION = "20260929T082110Z"
ONTOLOGY_BUILD = ONTOLOGY_DIR / ONTOLOGY_VERSION

# The verified ground truth (two official workbooks, 8/8 checks, 0 disagreements
# with CRIS to the minute, seconds kept). Corridor stops only.
GROUND_TRUTH_CSV = REPO_ROOT / "corridor_analytics" / "out" / "ground_truth_passenger.csv"

# The production topology, copied (never edited) into the v14 output folder.
PROD_TOPOLOGY = PROD_DIR / "data_cris" / "topology_jbp_sta_cris.json"

# Everything v14 writes.
V14_DIR = PROJECT_DIR / "data_v14"
TOPOLOGY_PATH = V14_DIR / "topology_jbp_sta_cris.json"
JOURNEYS_DIR = V14_DIR / "journeys"
DATASET_DIR = V14_DIR / "dataset"
BASELINES_PATH = V14_DIR / "baselines.json"

# ── The split — identical to v13, so every comparison is like for like ────────

TRAIN_DAYS = ("2025-09-02", "2025-09-20")
VAL_DAYS = ("2025-09-21", "2025-09-25")
TEST_DAYS = ("2025-09-26", "2025-09-30")

# Anything FITTED from data (a median, a percentile, a travel-time table) may
# only see events strictly before this instant. Validation starts here.
FIT_END = pd.Timestamp("2025-09-21 00:00:00")

# ── Named choices (the user's decisions, 2026-09-29) ──────────────────────────

# Asset failures: KNOWN FROM THEIR START TIME. The register logs them a median
# 449 min after they start, so by the log timestamp the model would almost
# never see one in time. The user chose start-time knowledge, which assumes
# the controller learns of a failure as it happens. This is an ASSUMPTION about
# operations, not a measured fact -- it is recorded in every checkpoint.
#
# Hard limit that holds either way: a failure's END time is never an input.
# At time t the model may know "a failure is active here"; it may not know
# when it will be over.
FAILURE_KNOWN_FROM = "start"          # "start" | "recorded"

# A failure affects traffic only in its FIRST HOUR. Measured on training days
# only (m10): a passenger leg through the failure's section loses 3.95 min in
# the first hour after start vs 1.93 on the same section at the same hour on
# other days (2x); 1-3 h: 2.57 vs 2.15; after 3 h: 1.33 vs 1.14 (noise, over
# 2,874 legs). The register holds tickets open for days -- 99th percentile
# duration 38 days, e.g. a 12-hour "failure" at KTE that was a lobby hooter
# test -- and without this cap 7% of train nodes were flagged disrupted.
# Causal: minutes since START are known at t; the duration is not.
FAILURE_EFFECT_MIN = 60.0

# Maintenance blocks: PRE-PLANNED, so the PLANNED window (permitted start/end)
# is known in advance. The ACTUAL clearance is known only once it has happened.
# Each block applies only to trains running on its own line (direction).
MAINTENANCE_KNOWN_FROM = "planned"    # "planned" | "recorded"

# Freight after the forecast moment. Measured (m9, days >= 09-22, fit on
# earlier days): freeze is right 55.6% at 30 min / 40.6% at 60 min; typical
# travel time wins beyond ~2 h (54.7% at 4 h). Timetable+carried was worst
# (11.9% at 30 min). So: freeze for the first 90 minutes, then travel time.
FREIGHT_FREEZE_MIN = 90.0


# ETAs to upcoming stations measured FROM NOW (build_dataset.CLOCK_ETAS). v13
# measured them from each train's own booked departure, so two trains' ETAs
# at one station were on different clocks: for trains meeting within 20 min
# the old form got their order right 54.9% of the time, the clock form 87.1%.
CLOCK_ETAS = True


def settings_record() -> dict:
    """What a dataset / checkpoint must carry so it can be reproduced."""
    return {
        "ontology_version": ONTOLOGY_VERSION,
        "ground_truth": str(GROUND_TRUTH_CSV.name),
        "fit_end": str(FIT_END),
        "failure_known_from": FAILURE_KNOWN_FROM,
        "failure_effect_min": FAILURE_EFFECT_MIN,
        "maintenance_known_from": MAINTENANCE_KNOWN_FROM,
        "freight_freeze_min": FREIGHT_FREEZE_MIN,
        "clock_etas": CLOCK_ETAS,
        "split": {"train": TRAIN_DAYS, "validation": VAL_DAYS, "test": TEST_DAYS},
    }


def check_pinned_build() -> dict:
    """Refuse to run against anything but the pinned ontology build."""
    man = json.loads((ONTOLOGY_BUILD / "manifest.json").read_text(encoding="utf-8"))
    if man.get("version") != ONTOLOGY_VERSION:
        raise SystemExit(f"ontology build mismatch: manifest says {man.get('version')}, "
                         f"v14 is pinned to {ONTOLOGY_VERSION}")
    return man


def assert_fit_window(times: pd.Series, what: str) -> None:
    """Every fitted statistic calls this on the timestamps it learned from.

    A baseline that saw a validation or test day is a leak: the model would be
    handed a 'normal' value that already knows how those days went.
    """
    t = pd.to_datetime(times, errors="coerce").dropna()
    if len(t) == 0:
        raise ValueError(f"{what}: fitted on zero rows")
    late = int((t >= FIT_END).sum())
    if late:
        raise AssertionError(f"LEAK: {what} was fitted on {late} rows at or after "
                             f"{FIT_END} (validation/test period)")
