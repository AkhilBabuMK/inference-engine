# -*- coding: utf-8 -*-
"""
cris_pipeline/v14/timeline.py
=============================
ONE CONTINUOUS TIMELINE ACROSS MIDNIGHT (the "midnight fix", switched on by
--midnight in build_dataset_v14 and rollout_cris; off by default, so every
existing dataset, checkpoint and forecast is unchanged).

The problem it fixes. A journey is filed under its corridor date (the day of
its FIRST actual corridor arrival), and every day was built on its own:

    day D's snapshots   = D's own trains, 00:00-23:57 of D
    day D+1's snapshots = D+1's own trains, 00:00-23:57 of D+1

A train that entered at 23:30 on D and runs until 05:00 is therefore in NO
snapshot after midnight: not in D's (they stop at 23:57), not in D+1's (it is
not D+1's train). Measured on the 29 days (scratch c66_midnight_cut.py):
84% of the trains really on the corridor are missing at 00h, 61% at 01h, 29%
at 02h; 3,857 of 40,398 real arrivals (9.5%) happen with the train in no
snapshot, so they are never a lesson. Holds peak at night, so the model saw
night holds with the trains that caused them missing.

The same cut was in the forecast world (rollout_cris): a day's replay held only
that day's trains, and a forecast issued late in the evening stopped
simulating at 23:57 -- and, had it run on, build_snapshot would have read
freight/disruptions at "date D, minute t % 1440", i.e. the PREVIOUS morning.

The fix, in one rule: a moment t sees every train whose corridor span covers
t, whatever its corridor date; the date used for overlays is the date of t.
Day files keep their shape (snapshots of one calendar day) so the trainer,
splits and scoring code are untouched; a file now also lists the trains of
other corridor dates that are on the corridor during its day (flagged
"carried_over": mostly the evening before; also 10 runs whose untimed first
stop is filled from the timetable a few hours before their own date).

Day numbers are CALENDAR offsets from the first kept date, so they equal the
old list positions on these consecutive days (checked) and the day before the
first kept date is -1.
"""

from __future__ import annotations

import datetime as dt

LINGER_MIN = 30.0       # build_dataset._find_position shows a train 30 min past its last departure


def day_number(date: str, first: str) -> int:
    return (dt.date.fromisoformat(date) - dt.date.fromisoformat(first)).days


def date_at(t: float, first: str) -> str:
    """Calendar date of absolute minute t (day 0 = `first`)."""
    return (dt.date.fromisoformat(first) + dt.timedelta(days=int(t // 1440))).isoformat()


def day_meta_at(t: float, first: str) -> dict:
    return {"day_of_week": dt.date.fromisoformat(date_at(t, first)).weekday()}


def check_consecutive(dates: list[str]) -> None:
    """Old code used the list position as the day number; the timeline uses the
    calendar. They agree only if no kept day is missing in between."""
    bad = [d for i, d in enumerate(dates) if day_number(d, dates[0]) != i]
    if bad:
        raise SystemExit(f"midnight timeline needs consecutive dates; gap before {bad[0]}")


MERGED_GAP_MIN = 720.0  # consecutive corridor stops this far apart are two trips filed as one run


def span(inst: dict) -> tuple[float, float]:
    """First and last minute the snapshot builder can show this train.

    Four journeys in the v14 journey files join two trips days apart under one
    run (00150_2025-09-08 and 00151_2025-09-15: up, then back ~3 days later;
    00935_2025-09-10/-17: two timetable-only trips ~8 days apart). Per-day
    building never showed the second trip (it lay outside the run's own day);
    a continuous timeline would carry the run as a phantom for days. The span
    stops at the first such gap, which keeps exactly what v14 showed."""
    st = inst["stops"]
    end = float(st[-1]["actual_dep_abs"])
    for a, b in zip(st, st[1:]):
        if float(b["actual_arr_abs"]) - float(a["actual_dep_abs"]) > MERGED_GAP_MIN:
            end = float(a["actual_dep_abs"])
            break
    return float(st[0]["actual_arr_abs"]), end + LINGER_MIN


def overlapping(instances, lo: float, hi: float) -> list[dict]:
    """Trains whose visible span meets [lo, hi]."""
    out = []
    for i in instances:
        a, b = span(i)
        if a <= hi and b >= lo:
            out.append(i)
    return out


RUN_ID_FIX = False      # --run-id-fix (needs --midnight): unique run ids + merged trips split


def build_own(BD, by_date: dict, date: str, first: str) -> list[dict]:
    """A corridor date's own instances, placed on the calendar timeline.

    RUN_ID_FIX: the run id "train_corridordate" is shared by two runs 20 times
    (a train entering just after midnight and again late the same day). The
    journey files already tell them apart ("2025-09-23#2.json"), so the id
    takes the file name: unchanged for every other run, "#2" for the second.
    And the 4 journeys that join two trips days apart (see span) are split at
    the gap; the later trip becomes its own run "<id>#t2"."""
    n = day_number(date, first)
    out = []
    for r in by_date.get(date, []):
        i = BD._build_instance(r, n)
        if not i:
            continue
        if RUN_ID_FIX:
            i["instance_id"] = f"{i['train_no']}_{r.get('_stem', i['corridor_date'])}"
            out += _split_trips(i)
        else:
            out.append(i)
    return out


def _split_trips(inst: dict) -> list[dict]:
    st = inst["stops"]
    for k in range(1, len(st)):
        if float(st[k]["actual_arr_abs"]) - float(st[k - 1]["actual_dep_abs"]) > MERGED_GAP_MIN:
            a = dict(inst, stops=st[:k], route=[s["station"] for s in st[:k]])
            b = dict(inst, stops=st[k:], route=[s["station"] for s in st[k:]],
                     instance_id=inst["instance_id"] + "#t2")
            return [a] + _split_trips(b)
    return [inst]
