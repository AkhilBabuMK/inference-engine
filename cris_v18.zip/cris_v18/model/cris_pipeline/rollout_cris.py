# -*- coding: utf-8 -*-
"""
cris_pipeline/rollout_cris.py
=============================
TRUE autoregressive rollout — the honest multi-hop metric.

`eval_cris.py` section 2 is NOT this. It scores the one-step p50 against hop-h
targets while every input still comes from ground truth, so a model that only
ever learned "delay stays roughly the same" scores well there. This module
instead hands the model its own predictions and never shows it the future.

METHOD
------
At a decision time T0 the model has seen the real day up to T0 and nothing
after it. From T0 onward the train's own predictions are written back into its
journey — arrival delay, departure delay, and therefore the wall-clock times
that decide where it sits in the graph — and the snapshot is rebuilt from that
forecast world. Feeding predictions back through `build_snapshot` rather than
patching feature tensors is deliberate: the rollout then exercises the exact
code path training used, so a divergence between the two is impossible by
construction rather than by review.

Errors compound the way they would in service: a hop-3 prediction rests on the
hop-1 and hop-2 predictions that placed the train there.

WHAT IS AND IS NOT ASSUMED KNOWN AFTER T0
-----------------------------------------
  known    : the working timetable, and planned exogenous events (maintenance
             blocks, TSRs, freight paths). A controller has these at T0.
  predicted: every corridor arrival and departure of every train present, and
             hence all occupancy, congestion and conflict state derived from
             them. No observed delay after T0 reaches the model.
  caveat   : a train that has not yet entered the corridor at T0 is taken over
             at its first corridor stop using its true entry delay. Corridor
             entry is set outside this corridor and this model does not claim
             to predict it. Those events are reported separately as
             `entered later` so the strict already-running subset can be read
             on its own — that subset is the number to quote.

    python -m cris_pipeline.rollout_cris --checkpoint data_cris/corridor_nextevent.pt
    python -m cris_pipeline.rollout_cris --checkpoint ... --show 6
"""

from __future__ import annotations

import argparse
import copy
import datetime as dt
import json
import math
import sys
from collections import defaultdict
from pathlib import Path

import torch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from cris_pipeline.config import (                                   # noqa: E402
    JOURNEYS_DIR, TOPOLOGY_PATH, DATASET_DIR, OUT_DIR,
)
from cris_pipeline import build_dataset as BD                        # noqa: E402
from cris_pipeline.v14 import timeline as TL                        # noqa: E402
from cris_pipeline.dataset_cris import (                             # noqa: E402
    CrisDataset, match_checkpoint_features,
)
from cris_pipeline.model_cris import (                               # noqa: E402
    CorridorNextEventGNN, load_weights, check_feature_dims,
)
from cris_pipeline.overlays import (                                 # noqa: E402
    FreightOverlay, DisruptionOverlay, DetentionOverlay,
)

HORIZON_MIN = 240                       # forecast 4 h ahead, as the old system
DIAG_ORACLE_FREIGHT = False             # --diag-oracle-freight (reads the future; diagnosis only)
DIAG_WORLD = None                       # --diag-dump-world: list of forecast-world trajectories
LEARN = None                            # --practice-out: PracticeLearner (v14 rollout fine-tune)
MIDNIGHT_WARM_MIN = 180                 # --midnight: minutes of the previous evening replayed (features only)


class PracticeLearner:
    """Learn from the model's OWN forecast world (v14 rollout fine-tune).

    At every simulated tick each train's label is its TRUE delay at the next
    station minus its SIMULATED current delay -- "from where you think you
    are, this is where reality went". Labels read the truth; inputs are the
    forecast world exactly as a scored rollout builds it. Same losses and
    weights as train_cris (arrival change; dwell extension at half weight),
    truncated BPTT over TBPTT_K ticks, memory detached at every step."""

    def __init__(self, model, lr: float, tbptt: int = 8, far_weight: float = 0.0):
        from cris_pipeline import train_cris as TC
        self.TC = TC
        self.model = model
        self.opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)
        self.k = tbptt
        # weight = 1 + far_weight * hours since T0: predictions deep into a
        # forecast are where the shortfall is, and they are the minority.
        self.far_weight = float(far_weight)
        self.window = []
        self.n_lab = 0
        self.sum_lab = self.sum_pred = self.sum_abs = 0.0
        self.steps = 0

    def step(self, data, out, snap, ro, used_js):
        nodes = snap["train_nodes"]
        n = len(nodes)
        lab = torch.zeros(n); m = torch.zeros(n)
        ext = torch.zeros(n); me = torch.zeros(n)
        for j in used_js:
            nd = nodes[j]
            T = ro.truth.get(nd["instance_id"])
            if T is None or not T.get("target_eligible"):
                continue
            k = int(nd["stop_idx"]) + 1
            if k >= len(T["stops"]):
                continue
            s = T["stops"][k]
            if not (s.get("is_target") and s.get("has_actual") and s.get("arr_delay") is not None):
                continue
            lab[j] = float(s["arr_delay"]) - float(nd["delay_min"])
            m[j] = 1.0
            if s.get("dep_delay") is not None:
                ext[j] = float(s["dep_delay"]) - float(s["arr_delay"])
                me[j] = 1.0
        if m.sum() < 1:
            return
        from cris_pipeline.model_cris import regression_loss as RL
        TC = self.TC
        hrs = max(0.0, float(snap["timestamp_abs_min"]) - float(ro.cur_t0)) / 60.0
        fw = 1.0 + self.far_weight * hrs
        loss = RL(out["next_arr"], lab, m, TC._weights(lab) * fw)
        dep = out.get("next_dep_expected", out["next_dep"])
        dw = (1.0 + (TC.HOLD_WEIGHT - 1.0) * (ext.abs() > 5.0).float()) * fw
        loss = loss + TC.DEP_LOSS_WEIGHT * RL(dep, ext, me, dw)
        self.window.append(loss)
        with torch.no_grad():
            sel = m > 0.5
            self.n_lab += int(sel.sum())
            self.sum_lab += float(lab[sel].sum())
            self.sum_pred += float(out["next_arr"][sel].sum())
            self.sum_abs += float((out["next_arr"][sel] - lab[sel]).abs().sum())
        if len(self.window) >= self.k:
            self.flush()

    def flush(self):
        if not self.window:
            return
        (sum(self.window) / len(self.window)).backward()
        torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
        self.opt.step()
        self.opt.zero_grad(set_to_none=True)
        self.window.clear()
        self.model.detach_memory()
        self.steps += 1

    def report(self) -> str:
        n = max(self.n_lab, 1)
        return (f"practice: {self.steps} optimiser steps, {self.n_lab} labelled train-ticks | "
                f"mean label {self.sum_lab/n:+.3f}  mean prediction {self.sum_pred/n:+.3f}  "
                f"MAE {self.sum_abs/n:.3f}")
LEAD_BUCKETS = [(0, 30), (30, 60), (60, 120), (120, 240)]
SPIKE = 30.0


# ── Forecast world ────────────────────────────────────────────────────────────

def _write_prediction(stops: list, k: int, arr_delay: float,
                      dep_delay: float) -> tuple[float, bool]:
    """Commit a predicted arrival/departure at stop k into the forecast world.

    Applies the same monotonicity clamp `_build_instance` applies to observed
    data, so a prediction can never place a train before the stop it just left
    (which would corrupt `_find_position` and put it in the wrong section).
    Returns the effective arrival delay and whether the clamp bound.
    """
    s = stops[k]
    raw_arr_abs = s["sched_arr_abs"] + arr_delay
    arr_abs = raw_arr_abs
    if k > 0:
        arr_abs = max(arr_abs, stops[k - 1]["actual_dep_abs"])
    clamped = arr_abs > raw_arr_abs + 1e-9

    dep_abs = max(s["sched_dep_abs"] + dep_delay, arr_abs)
    eff_arr = arr_abs - s["sched_arr_abs"]

    s["actual_arr_abs"] = arr_abs
    s["actual_dep_abs"] = dep_abs
    s["arr_delay"] = eff_arr
    s["dep_delay"] = dep_abs - s["sched_dep_abs"]
    s["delay_est"] = eff_arr
    # The rollout treats its own prediction as the observation it is standing
    # in for. Leaving this False would tell the model "this figure is inferred,
    # discount it" at every predicted stop — an input combination that never
    # occurs in training, so it would measure distribution shift, not skill.
    s["has_actual"] = True
    return eff_arr, clamped


def _state_copy(st: BD._StationState) -> BD._StationState:
    c = BD._StationState()
    c.cong = defaultdict(float, st.cong)
    c.crit = defaultdict(bool, st.crit)
    c.steps = defaultdict(int, st.steps)
    return c


class StateCheck:
    """Compares forecast-world node features against the ground-truth world at
    the same tick, so 'are the features actually being updated' is answerable
    with numbers instead of by reading the writer.

    Reported per feature: the mean in each world. A feature that is correct by
    construction (time of day) must match exactly; one that depends on
    predicted positions will drift, and HOW it drifts is the diagnosis.
    """

    def __init__(self, train_labels, station_labels):
        self.tl, self.sl = train_labels, station_labels
        self.f_sum, self.t_sum = None, None
        self.f_n = self.t_n = 0
        self.sf_sum, self.st_sum = None, None
        self.s_n = 0

    def add(self, fdata, tdata):
        fx, tx = fdata["train"].x, tdata["train"].x
        if self.f_sum is None:
            self.f_sum = torch.zeros(fx.shape[1])
            self.t_sum = torch.zeros(tx.shape[1])
        self.f_sum += fx.sum(0)
        self.t_sum += tx.sum(0)
        self.f_n += fx.shape[0]
        self.t_n += tx.shape[0]

        fs, ts = fdata["station"].x, tdata["station"].x
        if self.sf_sum is None:
            self.sf_sum = torch.zeros(fs.shape[1])
            self.st_sum = torch.zeros(ts.shape[1])
        self.sf_sum += fs.sum(0)
        self.st_sum += ts.sum(0)
        self.s_n += fs.shape[0]

    def report(self):
        print("\n\n" + "#" * 78)
        print("# STATE FIDELITY — forecast world vs ground truth at the same tick")
        print("#" * 78)
        print(f"  train nodes: forecast {self.f_n:,}  truth {self.t_n:,}"
              f"   ({100 * self.f_n / max(self.t_n, 1):.1f}% as many)")
        for name, fs, ts, n_f, n_t, labels in (
                ("TRAIN", self.f_sum, self.t_sum, self.f_n, self.t_n, self.tl),
                ("STATION", self.sf_sum, self.st_sum, self.s_n, self.s_n, self.sl)):
            if fs is None:
                continue
            print(f"\n  {name} features        {'forecast':>10} {'truth':>10} "
                  f"{'ratio':>8}")
            print("  " + "-" * 56)
            rows = []
            for j in range(len(fs)):
                a = float(fs[j]) / max(n_f, 1)
                b = float(ts[j]) / max(n_t, 1)
                nm = labels[j] if j < len(labels) else f"dim{j}"
                r = a / b if abs(b) > 1e-6 else (1.0 if abs(a) < 1e-6 else 99.0)
                rows.append((abs(r - 1.0), nm, a, b, r))
            for _, nm, a, b, r in sorted(rows, reverse=True)[:10]:
                flag = "  <-- DRIFT" if abs(r - 1.0) > 0.25 else ""
                print(f"  {nm:<24} {a:>10.4f} {b:>10.4f} {r:>8.2f}x{flag}")


class Rollout:
    """One forecast issued at T0, run forward to T0 + HORIZON_MIN."""

    def __init__(self, model, ds, day_idx, date, day_meta, freight, disrupt,
                 truth_by_iid, state_check=None, dep_mode='absolute',
                 hurdle_tau: float = 1.0, entry_mode: str = 'actual',
                 dep_head: str = 'model', standing_dep: str = 'actual',
                 revise: bool = False, revise_min: float = 0.0,
                 hold_rule=None, predictor=None, expected_hold: bool = False,
                 sample_seed=None, rules=None):
        self.model, self.ds = model, ds
        self.day_idx, self.date, self.day_meta = day_idx, date, day_meta
        self.freight, self.disrupt = freight, disrupt
        self.truth = truth_by_iid
        self.state_check = state_check
        self.dep_mode = dep_mode
        self.hurdle_tau = hurdle_tau
        self.entry_mode = entry_mode
        self.dep_head = dep_head
        self.standing_dep = standing_dep
        self.hold_rule = hold_rule
        self.predictor = predictor
        if standing_dep == "hold" and hold_rule is None:
            raise ValueError("--standing-dep hold needs a HoldRule")
        self.revise = revise
        self.revise_min = revise_min
        self.expected_hold = expected_hold
        self.sample_seed = sample_seed
        self.rules = rules
        self.bcal = None              # --b-calib: set from main
        self.first_date = None        # --midnight: day 0 of the calendar timeline (v14/timeline.py)
        self.inject = None            # --inject: {(iid, t0): (station, release_abs)}, set from main
        self.inject_floor = False     # --inject-floor: release as a "not before" limit, never ADDED to the model
        self.hold_mod = None          # --hold-module: set from main

    def _apply_rules(self, inst, k, pred_arr, pred_dep, sec, stats):
        """--rules: make the forecast world obey two railway rules before stop
        k is written. Delays in, delays out (minutes vs timetable).

        1. No overtaking inside a section: a same-direction train that left
           stop k-1 BEFORE this one must reach stop k first, by at least the
           section's arrival gap.
        2. Departure spacing: this train may not enter section k->k+1 within
           the departure gap of a same-direction train already committed to
           it; it waits until the gap has passed.
        Gaps are training-day 2nd percentiles (v14/headways.py). The dwell the
        model predicted is kept, so a train held back at arrival leaves later
        too. Only ever makes a train LATER, never earlier."""
        st, d, iid = inst["stops"], inst["direction"], inst["instance_id"]
        sk, sp = st[k], st[k - 1]
        arr = float(sk["sched_arr_abs"]) + pred_arr
        dep = float(sk["sched_dep_abs"]) + pred_dep
        dwell = max(dep - arr, 0.0)
        dep_prev = float(sp["actual_dep_abs"])
        key = f'{d}|{sp["station"]}|{sk["station"]}'
        h_a = self.rules["arr_gap"].get(key, self.rules["fallback_arr"])
        new_arr = arr
        for oid, (od, oa) in sec.get(key, {}).items():
            if oid != iid and oa is not None and od < dep_prev and oa + h_a > new_arr:
                new_arr = oa + h_a
        if new_arr > arr:
            stats["arr"] += 1
            stats["min"] += new_arr - arr
        new_dep = max(dep, new_arr + dwell)
        if k + 1 < len(st):
            key2 = f'{d}|{sk["station"]}|{st[k+1]["station"]}'
            h_d = self.rules["dep_gap"].get(key2, self.rules["fallback_dep"])
            others = sorted(od for oid, (od, _) in sec.get(key2, {}).items() if oid != iid)
            before = new_dep
            for od in others:                       # ascending, so one pass settles it
                if abs(new_dep - od) < h_d:
                    new_dep = od + h_d
            if new_dep > before:
                stats["dep"] += 1
                stats["min"] += new_dep - before
        return (new_arr - float(sk["sched_arr_abs"]),
                new_dep - float(sk["sched_dep_abs"]))

    def run(self, t0, instances, st_state, prev_delay):
        """Issue one forecast at t0.

        v14 stores (FreightStore, EventStore) answer "as of" a moment of
        knowledge. For the whole forecast that moment is T0: every tick after
        it sees freight and disruptions only as known at T0 (planned windows,
        projections), never the real future. v13 overlays have no `as_of` and
        are unaffected. Reset in `finally` so the chronological pass that
        continues after this forecast is never left looking at a stale T0.
        """
        import pandas as _pd
        K = (_pd.Timestamp(self.date)
             + _pd.Timedelta(minutes=float(t0 - self.day_idx * 1440)))
        self.cur_t0 = t0
        stores = [s for s in (self.freight, self.disrupt) if hasattr(s, "as_of")]
        if DIAG_ORACLE_FREIGHT:
            # DIAGNOSTIC ONLY -- reads the real future. Measures the most a
            # better freight projection could gain; never a forecast setting.
            stores = [s for s in stores if s is not self.freight]
        for s in stores:
            s.as_of = K
        try:
            return self._run(t0, instances, st_state, prev_delay)
        finally:
            for s in stores:
                s.as_of = None

    def _run(self, t0, instances, st_state, prev_delay):
        """`instances` is already a deep copy owned by this rollout."""
        model = self.model
        by_iid = {i["instance_id"]: i for i in instances}
        routes = {i["instance_id"]: i["route"] for i in instances}

        # Stop each train occupies at T0 — everything after it is predicted.
        takeover, delay_at_t0, standing = {}, {}, {}
        for inst in instances:
            pos = BD._find_position(inst, t0)
            if pos is not None:
                takeover[inst["instance_id"]] = pos["stop_idx"]
                standing[inst["instance_id"]] = pos["mode"] == "at_station"

        # ERASE THE FUTURE from the forecast world.
        #
        # `instances` is a deep copy, but the stops the rollout has not reached
        # yet still hold their TRUE timestamps until a prediction overwrites
        # them. build_snapshot never reads past the current stop (proved by
        # audit_raw_causality), so features were safe — but `_find_position`
        # does read one thing beyond it:
        #
        #     if t > stops[-1]["actual_dep_abs"] + 30: return None
        #
        # In training that is causal: a last-departure lying in the future only
        # tells you "not finished yet", which is knowable at t. In a ROLLOUT it
        # is not, because it governs the forecast world with the TRUE finish
        # time instead of the predicted one — a train left the graph when
        # reality said it was done, not when the forecast said so. 83% of
        # journeys complete inside the 4 h horizon, so this fires often.
        #
        # Pushing unwritten stops to a sentinel far beyond the horizon means
        # the forecast world holds no future information at all: a train stays
        # in the graph until the model's own predictions carry it to its end,
        # and every value the rollout reads is either observed before T0 or
        # predicted by the model. Each prediction overwrites its sentinel as
        # the rollout advances.
        horizon_end = t0 + HORIZON_MIN
        sentinel = horizon_end + 10_000.0
        # A train that has NOT yet entered the corridor at T0 was previously
        # skipped here, so it kept its true timestamps for the whole journey
        # until predictions overwrote them one stop at a time. It is a node in
        # the graph, so its position fed congestion and conflict features to
        # the very trains we score. That is the same shape as the bug fixed
        # above, applied to the other population, and it contradicted the
        # documented assumption -- which grants only the true ENTRY delay, not
        # the whole journey.
        #
        # Careful: `_find_position` returns None for TWO different trains. One
        # has not entered yet; the other already FINISHED before T0. Only the
        # first has a future to erase. Erasing the second resurrects a
        # completed journey, because the "have we finished" test reads
        # stops[-1], which would then be a sentinel that never compares true --
        # measured at 153% of the true train count before this was separated.
        #
        # Measured cost of closing it: STRICT MAE 7.65 -> 7.60, spike recall
        # 82.4% -> 86.0%, train-node fidelity 100.2% of truth. The old numbers
        # were NOT materially optimistic; this is correctness, not a rescue.
        for inst in instances:
            k0 = takeover.get(inst["instance_id"])
            if k0 is None:
                if t0 >= inst["stops"][0]["actual_arr_abs"]:
                    continue                       # already finished: past
                k0 = 0                             # not entered: keep entry only
                # ENTRY MODE. 'actual' hands the rollout the train's TRUE
                # entry time and TRUE entry delay -- both of which lie in the
                # future at T0. Measured on the test days: median 13 min of
                # future information, p90 32 min, 11% over half an hour, and
                # biased (-5 min: trains claw back time on the approach).
                #
                # Training never does this -- build_snapshot drops a train
                # that has not entered, so the weights are clean. It is the
                # simulator alone that is generous.
                #
                # 'timetable' is the opposite extreme: the train is assumed
                # ON TIME to its booked entry with no upstream context at all.
                # Neither mode is what production sees -- production projects
                # entry from the last upstream report before T0 -- but the two
                # BRACKET it, so the gap between them prices the grant before
                # anyone pays for the full projection path.
                if self.entry_mode == "timetable":
                    s0 = inst["stops"][0]
                    if s0.get("sched_arr_abs") is not None:
                        s0["actual_arr_abs"] = float(s0["sched_arr_abs"])
                        s0["actual_dep_abs"] = float(
                            s0.get("sched_dep_abs") or s0["sched_arr_abs"])
                        s0["arr_delay"] = 0.0
                        s0["dep_delay"] = 0.0
                        s0["delay_est_arr"] = 0.0
                        s0["delay_est"] = 0.0
                        # entry_delay_min / upstream_* are all read off the
                        # prefix INCLUDING the part after T0, so they go too.
                        inst["entry"] = {}
            # THE STANDING-DEPARTURE GRANT.
            #
            # The erase below wipes every stop AFTER the one the train
            # occupies. It leaves that stop alone -- correctly for its
            # ARRIVAL, which already happened, but its DEPARTURE has not.
            # `_find_position` reads that departure at every later tick to
            # decide "is this train still on the platform", so the forecast
            # world releases a held train at the exact minute reality did.
            # Measured over trains standing at a decision time: a median of
            # 11 minutes of future knowledge, p90 37, worst 43, on the 22% of
            # forecasts that begin with the train at a platform.
            #
            # Same family as the entry grant, and unlike that one it was never
            # documented. Nothing predicts this departure -- _write_prediction
            # only ever writes stop k+1 -- so closing it needs a rule. The
            # honest one is the timetable: leave when the booked dwell is up,
            # or now if that moment has already passed.
            if (self.standing_dep in ("booked", "hold")
                    and standing.get(inst["instance_id"])):
                s0 = inst["stops"][k0]
                sa, sd = s0.get("sched_arr_abs"), s0.get("sched_dep_abs")
                if sa is not None and sd is not None:
                    booked = max(0.0, float(sd) - float(sa))
                    dep = max(float(s0["actual_arr_abs"]) + booked, float(t0))
                    s0["actual_dep_abs"] = dep
                    s0["dep_delay"] = dep - float(sd)
            for s in inst["stops"][k0 + 1:]:
                s["actual_arr_abs"] = sentinel
                s["actual_dep_abs"] = sentinel
                s["arr_delay"] = None
                s["dep_delay"] = None
                s["has_actual"] = False

        written: set[tuple[str, int]] = set()
        # --rules: section index "dir|a|b" -> {iid: [departure from a, arrival at b]}
        # holding every time the forecast world already knows (observed before
        # T0, or written by an earlier prediction). Sentinels are excluded.
        sec, rule_stats = None, {"arr": 0, "dep": 0, "min": 0.0}
        if self.rules is not None:
            sec = defaultdict(dict)
            for inst in instances:
                st_, d_ = inst["stops"], inst["direction"]
                for i in range(len(st_) - 1):
                    if st_[i]["actual_dep_abs"] >= sentinel - 1:
                        break
                    ab = st_[i + 1]["actual_arr_abs"]
                    sec[f'{d_}|{st_[i]["station"]}|{st_[i+1]["station"]}'][inst["instance_id"]] = [
                        float(st_[i]["actual_dep_abs"]),
                        float(ab) if ab < sentinel - 1 else None]
        # --expected-hold: per train, the expected hold minutes (probability-
        # weighted departure minus the departure actually written) summed over
        # the stops it has left inside this forecast. Added to what is
        # REPORTED at later stops only; the world keeps real stops.
        hold_ledger: dict[str, float] = {}
        # one reproducible random stream per (future, day, decision time)
        mc_gen = None
        if self.sample_seed is not None:
            mc_gen = torch.Generator().manual_seed(
                int(self.sample_seed) * 1_000_003 + int(self.day_idx) * 7_919 + int(t0))
        records, n_clamped = [], 0
        n_hurdle = [0]
        n_extended = [0]
        n_hold_mod = [0]
        n_injected = [0]
        # (iid, k) -> index in `records`. A revised prediction must REPLACE
        # its earlier version, never append: appending would count one
        # forecast event many times and quietly reweight the whole metric
        # toward trains that happened to stand the longest.
        rec_at: dict[tuple[str, int], int] = {}

        # --midnight: a forecast issued in the evening runs on past midnight,
        # and every tick reads freight/disruptions on ITS OWN date. Without it
        # the forecast stops at 23:57 (the old per-day world).
        days = (self.day_idx,) if self.first_date is None else (self.day_idx, self.day_idx + 1)
        ticks = [k * 1440 + m for k in days for m in BD.SNAPSHOT_SCHEDULE
                 if 0 <= (k * 1440 + m) - t0 <= HORIZON_MIN]
        # HOLD RULE (--standing-dep hold, v14/hold_rule.py). A train standing
        # at T0 gets the booked departure above; if the frozen classifier says
        # a same-direction train will pass it here (p >= tau), it leaves at
        # that train's arrival as estimated at T0 + gap instead. Applied once,
        # at T0, from T0 knowledge only. `hold_shift` moves the train's next
        # predicted arrival by the same amount, or the monotonicity clamp
        # would let it "arrive" the instant it departs.
        hold_shift: dict[str, float] = {}
        rule_held: set = set()        # --standing-dep hold: trains the rule kept standing (recorded on rows)
        # --inject (gated overtake hold): for a RUNNING train the frozen
        # overtake detector is >= tau sure will be passed within ~30 min, the
        # departure from the projected hold station is pushed to the projected
        # release (passing convoy's arrival there + fitted gap). Table built
        # from T0 knowledge only (scratch c74_inject_table.py); applied when
        # the rollout first writes that stop, so the delay carries downstream
        # and to every train behind it. Only ever makes a departure LATER.
        inject_at: dict[str, tuple[int, float]] = {}
        arr_floor: dict[str, tuple[int, float]] = {}
        if self.inject is not None:
            for iid_i, inst_i in by_iid.items():
                hit = self.inject.get((iid_i, int(round(t0))))
                if hit is None or iid_i not in takeover:
                    continue
                ks = [kk for kk, ss in enumerate(inst_i["stops"])
                      if kk > takeover[iid_i] and ss.get("station_code") == hit[0]]
                if ks:
                    inject_at[iid_i] = (ks[0], float(hit[1]))
                elif (standing.get(iid_i) and inst_i["stops"][takeover[iid_i]]
                        .get("station_code") == hit[0]):
                    # standing AT the projected hold station now: same move as
                    # the hold rule -- later departure here, next arrival
                    # shifted by the same amount
                    s0 = inst_i["stops"][takeover[iid_i]]
                    old = float(s0["actual_dep_abs"])
                    if float(hit[1]) > old:
                        s0["actual_dep_abs"] = float(hit[1])
                        if s0.get("sched_dep_abs") is not None:
                            s0["dep_delay"] = float(hit[1]) - float(s0["sched_dep_abs"])
                        if self.inject_floor:
                            # FLOOR, not addition (measured 2026-10-09: adding the shift on top of the
                            # model's next arrival double-counted the stand -- held trains went from
                            # ~9 min too early to ~8-11 min too late): next arrival >= release + booked run
                            kn = takeover[iid_i] + 1
                            if kn < len(inst_i["stops"]):
                                sn = inst_i["stops"][kn]
                                run = float(sn["sched_arr_abs"]) - float(s0["sched_dep_abs"] if s0.get("sched_dep_abs") is not None else s0["sched_arr_abs"])
                                arr_floor[iid_i] = (kn, float(hit[1]) + max(run, 0.0))
                        else:
                            hold_shift[iid_i] = hold_shift.get(iid_i, 0.0) + float(hit[1]) - old
                    inject_at[iid_i] = (-1, float(hit[1]))
            n_injected[0] += len(inject_at)
        hold_pending = self.standing_dep == "hold"
        for t in ticks:
            if self.first_date is None:
                date_t, meta_t = self.date, self.day_meta
            else:
                date_t, meta_t = TL.date_at(t, self.first_date), TL.day_meta_at(t, self.first_date)
            snap = BD.build_snapshot(self.day_idx, t, instances, st_state,
                                     meta_t, prev_delay, self.freight,
                                     self.disrupt, date_t)
            if not snap["train_nodes"]:
                continue
            if hold_pending:
                hold_pending = False
                nodes = {nd["instance_id"]: nd for nd in snap["train_nodes"]}
                ids = {i for i, v in standing.items() if v and i in nodes}
                for iid_h, new_dep in self.hold_rule.standing_departures(
                        instances, t, nodes, ids).items():
                    s0 = by_iid[iid_h]["stops"][takeover[iid_h]]
                    old = float(s0["actual_dep_abs"])
                    if new_dep > old:
                        s0["actual_dep_abs"] = new_dep
                        if s0.get("sched_dep_abs") is not None:
                            s0["dep_delay"] = new_dep - float(s0["sched_dep_abs"])
                        hold_shift[iid_h] = new_dep - old
                        rule_held.add(iid_h)
                n_extended[0] += len(hold_shift)
            if self.predictor is not None:
                # A non-GNN predictor (v14/gbm_predictor.py): the same two
                # numbers per train the GNN gives -- next arrival change and
                # next-station dwell extension -- from the same snapshot.
                _p = self.predictor.predict(snap, instances)
                arr_q = [_p.get(nd["instance_id"], (0.0, 0.0))[0] for nd in snap["train_nodes"]]
                dep_q = [_p.get(nd["instance_id"], (0.0, 0.0))[1] for nd in snap["train_nodes"]]
                sp_logit = sp_mag = rem_q = None
            else:
                data = self.ds.materialise(snap, by_iid, routes)
                if data is None or data["train"].x.numel() == 0:
                    continue

                # STATE FIDELITY: build the SAME tick from ground truth and compare.
                # The forecast world is only as good as the state it reconstructs;
                # if predicted trains never stand at platforms, the very condition
                # that creates delay can never recur and the forecast must flatten.
                if self.state_check is not None:
                    # Ground truth for comparison: real positions, not T0 knowledge.
                    _saved = [(s, s.as_of) for s in (self.freight, self.disrupt)
                              if hasattr(s, "as_of")]
                    for s, _ in _saved:
                        s.as_of = None
                    tsnap = BD.build_snapshot(
                        self.day_idx, t, list(self.truth.values()),
                        _state_copy(st_state), meta_t, dict(prev_delay),
                        self.freight, self.disrupt, date_t)
                    for s, v in _saved:
                        s.as_of = v
                    if tsnap["train_nodes"]:
                        tdata = self.ds.materialise(
                            tsnap, self.truth,
                            {k: v["route"] for k, v in self.truth.items()})
                        if tdata is not None and tdata["train"].x.numel():
                            self.state_check.add(data, tdata)

                if LEARN is not None:
                    # PRACTICE MODE (--practice-out): same forward, with
                    # gradients; the learner grades it against the TRUTH and
                    # steps the optimiser. The forecast itself continues from
                    # detached outputs, so the world is built exactly as in a
                    # scored rollout.
                    # Graded AFTER the write loop below, and only on the
                    # predictions this tick actually WRITES into the forecast:
                    # each (train, next stop) is used once, at the first tick
                    # it is seen; later ticks' outputs are discarded.
                    out_grad = model(data, update_memory=True)
                    out = {k_: (v_.detach() if torch.is_tensor(v_) else v_)
                           for k_, v_ in out_grad.items()}
                else:
                    with torch.no_grad():
                        out = model(data, update_memory=True)
                used_js = []
                arr_q = out["next_arr"]
                if self.hold_mod is not None and self.sample_seed is None:
                    # --hold-module (run B): hold chance and hold length from the
                    # SITUATION-ONLY module (v14/hold_module.py, no train identity);
                    # running and normal stops stay with the GNN.
                    hm = self.hold_mod.predict(snap, instances)
                    xs = data["train"].x
                    standing_t = 1.0 - xs[:, 10]
                    booked_t = xs[:, 34]
                    ids = [nd["instance_id"] for nd in snap["train_nodes"]]
                    def _col(i, fallback):
                        return torch.tensor([float(hm[iid][i]) if iid in hm else float(fallback[j])
                                             for j, iid in enumerate(ids)], dtype=out["run"].dtype)
                    pn = _col(0, out["p_next"]); ln = _col(1, out["ext_h"])
                    pc = _col(2, out["p_cur"]); rh = _col(3, out["rem_h"])
                    arr_q = out["run"] + standing_t * ((1 - pc) * out["rem_n"] + pc * rh)
                    held = (pn >= model.hold_tau).float()
                    out = dict(out)
                    out["next_dep"] = held * ln + (1 - held) * booked_t * out["ext_n"]
                    out["next_dep_expected"] = pn * ln + (1 - pn) * booked_t * out["ext_n"]
                    out["next_arr"] = arr_q
                    dep_exp = out["next_dep_expected"] if self.expected_hold else None
                    n_hold_mod[0] += len(hm)
                if self.bcal is not None and self.sample_seed is None:
                    # --b-calib (run B): honest hold probabilities (isotonic) and hold
                    # lengths (scale), fitted on days the model never trained on.
                    import numpy as _np
                    c = self.bcal
                    xs = data["train"].x
                    standing_t = 1.0 - xs[:, 10]
                    booked_t = xs[:, 34]
                    pn = torch.tensor(_np.interp(out["p_next"].numpy(), c["p_next"]["x"], c["p_next"]["y"]),
                                      dtype=out["p_next"].dtype)
                    pc = torch.tensor(_np.interp(out["p_cur"].numpy(), c["p_cur"]["x"], c["p_cur"]["y"]),
                                      dtype=out["p_cur"].dtype)
                    eh = out["ext_h"] * c["ext_h_scale"]
                    arr_q = out["run"] + standing_t * (
                        (1 - pc) * out["rem_n"] + pc * out["rem_h"] * c["rem_h_scale"])
                    held = (pn >= model.hold_tau).float()
                    out = dict(out)
                    out["next_dep"] = held * eh + (1 - held) * booked_t * out["ext_n"]
                    out["next_dep_expected"] = pn * eh + (1 - pn) * booked_t * out["ext_n"]
                    out["next_arr"] = arr_q
                    dep_exp = out["next_dep_expected"] if self.expected_hold else None
                dep_q = out["next_dep"]
                dep_exp = (out.get("next_dep_expected")
                           if self.expected_hold else None)
                if self.sample_seed is not None:
                    # MANY-FUTURES mode (run B): this rollout is ONE sampled
                    # future. Each hold is decided by a draw with the model's
                    # own probability instead of a threshold or an average, so
                    # a held train really stands (and blocks) in this future
                    # and a non-held one does not. Averaging the records of N
                    # futures gives the forecast. Draws use model outputs only.
                    xs = data["train"].x
                    standing_t = 1.0 - xs[:, 10]
                    booked_t = xs[:, 34]
                    u_cur = torch.rand(len(standing_t), generator=mc_gen)
                    u_next = torch.rand(len(standing_t), generator=mc_gen)
                    held_cur = (u_cur < out["p_cur"]).float()
                    held_next = (u_next < out["p_next"]).float()
                    arr_q = out["run"] + standing_t * (
                        held_cur * out["rem_h"] + (1 - held_cur) * out["rem_n"])
                    dep_q = held_next * out["ext_h"] + (1 - held_next) * booked_t * out["ext_n"]
                sp_logit = out.get("spike_logit")
                sp_mag = out.get("spike_mag")

                rem_q = out.get("remaining_dwell") if self.revise else None

            for j, n in enumerate(snap["train_nodes"]):
                iid = n["instance_id"]
                i = int(n["stop_idx"])
                k = i + 1
                inst = by_iid[iid]
                if k >= len(inst["stops"]):
                    continue

                # STANDING: the train is on a platform right now.
                #
                # Two things become possible that were not before.
                #
                # 1. EXTEND THE STAND. A stop's departure is written while the
                #    train is still one stop back, before it has arrived, and
                #    was never revisited -- so a hold beginning after T0 could
                #    not lengthen, the platform freed on schedule, and the
                #    queue behind never formed. `remaining_dwell` answers "how
                #    much longer" from the state on the platform, every tick,
                #    so the train stays because the MODEL keeps saying it will.
                #
                # 2. REVISE THE NEXT ARRIVAL. Today each (train, next stop) is
                #    predicted exactly once, at the first tick the train is
                #    seen -- which for a hold is the one moment the answer is
                #    unknowable. Overwriting while it stands lets the forecast
                #    improve as the evidence arrives, which is what a
                #    controller does.
                #
                # Both stop the moment it departs: once running, the arrival is
                # locked, or predictions would thrash on every tick.
                standing = self.revise and not int(n.get("mode_in_transit", 1))
                if not standing and (iid, k) in written:
                    continue
                # A train first seen after T0 is taken over where it appears.
                if iid not in takeover:
                    takeover[iid] = i
                if i < takeover[iid]:
                    continue

                cur = float(n["delay_min"])
                if iid not in delay_at_t0:
                    delay_at_t0[iid] = cur

                # HURDLE COMBINE. `next_arr` is the ordinary head and is what
                # every model up to v6 used alone. When the classifier clears
                # the threshold we take the magnitude head instead, which was
                # trained only on large changes and so is not dragged toward
                # the quiet answer.
                #
                # The threshold is the dial that used to be buried inside the
                # loss: raise it for fewer false alarms, lower it to catch more.
                # At 1.0 nothing ever fires and this reduces EXACTLY to the
                # pre-hurdle model, which is the degeneracy test.
                delta = float(arr_q[j])
                if sp_logit is not None and self.hurdle_tau < 1.0:
                    p_big = 1.0 / (1.0 + math.exp(-float(sp_logit[j])))
                    if p_big > self.hurdle_tau:
                        delta = float(sp_mag[j])
                        n_hurdle[0] += 1
                pred_arr = cur + delta
                # ABLATION. `next_dep` is trained (at half loss weight, 30,977
                # parameters) but is NOT part of val_mae and is never scored
                # against ground truth anywhere -- its only effect is to set
                # departure times inside the forecast world, which decides how
                # long a train occupies a platform and therefore how much
                # congestion it creates for everyone else.
                #
                # `--dep-head booked` forces the extension to zero, i.e. every
                # train dwells exactly as booked. That is the honest control:
                # if the head earns nothing against it, it is 30k parameters
                # and a loss term doing no work.
                dep_q_j = 0.0 if self.dep_head == "booked" else float(dep_q[j])
                # The dep head means different things in the two regimes;
                # composing them wrongly silently corrupts every rollout.
                pred_dep = (pred_arr + dep_q_j
                            if self.dep_mode == 'extension'
                            else cur + dep_q_j)

                # Extend the stand BEFORE writing the next stop, so the
                # monotonicity clamp inside _write_prediction sees the updated
                # departure and can never place the next arrival before it.
                # REVISION FLOOR. Measured on the test days, the head over-
                # predicts exactly where it does the most damage: on stands
                # with under 3 min left it says 3.65 against a truth of 0.81,
                # and those are 1,185 of 3,540 supervised observations. Because
                # a departure may only ever move LATER (below), every one of
                # those over-guesses is permanent while every correction is
                # discarded -- so across 80 ticks nothing leaves on time.
                # Unfiltered revision scored 12.86 against 7.71, worse than
                # persistence.
                #
                # The floor keeps the mechanism only where it was wanted: a
                # hold long enough to block a platform and queue the trains
                # behind it. Below the floor the departure is left exactly as
                # the unrevised rollout wrote it.
                #
                # 0.0 is a no-op -- `rem` is already clamped non-negative, so
                # the comparison is always true and this reproduces the
                # unfiltered behaviour byte for byte.
                if standing and rem_q is not None:
                    s_here = inst["stops"][i]
                    rem = min(max(float(rem_q[j]), 0.0),
                              BD.MAX_REMAINING_DWELL_MIN)
                    if rem >= self.revise_min:
                        new_dep = float(t) + rem
                        # Only ever push a departure LATER. Letting it move
                        # earlier would rewrite history the forecast has
                        # already acted on -- other trains were held against
                        # this platform being busy.
                        if new_dep > float(s_here["actual_dep_abs"]):
                            cap = (float(s_here["actual_arr_abs"])
                                   + BD.MAX_REMAINING_DWELL_MIN)
                            s_here["actual_dep_abs"] = min(new_dep, cap)
                            if s_here.get("sched_dep_abs") is not None:
                                s_here["dep_delay"] = (
                                    s_here["actual_dep_abs"]
                                    - float(s_here["sched_dep_abs"]))
                            n_extended[0] += 1

                if iid in hold_shift and k == takeover[iid] + 1:
                    d_h = hold_shift.pop(iid)
                    pred_arr += d_h
                    pred_dep += d_h
                first_write = (iid, k) not in written
                if first_write and iid in arr_floor and k == arr_floor[iid][0]:
                    pred_arr = max(pred_arr, arr_floor[iid][1] - float(inst["stops"][k]["sched_arr_abs"]))
                if first_write and iid in inject_at and k == inject_at[iid][0]:
                    pred_dep = max(pred_dep, inject_at[iid][1]
                                   - float(inst["stops"][k]["sched_dep_abs"]))
                if sec is not None and first_write:
                    pred_arr, pred_dep = self._apply_rules(
                        inst, k, pred_arr, pred_dep, sec, rule_stats)
                eff, clamped = _write_prediction(inst["stops"], k,
                                                 pred_arr, pred_dep)
                n_clamped += int(clamped)
                written.add((iid, k))
                if LEARN is not None and first_write:
                    used_js.append(j)
                if sec is not None:
                    st_ = inst["stops"]
                    d_ = inst["direction"]
                    sec[f'{d_}|{st_[k-1]["station"]}|{st_[k]["station"]}'][iid] = [
                        float(st_[k - 1]["actual_dep_abs"]), float(st_[k]["actual_arr_abs"])]
                    if k + 1 < len(st_):
                        sec[f'{d_}|{st_[k]["station"]}|{st_[k+1]["station"]}'][iid] = [
                            float(st_[k]["actual_dep_abs"]), None]
                # Ledger BEFORE this stop's departure: the arrival at k is only
                # affected by holds at stops already left.
                led = hold_ledger.get(iid, 0.0)
                if (dep_exp is not None and first_write
                        and self.dep_head == "model"
                        and self.dep_mode == "extension"):
                    hold_ledger[iid] = led + float(dep_exp[j]) - dep_q_j

                tstops = self.truth[iid]["stops"]
                if k >= len(tstops):
                    continue
                ts = tstops[k]
                if not (ts["is_target"] and ts["has_actual"]
                        and ts["arr_delay"] is not None
                        and self.truth[iid]["target_eligible"]):
                    continue

                row = {
                    "iid": iid,
                    "train_no": self.truth[iid]["train_no"],
                    "train_type": self.truth[iid].get("train_type", ""),
                    "stop_k": k,
                    "station": ts["station_code"],
                    "hop": k - takeover[iid],
                    "lead_min": float(ts["actual_arr_abs"]) - t0,
                    "pred": eff + led,
                    "actual": float(ts["arr_delay"]),
                    # Persistence = the delay this train had at T0, held flat.
                    "persist": delay_at_t0[iid],
                    # Was this train inside the corridor at the decision time?
                    # Tested against TRUTH, since the forecast world has been
                    # rewritten by then. Only these are quoted as the headline.
                    "already_running": BD._find_position(
                        self.truth[iid], t0) is not None,
                    "t0": t0,
                }
                if self.standing_dep == "hold":
                    row["rule_held"] = iid in rule_held
                prev = rec_at.get((iid, k))
                if prev is None:
                    rec_at[(iid, k)] = len(records)
                    records.append(row)
                else:
                    records[prev] = row
            if LEARN is not None and self.predictor is None:
                LEARN.step(data, out_grad, snap, self, used_js)

        if n_extended[0]:
            print(f"    stand extended {n_extended[0]} times", flush=True)
        if n_injected[0]:
            print(f"    injected overtake holds: {n_injected[0]}", flush=True)
        if n_hurdle[0]:
            print(f"    hurdle head fired on {n_hurdle[0]} predictions", flush=True)
        if LEARN is not None:
            LEARN.flush()                       # end of this forecast's window
        if sec is not None:
            print(f"    rules: arrival waits {rule_stats['arr']}, departure waits "
                  f"{rule_stats['dep']}, {rule_stats['min']:.0f} min added", flush=True)
        if DIAG_WORLD is not None:
            # DIAGNOSTIC (--diag-dump-world): every passenger train's forecast-
            # world times after T0 next to the real ones, for the rules test.
            lim = t0 + HORIZON_MIN
            for inst in instances:
                iid = inst["instance_id"]
                tr = self.truth.get(iid)
                if tr is None:
                    continue
                fc, rl = [], []
                for k, s in enumerate(inst["stops"]):
                    if not s.get("has_actual") or s["actual_arr_abs"] >= lim + 5000:
                        continue
                    ts = tr["stops"][k]
                    if s["actual_dep_abs"] < t0 or s["actual_arr_abs"] > lim:
                        continue
                    fc.append((s["station"], round(float(s["actual_arr_abs"]), 2),
                               round(float(s["actual_dep_abs"]), 2)))
                    if ts.get("has_actual"):
                        rl.append((ts["station"], round(float(ts["actual_arr_abs"]), 2),
                                   round(float(ts["actual_dep_abs"]), 2)))
                if fc:
                    DIAG_WORLD.append({"t0": t0, "iid": iid, "dir": inst["direction"],
                                       "prio": inst["priority"], "fc": fc, "real": rl})
        return records, n_clamped


# ── Reporting ─────────────────────────────────────────────────────────────────

def _table(title, rows, keyfn, keys, keyname):
    print("\n" + "=" * 78)
    print(title)
    print("=" * 78)
    print(f"{keyname:>10} {'n':>7} {'MAE':>8} {'persist':>9} {'gain':>8} "
          f"{'bias':>8} {'P90err':>8}")
    for key in keys:
        sel = [r for r in rows if keyfn(r) == key]
        if not sel:
            continue
        n = len(sel)
        errs = sorted(abs(r["pred"] - r["actual"]) for r in sel)
        mae = sum(errs) / n
        per = sum(abs(r["persist"] - r["actual"]) for r in sel) / n
        bias = sum(r["pred"] - r["actual"] for r in sel) / n
        p90 = errs[min(int(0.9 * n), n - 1)]
        print(f"{str(key):>10} {n:>7} {mae:>8.2f} {per:>9.2f} "
              f"{per - mae:>+8.2f} {bias:>+8.2f} {p90:>8.2f}")


def _bucket(v):
    for lo, hi in LEAD_BUCKETS:
        if lo <= v < hi:
            return f"{lo}-{hi}m"
    return None


def report(rows, n_clamped, label):
    if not rows:
        print(f"\n[{label}] no scored events")
        return
    print("\n\n" + "#" * 78)
    print(f"# {label}   ({len(rows):,} forecast events)")
    print("#" * 78)

    _table("MAE BY LEAD TIME  (wall-clock minutes from decision to event)",
           rows, lambda r: _bucket(r["lead_min"]),
           [f"{lo}-{hi}m" for lo, hi in LEAD_BUCKETS], "lead")

    hops = sorted({r["hop"] for r in rows if r["hop"] <= 8})
    _table("MAE BY HOP  (stations ahead — errors compound autoregressively)",
           rows, lambda r: r["hop"], hops, "hop")

    # Spikes: the event the old system missed 70-87% of.
    sp = [r for r in rows if r["actual"] - r["persist"] > SPIKE]
    if sp:
        hit = sum(1 for r in sp if r["pred"] - r["persist"] > SPIKE * 0.5)
        pred_sp = [r for r in rows if r["pred"] - r["persist"] > SPIKE * 0.5]
        tp = sum(1 for r in pred_sp if r["actual"] - r["persist"] > SPIKE)
        print("\n" + "=" * 78)
        print("SPIKE DETECTION UNDER ROLLOUT  (actual rise > 30 min vs T0)")
        print("=" * 78)
        print(f"  spikes            : {len(sp)}")
        print(f"  recall            : {hit / len(sp):.1%}   "
              f"(old system: 13-30%)")
        print(f"  precision         : {tp / max(len(pred_sp), 1):.1%}")
        print(f"  spike MAE         : "
              f"{sum(abs(r['pred'] - r['actual']) for r in sp) / len(sp):.1f} min")
        under = sum(1 for r in sp if r["pred"] < r["actual"])
        print(f"  underpredicted    : {under}/{len(sp)} = "
              f"{under / len(sp):.0%}   (old system: 100%)")

    rec = [r for r in rows if r["persist"] - r["actual"] > SPIKE]
    if rec:
        hit = sum(1 for r in rec if r["persist"] - r["pred"] > SPIKE * 0.5)
        print("\n" + "=" * 78)
        print("RECOVERY DETECTION  (actual fall > 30 min vs T0)")
        print("=" * 78)
        print(f"  recoveries        : {len(rec)}")
        print(f"  recall            : {hit / len(rec):.1%}")
        print(f"  recovery MAE      : "
              f"{sum(abs(r['pred'] - r['actual']) for r in rec) / len(rec):.1f} min")

    # PER-JOURNEY ROBUST VIEW.
    #
    # The event-level mean below is dominated by a handful of runaway
    # journeys: measured on the 96-journey ship set, ONE journey moved the
    # v3-vs-v5 verdict from "v5 better" to "v5 worse", and three of them
    # flipped the sign. Every model comparison in this project has landed
    # inside the noise band, and this is why -- the headline statistic is not
    # sensitive enough to read the experiments we run on it.
    #
    # Median and trimmed mean say what happens on a TYPICAL journey; the mean
    # says what happens to the total minute count, which the tail owns. Report
    # both, and when they disagree, the disagreement IS the finding.
    by_j = defaultdict(list)
    for r in rows:
        by_j[(r["iid"], r["t0"])].append(r)
    jm, jp = [], []
    for v in by_j.values():
        jm.append(sum(abs(r["pred"] - r["actual"]) for r in v) / len(v))
        jp.append(sum(abs(r["persist"] - r["actual"]) for r in v) / len(v))

    def _q(x, f):
        x = sorted(x)
        return x[min(int(len(x) * f), len(x) - 1)]

    def _trim(x, f=0.05):
        x = sorted(x)
        k = int(len(x) * f)
        x = x[k:len(x) - k] or x
        return sum(x) / len(x)

    runaway = 0
    for v in by_j.values():
        if len(v) < 4:
            continue
        e = [abs(r["pred"] - r["actual"]) for r in sorted(v, key=lambda r: r["hop"])]
        if e[-1] > 40 and e[-1] > e[len(e) // 2] + 20:
            runaway += 1

    print("\n" + "=" * 78)
    print(f"PER-JOURNEY ERROR  ({len(jm):,} journeys) — the tail-robust view")
    print("=" * 78)
    print(f"  {'statistic':18} {'persistence':>12} {'model':>9} {'gain':>8}")
    for nm, f in (("mean", lambda x: sum(x) / len(x)),
                  ("MEDIAN", lambda x: _q(x, 0.5)),
                  ("5% trimmed mean", _trim),
                  ("75th percentile", lambda x: _q(x, 0.75)),
                  ("90th percentile", lambda x: _q(x, 0.90))):
        m, p = f(jm), f(jp)
        print(f"  {nm:18} {p:>12.2f} {m:>9.2f} {p - m:>+8.2f}")
    print(f"\n  runaway journeys (error grew >20 min in the second half "
          f"and ended >40): {runaway}")

    n = len(rows)
    mae = sum(abs(r["pred"] - r["actual"]) for r in rows) / n
    per = sum(abs(r["persist"] - r["actual"]) for r in rows) / n
    print("\n" + "-" * 78)
    print(f"OVERALL  MAE {mae:.2f}   persistence {per:.2f}   "
          f"gain {per - mae:+.2f}   (monotonicity clamp fired {n_clamped}x)")


def _hhmm(x) -> str:
    hh, mm = divmod(int(round(x)) % 1440, 60)
    return f"{hh:02d}:{mm:02d}"


def journey_view(rows, truth, n_show, want_train=None, want_at=None):
    """The whole run on one page: what was OBSERVED up to the decision time,
    then what was FORECAST after it, against what actually happened.

    This is the view that makes propagation legible — you can see the delay the
    train carried into the corridor, how it moved leg by leg while we were
    still watching, and then whether the model continued that trajectory
    correctly once it was flying blind.
    """
    by_run = defaultdict(list)
    for r in rows:
        if want_train and str(r["train_no"]) != str(want_train):
            continue
        if want_at is not None and int(r["t0"]) % 1440 != int(want_at):
            continue
        by_run[(r["t0"], r["iid"])].append(r)
    if not by_run:
        print("\nno runs match that filter")
        return

    # Show a SPREAD of scenarios, not just the biggest movers. Sorting purely
    # by magnitude returns four variations of the same runaway train and says
    # nothing about whether the model handles an ordinary run, or a train that
    # recovers time — which is the case a controller most needs to trust.
    def scenario(rs):
        rise = max(x["actual"] - x["persist"] for x in rs)
        fall = max(x["persist"] - x["actual"] for x in rs)
        if rise > SPIKE:
            return "SPIKE"
        if fall > SPIKE:
            return "RECOVERY"
        if max(abs(x["actual"] - x["persist"]) for x in rs) < 10:
            return "STEADY"
        return "MODERATE"

    buckets = defaultdict(list)
    for k, rs in by_run.items():
        buckets[scenario(rs)].append((k, rs))
    for b in buckets:
        buckets[b].sort(key=lambda kv: -len(kv[1]))       # longest journeys

    order = ["SPIKE", "RECOVERY", "MODERATE", "STEADY"]
    picked, i = [], 0
    while len(picked) < n_show and i < 50:                 # round-robin
        for b in order:
            if i < len(buckets.get(b, [])) and len(picked) < n_show:
                picked.append((b, *buckets[b][i]))
        i += 1

    print("\n\n" + "#" * 78)
    print("# PER-TRAIN JOURNEY — observed history, then forecast vs actual")
    print(f"# scenarios available: "
          + "  ".join(f"{b}={len(buckets.get(b, []))}" for b in order))
    print("#" * 78)

    for kind, (t0, iid), rs in picked:
        rs = sorted(rs, key=lambda r: r["stop_k"])
        inst = truth.get(iid)
        if inst is None:
            continue
        takeover = rs[0]["stop_k"] - rs[0]["hop"]
        stops = inst["stops"]

        print(f"\n{'=' * 74}")
        print(f"  [{kind}]  Train {inst['train_no']}  "
              f"({inst.get('train_class','?')}, "
              f"{inst.get('direction','?')})   {inst['corridor_date']}")
        print(f"  Forecast issued {_hhmm(t0)}   "
              f"delay at that moment {rs[0]['persist']:+.0f} min")
        entry = inst.get("entry") or {}
        if entry.get("has_upstream"):
            print(f"  Entered corridor {float(entry.get('entry_delay_min',0)):+.0f} "
                  f"min late from upstream "
                  f"({float(entry.get('km_before_corridor',0)):.0f} km before)")
        print(f"{'=' * 74}")
        print(f"  {'station':<8} {'sched':>6} {'actual':>7} {'delay':>7} "
              f"{'pred':>7} {'error':>7}   note")
        print(f"  {'-' * 68}")

        # ── Observed: everything up to and including the decision point ──
        for k in range(0, min(takeover + 1, len(stops))):
            s = stops[k]
            d = s.get("arr_delay")
            shown = f"{float(d):+7.0f}" if d is not None else "      ?"
            act = (_hhmm(s["actual_arr_abs"])
                   if s.get("has_actual") and d is not None else "      -")
            note = "" if s.get("has_actual") else "not reported"
            if k == takeover:
                note = (note + "  <== NOW").strip()
            print(f"  {str(s['station_code']):<8} "
                  f"{_hhmm(s['sched_arr_abs']):>6} {act:>7} {shown} "
                  f"{'':>7} {'':>7}   {note}")

        print(f"  {'- ' * 34}")
        print(f"  {'':<8} {'':>6} {'':>7} {'':>7} {'':>7} {'':>7}   "
              f"forecast from here — no observations used")
        print(f"  {'- ' * 34}")

        # ── Forecast: hop by hop, autoregressive ──
        for r in rs:
            s = stops[r["stop_k"]]
            err = r["pred"] - r["actual"]
            flag = ""
            if r["actual"] - r["persist"] > SPIKE:
                flag = "SPIKE" if err > -SPIKE * 0.5 else "SPIKE MISSED"
            elif r["persist"] - r["actual"] > SPIKE:
                flag = "recovery"
            print(f"  {str(r['station']):<8} "
                  f"{_hhmm(s['sched_arr_abs']):>6} "
                  f"{_hhmm(s['actual_arr_abs']):>7} "
                  f"{r['actual']:>+7.0f} {r['pred']:>+7.0f} {err:>+7.0f}   "
                  f"h{r['hop']} +{r['lead_min']:.0f}m {flag}")

        n = len(rs)
        mae = sum(abs(r["pred"] - r["actual"]) for r in rs) / n
        per = sum(abs(r["persist"] - r["actual"]) for r in rs) / n
        print(f"  {'-' * 68}")
        print(f"  {n} forecast stops   MAE {mae:.1f} min   "
              f"persistence {per:.1f} min   gain {per - mae:+.1f}")


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", default=str(OUT_DIR / "corridor_nextevent.pt"))
    ap.add_argument("--journeys", default=str(JOURNEYS_DIR))
    ap.add_argument("--topology", default=str(TOPOLOGY_PATH))
    ap.add_argument("--dataset", default=str(DATASET_DIR))
    ap.add_argument("--split", default="test")
    ap.add_argument("--every", type=int, default=90,
                    help="minutes between decision times")
    ap.add_argument("--first", type=int, default=330)
    ap.add_argument("--last", type=int, default=1290)
    ap.add_argument("--show", type=int, default=0,
                    help="print N per-train journey tables")
    ap.add_argument("--train", default=None,
                    help="restrict --show to this train number")
    ap.add_argument("--at", type=int, default=None,
                    help="restrict --show to this decision time (minute of day)")
    ap.add_argument("--check-state", action="store_true",
                    help="rebuild each tick from ground truth too and compare "
                         "features, to verify the forecast world updates right")
    ap.add_argument("--out", default=None, help="write raw records as JSON")
    ap.add_argument("--dep-head", choices=["model", "booked"], default="model",
                    help="'model' uses the trained departure head to set dwell "
                         "inside the forecast world; 'booked' forces every "
                         "dwell to its booked value, ablating the head.")
    ap.add_argument("--revise", action="store_true",
                    help="while a train STANDS at a platform, re-ask how "
                         "much longer it will stay and re-predict its next "
                         "arrival every tick, instead of deciding both once "
                         "at the first tick. Needs a checkpoint with the "
                         "remaining_dwell head.")
    ap.add_argument("--revise-min", type=float, default=0.0,
                    help="minutes: only EXTEND a stand when the head asks for "
                         "at least this long. The head over-predicts short "
                         "stands (3.65 min against a truth of 0.81) and a "
                         "departure may only move later, so unfiltered "
                         "revision holds everything. 0.0 disables the floor "
                         "and reproduces unfiltered --revise exactly. Only "
                         "meaningful with --revise.")
    ap.add_argument("--standing-dep", choices=["actual", "booked", "hold"],
                    default="actual",
                    help="when does a train ALREADY STANDING at T0 leave? "
                         "'actual' keeps its true departure (future "
                         "information, the historical default); 'booked' "
                         "releases it after its booked dwell, or at once if "
                         "that moment has passed.")
    ap.add_argument("--entry-mode", choices=["actual", "timetable"],
                    default="actual",
                    help="how trains that enter the corridor AFTER T0 are "
                         "injected. 'actual' = true entry time and delay "
                         "(future information, the historical default); "
                         "'timetable' = booked entry, on time, no upstream "
                         "context. The two bracket what production can know.")
    # Comparing two models is only meaningful on identical ground. Both of
    # these exist so a run can be pinned to the same days and the same train
    # population as an earlier run, even when the split moved underneath it
    # (adding supervised train types changed which boundary days survive
    # _drop_partial_days, which shifted every split by one day).
    ap.add_argument("--hurdle-tau", type=float, default=1.0,
                    help="P(large change) above which the magnitude head "
                         "replaces the ordinary head. 1.0 disables it, "
                         "which reproduces the pre-hurdle model exactly. "
                         "Tune on VALIDATION days, never on test.")
    ap.add_argument("--practice-out", default=None,
                    help="v14 rollout fine-tune: LEARN from the forecast world on the "
                         "chosen dates (TRAINING days only) and save the updated "
                         "checkpoint here. Labels read the truth; inputs never do.")
    ap.add_argument("--practice-lr", type=float, default=5e-5)
    ap.add_argument("--practice-far-weight", type=float, default=0.0,
                    help="weight practice labels by 1 + this * hours since T0")
    ap.add_argument("--hold-module", action="store_true",
                    help="run B: hold chance/length from v14/hold_module.py (situation only)")
    ap.add_argument("--b-calib", default=None,
                    help="run B: JSON with isotonic p_next/p_cur maps and hold-length scales, "
                         "fitted on days the model never trained on")
    ap.add_argument("--rules", action="store_true",
                    help="forecast world obeys headway + no in-section overtaking "
                         "(gaps fitted on training days, v14/headways.py)")
    ap.add_argument("--diag-dump-world", default=None,
                    help="DIAGNOSIS: write every passenger train's forecast-world "
                         "times (and the real ones) to this JSON file.")
    ap.add_argument("--diag-oracle-freight", action="store_true",
                    help="DIAGNOSIS ONLY: freight at its TRUE future positions, to "
                         "measure the most a better freight projection could gain.")
    ap.add_argument("--horizon", type=int, default=None,
                    help="simulate this many minutes after T0 (default 240). "
                         "Many-futures runs use a longer one so a future in which "
                         "a train is held still reaches the stops scored at 240.")
    ap.add_argument("--sample-seed", type=int, default=None,
                    help="run B many-futures mode: this rollout is ONE sampled "
                         "future (holds drawn with the model's probabilities). "
                         "Run several seeds and average their records.")
    ap.add_argument("--expected-hold", action="store_true",
                    help="run B: add each train's expected (probability-weighted) "
                         "hold minutes at stops it has left to its reported delay "
                         "at later stops. The forecast world is unchanged.")
    ap.add_argument("--hold-tau", type=float, default=None,
                    help="run B: hold probability above which a hold is written "
                         "into the forecast world. Default keeps the checkpoint's "
                         "value (0.5). Tune on VALIDATION days, never on test.")
    ap.add_argument("--dates", default=None,
                    help="comma-separated dates to score, overriding --split")
    ap.add_argument("--only-types", default=None,
                    help="comma-separated train_type codes to SCORE; others "
                         "still run as actors but are not counted")
    ap.add_argument("--midnight", action="store_true",
                    help="one continuous timeline (v14/timeline.py): a day's world also holds the trains "
                         "still running from the evening before and those entering after midnight, the "
                         "replay starts the evening before (features only), and forecasts run past midnight")
    ap.add_argument("--run-id-fix", action="store_true",
                    help="with --midnight: unique run ids + merged two-trip journeys split (v14/timeline.py)")
    ap.add_argument("--inject", default=None,
                    help="JSON list of [iid, t0, station, release_abs]: gated overtake holds pushed into "
                         "the forecast world (built from T0 knowledge only by scratch c74_inject_table.py)")
    ap.add_argument("--inject-floor", action="store_true",
                    help="with --inject: a standing train's release is a 'not before' limit on its next arrival, "
                         "never added on top of the model's own forecast")
    ap.add_argument("--v14", action="store_true",
                    help="v14 data layer: v14 journeys + FreightStore/EventStore "
                         "with as-of-T0 knowledge. Topology stays the production "
                         "file so service indices match v13-era checkpoints.")
    ap.add_argument("--predictor", default="gnn",
                    choices=["gnn", "gbm-median", "gbm-mean", "gbm-composed",
                             "mix-mean+median", "mix-median+mean",
                             "mix-composed+median"],
                    help="gnn = the checkpoint (default). gbm-* = the frozen "
                         "gradient-boosted stand-ins from v14/gbm_predictor.py, "
                         "used to choose what single number the GNN should predict.")
    args = ap.parse_args()
    global HORIZON_MIN, DIAG_ORACLE_FREIGHT, DIAG_WORLD, LEARN
    if args.diag_dump_world:
        DIAG_WORLD = []
    bcal_table = None
    if args.b_calib:
        bcal_table = json.loads(Path(args.b_calib).read_text(encoding="utf-8"))
        print(f"  b-calib: honest hold probabilities/lengths from {args.b_calib} "
              f"(fitted excluding day {bcal_table.get('fit_excluding_day')})")
    rules_table = None
    if args.rules:
        from cris_pipeline.v14.headways import load as _load_headways
        rules_table = _load_headways()
        print(f"  rules: headways fitted on {len(rules_table['fit_days'])} training days "
              f"(fallback dep {rules_table['fallback_dep']:.1f} / arr {rules_table['fallback_arr']:.1f} min)")
    if args.horizon is not None:
        HORIZON_MIN = int(args.horizon)
    if args.diag_oracle_freight:
        DIAG_ORACLE_FREIGHT = True
        print("  !! DIAGNOSTIC: true future freight positions (not a forecast)")
    if args.v14:
        from cris_pipeline.v14.settings import (JOURNEYS_DIR as _J, DATASET_DIR as _D,
                                                PROD_TOPOLOGY as _T)
        args.journeys, args.dataset, args.topology = str(_J), str(_D), str(_T)

    topo = json.loads(Path(args.topology).read_text(encoding="utf-8"))
    BD._init_topology(topo)

    predictor = None
    if args.predictor != "gnn":
        # GBM stand-in: no checkpoint. Conventions come from the DATASET its
        # training rows were built from (v14: honest standing, clock ETAs).
        from cris_pipeline.v14.gbm_predictor import GBMPredictor
        _meta = json.loads((Path(args.dataset) / "meta.json").read_text(encoding="utf-8"))
        BD.HONEST_STANDING_DELAY = bool(_meta.get("honest_standing_delay", False))
        BD.CLOCK_ETAS = bool(_meta.get("clock_etas", False))
        if args.predictor.startswith("mix-"):
            from cris_pipeline.v14.gbm_predictor import MixPredictor
            _a, _e = args.predictor[4:].split("+")
            predictor = MixPredictor(_a, _e)          # arrival from _a, dwell from _e
        else:
            predictor = GBMPredictor.load(args.predictor.split("-", 1)[1])
        model, ds, dep_mode = None, None, "extension"
        args.hurdle_tau = 1.0
        print(f"  predictor {args.predictor} fitted on {predictor.fit_days}; "
              f"honest standing {BD.HONEST_STANDING_DELAY}, clock ETAs {BD.CLOCK_ETAS}")
    else:
        ck = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
        model = CorridorNextEventGNN(**ck["config"])
        # Checkpoints from before the hurdle heads existed (v1..v6) carry no
        # spike_logit_head / spike_mag_head. Load them anyway so every historical
        # model stays scoreable on the current code -- that comparability is the
        # only reason the release directories are worth keeping. Their hurdle
        # weights stay at init and are never consulted, because a missing head
        # forces the threshold to 1.0 below.
        # Score a model under the convention it was TRAINED on. v6..v12
        # froze a standing train's delay at its arrival value; v13 lets it grow.
        # Reading this from the checkpoint means an old model can never be
        # accidentally scored under new rules, which would look like a
        # regression that is really a mismatch.
        BD.HONEST_STANDING_DELAY = bool(ck.get("honest_standing_delay", False))
        if BD.HONEST_STANDING_DELAY:
            print("  honest standing delay: ON (v13 convention)")
        # ETA convention, same rule: absent from every checkpoint up to v13, which
        # therefore scores exactly as before.
        BD.CLOCK_ETAS = bool(ck.get("clock_etas", False))
        if BD.CLOCK_ETAS:
            print("  clock ETAs: ON (v14 convention)")
        hurdle_ok, dwell_ok = load_weights(model, ck["model"])
        # An untrained head sits at its initialisation and emits noise. Letting
        # --revise consult one would extend stands at random and look exactly like
        # a research result, so refuse rather than warn.
        if args.revise and not dwell_ok:
            raise SystemExit(
                "--revise needs a checkpoint trained with the remaining_dwell head; "
                f"{args.checkpoint} predates it. Re-run without --revise, or use a "
                "v7 checkpoint.")
        if not hurdle_ok:
            if args.hurdle_tau < 1.0:
                print("  ! checkpoint predates the hurdle heads — "
                      "--hurdle-tau ignored")
            args.hurdle_tau = 1.0
        if args.hold_tau is not None:
            # Run B only: p_next threshold above which a hold is written into
            # the forecast world. None keeps the checkpoint's own buffer.
            if not hasattr(model, "hold_tau"):
                raise SystemExit("--hold-tau needs an interactions (run B) checkpoint")
            model.hold_tau.fill_(float(args.hold_tau))
            print(f"  hold_tau set to {args.hold_tau}")
        if args.expected_hold:
            if not getattr(model, "interactions", False):
                raise SystemExit("--expected-hold needs an interactions (run B) checkpoint")
            print("  expected-hold ledger: ON")
        if args.sample_seed is not None:
            if not getattr(model, "interactions", False):
                raise SystemExit("--sample-seed needs an interactions (run B) checkpoint")
            if args.expected_hold or args.revise:
                raise SystemExit("--sample-seed is a pure sampled future: "
                                 "do not combine with --expected-hold or --revise")
            print(f"  many-futures: sampled future, seed {args.sample_seed}")
        model.eval()
        dep_mode = ck.get("dep_mode", "absolute")
        print(f"checkpoint epoch {ck['epoch']}  val_mae {ck['val_mae']:.2f}"
              f"  dep_mode={dep_mode}")

        # Pre-v6 checkpoints were trained before the two timetable-slack dims, so
        # they expect 44 rather than 46. Must come BEFORE the dataset is built --
        # CrisDataset snapshots the feature width at construction. A no-op for
        # anything trained at v6 or later.
        match_checkpoint_features(ck["config"])

        ds = CrisDataset(args.dataset, args.topology, lazy=True, verbose=False)
        # A forecast never computes labels (the future) from its own world.
        ds.compute_labels = False
        # Built after the model here, so the guard lands here rather than at
        # construction. Still ahead of the first forward pass, which is all
        # that matters -- the alternative is a shape error from inside a
        # Linear, four frames deep, that reads like a model bug.
        check_feature_dims(ck["config"], ds)

    section_pairs = {(int(s["from_id"]), int(s["to_id"]))
                     for s in BD._SECTIONS.values()}
    if args.v14:
        from cris_pipeline.v14.freight import FreightStore
        from cris_pipeline.v14.events import EventStore
        from cris_pipeline.v14.audit_env import _NoDetention
        freight, disrupt, detent = (FreightStore.load(),
                                    EventStore.load(section_pairs), _NoDetention())
        print("  [v14] journeys + FreightStore/EventStore (knowledge as of T0)")
    else:
        freight = FreightOverlay.load()
        disrupt = DisruptionOverlay.load(section_pairs)
        detent = DetentionOverlay.load()

    # Reproduce build_dataset's exact day indexing and split assignment so
    # `day_idx` (and therefore every absolute minute) matches the dataset.
    by_date = BD._load_journeys(Path(args.journeys))
    dates = BD._drop_partial_days(by_date, sorted(by_date))
    splits = BD._assign_splits(dates)
    if args.dates:
        want = [d.strip() for d in args.dates.split(",") if d.strip()]
        missing = [d for d in want if d not in dates]
        if missing:
            raise SystemExit(f"--dates not present in this build: {missing}\n"
                             f"available: {dates[0]} .. {dates[-1]}")
        target_dates = want
        print(f"pinned dates: {len(target_dates)} days  {target_dates}")
    else:
        target_dates = [d for d in dates if splits[d] == args.split]
        print(f"{args.split}: {len(target_dates)} days  {target_dates}")

    if args.practice_out:
        # Practice reads the TRUTH as labels, so it may only ever touch days
        # the model is allowed to train on. Refuse anything else outright.
        bad = [d for d in target_dates if splits[d] != "train"]
        if bad:
            raise SystemExit(f"--practice-out on non-training days refused: {bad}")
        if model is None:
            raise SystemExit("--practice-out needs a GNN checkpoint")
        LEARN = PracticeLearner(model, lr=args.practice_lr,
                                far_weight=args.practice_far_weight)
        print(f"  PRACTICE: learning on {len(target_dates)} training days, lr {args.practice_lr}, "
              f"far weight {args.practice_far_weight}/h")

    hold_mod = None
    if args.hold_module:
        if model is None or not getattr(model, "interactions", False):
            raise SystemExit("--hold-module needs a run-B (interactions) checkpoint")
        from cris_pipeline.v14.hold_module import HoldModule
        hold_mod = HoldModule.load()
        print(f"  hold module: situation-only holds, fitted on {hold_mod.fit_days}")

    only_types = ({t.strip().upper() for t in args.only_types.split(",")}
                  if args.only_types else None)
    if only_types:
        print(f"scoring only train types: {sorted(only_types)}")

    hold_rule = None
    if args.standing_dep == "hold":
        from cris_pipeline.v14.hold_rule import HoldRule
        hold_rule = HoldRule.load()
        print(f"  hold rule: tau {hold_rule.tau}, gap {hold_rule.gap:.1f} min, "
              f"fitted on {hold_rule.fit_days}")
    decisions = list(range(args.first, args.last + 1, args.every))
    print(f"decision times/day: {len(decisions)}  "
          f"horizon {HORIZON_MIN} min  entry_mode {args.entry_mode}"
          f"  dep_head {args.dep_head}"
          f"  standing_dep {args.standing_dep}"
          f"{'  revise' if args.revise else ''}"
          f"{f'  revise_min {args.revise_min:g}' if args.revise and args.revise_min else ''}\n")

    state_check = None
    if args.check_state:
        from cris_pipeline.audit_features import TRAIN_LABELS, STATION_LABELS
        state_check = StateCheck(TRAIN_LABELS, STATION_LABELS)

    all_rows, total_clamped = [], 0
    truth_all: dict[str, dict] = {}       # pristine journeys, for the viewer
    inject_table = None
    if args.inject:
        inject_table = {(r[0], int(round(r[1]))): (r[2], float(r[3]))
                        for r in json.loads(Path(args.inject).read_text(encoding="utf-8"))}
        print(f"  INJECT: {len(inject_table)} gated overtake holds from {args.inject}")
    if args.run_id_fix:
        if not args.midnight:
            raise SystemExit("--run-id-fix needs --midnight")
        TL.RUN_ID_FIX = True
        print("  RUN-ID FIX: unique run ids, merged trips split")
    if args.midnight:
        TL.check_consecutive(dates)
        print(f"  MIDNIGHT: continuous timeline, previous-evening replay {MIDNIGHT_WARM_MIN} min")
    own_cache: dict[str, list] = {}
    for date in target_dates:
        di = dates.index(date)
        d_obj = dt.date.fromisoformat(date)
        day_meta = {"day_of_week": d_obj.weekday()}

        instances, warm = [], []
        if args.midnight:
            # The trains of the days around D, placed on the calendar timeline;
            # D's world = every train whose span meets D or the forecasts'
            # reach past midnight; the warm-up = those on the corridor in the
            # previous evening's last MIDNIGHT_WARM_MIN minutes.
            assert TL.day_number(date, dates[0]) == di
            pool = []
            for k in (-2, -1, 0, 1):
                dd = (d_obj + dt.timedelta(days=k)).isoformat()
                if dd not in own_cache:
                    own_cache[dd] = TL.build_own(BD, by_date, dd, dates[0])
                pool += own_cache[dd]
            lo = di * 1440
            pool = [copy.deepcopy(i) for i in TL.overlapping(pool, lo - MIDNIGHT_WARM_MIN,
                                                             lo + 1440 + HORIZON_MIN)]
            for inst in pool:
                inst["detention"] = detent.get(
                    inst["train_no"], inst.get("journey_date") or inst["corridor_date"]) or {}
            instances = TL.overlapping(pool, lo, lo + 1440 + HORIZON_MIN)
            warm = TL.overlapping(pool, lo - MIDNIGHT_WARM_MIN, lo)
        else:
            for rec in by_date[date]:
                inst = BD._build_instance(rec, di)
                if inst:
                    inst["detention"] = detent.get(
                        inst["train_no"], inst.get("journey_date") or date) or {}
                    instances.append(inst)
        if not instances:
            continue
        truth_by_iid = {i["instance_id"]: i for i in instances}
        # Truth is never mutated — the rollout owns a deep copy — so these can
        # be kept as-is for the journey view.
        truth_all.update(truth_by_iid)
        by_iid = truth_by_iid
        routes = {i["instance_id"]: i["route"] for i in instances}

        # One chronological pass over the REAL day. At each decision time the
        # memory and station state are forked and a rollout is run from there,
        # so the model enters every forecast having seen exactly the history a
        # controller would have at that moment — no more, no less.
        st_state = BD._StationState()
        prev_delay: dict[str, float] = {}
        if model is not None:
            model.reset_memory()
        day_rows, day_clamped = [], 0
        pending = set(decisions)
        if args.midnight:
            # Features only (station state, previous delays) -- the model's
            # memory still starts at 00:00, exactly as in training.
            prev_date = (d_obj - dt.timedelta(days=1)).isoformat()
            prev_meta = {"day_of_week": (d_obj - dt.timedelta(days=1)).weekday()}
            for m in BD.SNAPSHOT_SCHEDULE:
                if m >= 1440 - MIDNIGHT_WARM_MIN:
                    BD.build_snapshot(di - 1, (di - 1) * 1440 + m, warm, st_state, prev_meta,
                                      prev_delay, freight, disrupt, prev_date)

        for m in BD.SNAPSHOT_SCHEDULE:
            t = di * 1440 + m
            if m in pending:
                pending.discard(m)
                saved = ((model.station_memory.clone(),
                          model.service_memory.clone(),
                          model.section_memory.clone()) if model is not None else None)
                ro = Rollout(model, ds, di, date, day_meta, freight, disrupt,
                             truth_by_iid, state_check, dep_mode,
                             hurdle_tau=args.hurdle_tau,
                             entry_mode=args.entry_mode,
                             dep_head=args.dep_head,
                             standing_dep=args.standing_dep,
                             hold_rule=hold_rule,
                             predictor=predictor,
                             revise=args.revise,
                             revise_min=args.revise_min,
                             expected_hold=args.expected_hold,
                             sample_seed=args.sample_seed,
                             rules=rules_table)
                ro.bcal = bcal_table
                ro.first_date = dates[0] if args.midnight else None
                ro.inject = inject_table
                ro.inject_floor = bool(args.inject_floor)
                ro.hold_mod = hold_mod
                rows, nc = ro.run(t, copy.deepcopy(instances),
                                  _state_copy(st_state), dict(prev_delay))
                day_rows += rows
                day_clamped += nc
                if model is not None:
                    (model.station_memory, model.service_memory,
                     model.section_memory) = saved

            snap = BD.build_snapshot(di, t, instances, st_state, day_meta,
                                     prev_delay, freight, disrupt, date)
            if not snap["train_nodes"]:
                continue
            if model is None:
                continue                      # no recurrent memory to advance
            data = ds.materialise(snap, by_iid, routes)
            if data is None or data["train"].x.numel() == 0:
                continue
            with torch.no_grad():
                model(data, update_memory=True)

        if only_types:
            kept = [r for r in day_rows
                    if str(r.get("train_type", "")).upper() in only_types]
            dropped = len(day_rows) - len(kept)
            day_rows = kept
        else:
            dropped = 0
        all_rows += day_rows
        total_clamped += day_clamped
        print(f"  {date}: {len(day_rows):5d} forecast events"
              + (f"  ({dropped} not scored: type filter)" if dropped else ""),
              flush=True)

    strict = [r for r in all_rows if r["already_running"]]
    report(strict, total_clamped, "STRICT — trains already running at T0")
    later = [r for r in all_rows if not r["already_running"]]
    if later:
        report(later, 0, "ENTERED LATER — " + (
            "true entry delay assumed known" if args.entry_mode == "actual"
            else "booked entry assumed, on time"))

    if state_check is not None:
        state_check.report()

    if args.show:
        journey_view(strict, truth_all, args.show,
                     want_train=args.train, want_at=args.at)

    if args.out:
        Path(args.out).write_text(json.dumps(all_rows, indent=1),
                                  encoding="utf-8")
        print(f"\nwrote {args.out}")
    if LEARN is not None:
        LEARN.flush()
        print(LEARN.report())
        ck_out = dict(ck)
        ck_out["model"] = model.state_dict()
        ck_out["practice"] = {"from": args.checkpoint, "dates": target_dates,
                              "lr": args.practice_lr, "steps": LEARN.steps,
                              "first": args.first, "last": args.last, "every": args.every,
                              "standing_dep": args.standing_dep}
        torch.save(ck_out, args.practice_out)
        print(f"wrote practised checkpoint {args.practice_out}")
    if DIAG_WORLD is not None:
        Path(args.diag_dump_world).write_text(json.dumps(DIAG_WORLD), encoding="utf-8")
        print(f"wrote forecast-world dump {args.diag_dump_world} ({len(DIAG_WORLD)} trajectories)")


if __name__ == "__main__":
    main()
