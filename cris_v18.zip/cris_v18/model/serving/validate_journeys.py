# -*- coding: utf-8 -*-
"""
serving/validate_journeys.py -- check journey files before forecasting.

    python serving/validate_journeys.py <journey folder> [--date YYYY-MM-DD]

For whoever produces the live journey files (e.g. the Redis -> journey converter). The rules are the ones the
September 2025 files obey (all 2,605 pass with 0 errors); the frozen loader silently skips a file it cannot read,
so a broken file would otherwise just make a train disappear from the forecast.

ERROR   = the file is unusable or would give wrong forecasts. Exit code 1.
WARNING = it works, but something is worth a look (e.g. a train v18 never saw in training).

Layout:   <folder>/<train_no>/<corridor_date>.json        (a second run on the same date: <corridor_date>#2.json)
Times:    minutes after 00:00 of corridor_date (may be negative, or > 1440 after midnight); null = not reported yet
Rule:     arr_delay_min = actual_arr_min - sched_arr_min (same for departure); has_actual = arrival reported
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import re
import sys
from pathlib import Path

MODEL = Path(__file__).resolve().parent.parent
TOPOLOGY = MODEL.parent / "jabalpur_scenario_gnn" / "data_cris" / "topology_jbp_sta_cris.json"

TOP = {"train_no": str, "corridor_date": str, "journey_date": str, "train_type": str, "train_sub_type": str,
       "train_class": str, "train_group": str, "priority": (int, float), "speed_factor": (int, float),
       "source": str, "destination": str, "direction": str, "n_coaches": int, "is_target_eligible": bool,
       "entry": dict, "stops": list}
ENTRY = {"entry_delay_min", "has_upstream", "km_before_corridor", "upstream_delay_trend_min",
         "upstream_max_delay_min", "upstream_rate5", "upstream_recovered_min", "upstream_stops_observed",
         "upstream_volatility"}
STOP = {"station_code": str, "station_id": int, "sched_arr_min": (int, float), "sched_dep_min": (int, float),
        "actual_arr_min": (int, float, type(None)), "actual_dep_min": (int, float, type(None)),
        "arr_delay_min": (int, float, type(None)), "dep_delay_min": (int, float, type(None)),
        "has_actual": bool, "is_booked_halt": bool, "is_division_stop": bool, "is_ptt_halt": bool,
        "sched_allowance_min": (int, float), "platform": (str, int, type(None)), "distance_km": (int, float)}
NAME = re.compile(r"^(\d{4}-\d{2}-\d{2})(#\d+)?\.json$")


def check_file(f: Path, topo: dict) -> tuple[list, list]:
    err, warn = [], []
    try:
        r = json.loads(f.read_text(encoding="utf-8"))
    except Exception as e:
        return [f"cannot read JSON: {type(e).__name__}: {e}"], []
    m = NAME.match(f.name)
    if not m:
        err.append("file name must be <corridor_date>.json or <corridor_date>#N.json")
    for k, t in TOP.items():
        if k not in r:
            err.append(f"missing field {k}")
        elif not isinstance(r[k], t) or (t is int and isinstance(r[k], bool)):
            err.append(f"{k} has type {type(r[k]).__name__}")
    if err:
        return err, warn
    for k in ("corridor_date", "journey_date"):
        try:
            dt.date.fromisoformat(r[k])
        except ValueError:
            err.append(f"{k} is not YYYY-MM-DD: {r[k]!r}")
    if m and m.group(1) != r["corridor_date"]:
        err.append(f"file name date {m.group(1)} != corridor_date {r['corridor_date']}")
    if f.parent.name != r["train_no"]:
        err.append(f"folder {f.parent.name} != train_no {r['train_no']}")
    if r["direction"] not in ("UP", "DN"):
        err.append(f"direction must be UP or DN, got {r['direction']!r}")
    miss = ENTRY - set(r["entry"])
    if miss:
        err.append(f"entry is missing {sorted(miss)}")
    if not r["stops"]:
        err.append("no stops")
    if r["train_no"] not in {t["train_no"] for t in topo["trains"]}:
        warn.append(f"train {r['train_no']} is not in the topology: v18 never saw it in training (generic identity)")
    prev_t, prev_k = None, None
    for k, s in enumerate(r["stops"]):
        where = f"stop {k} {s.get('station_code')}"
        for key, t in STOP.items():
            if key not in s:
                err.append(f"{where}: missing {key}")
            elif not isinstance(s[key], t) or (t is int and isinstance(s[key], bool)):
                err.append(f"{where}: {key} has type {type(s[key]).__name__}")
        if any(e.startswith(where) for e in err):
            continue
        if topo["code_to_id"].get(s["station_code"]) != s["station_id"]:
            err.append(f"{where}: station_code/station_id do not match the topology "
                       f"({s['station_code']} -> {topo['code_to_id'].get(s['station_code'])}, file says {s['station_id']})")
        for a, d, sc in (("actual_arr_min", "arr_delay_min", "sched_arr_min"),
                         ("actual_dep_min", "dep_delay_min", "sched_dep_min")):
            if (s[a] is None) != (s[d] is None):
                err.append(f"{where}: {a} and {d} must both be set or both be null")
            elif s[a] is not None and abs(s[a] - s[sc] - s[d]) > 0.02:
                err.append(f"{where}: {d} {s[d]} != {a} - {sc} = {s[a] - s[sc]:.2f}")
        if s["has_actual"] != (s["actual_arr_min"] is not None):
            err.append(f"{where}: has_actual must be true exactly when actual_arr_min is set")
        if s["actual_arr_min"] is not None and s["actual_dep_min"] is not None and s["actual_dep_min"] < s["actual_arr_min"] - 0.01:
            warn.append(f"{where}: departure before arrival")
        for t in (s["actual_arr_min"], s["actual_dep_min"]):
            if t is None:
                continue
            if prev_t is not None and t < prev_t - 0.01:
                warn.append(f"{where}: reported time {t:.2f} is earlier than stop {prev_k} ({prev_t:.2f})")
            prev_t, prev_k = t, k
    return err, warn


def main() -> int:
    ap = argparse.ArgumentParser(description="check cris-v18 journey files")
    ap.add_argument("folder")
    ap.add_argument("--date", help="only files whose corridor date is this day or the day before")
    ap.add_argument("--show", type=int, default=20, help="problems to print (default 20)")
    a = ap.parse_args()
    folder = Path(a.folder)
    if not folder.is_dir():
        print(f"ERROR: not a folder: {folder}", file=sys.stderr)
        return 2
    topo = json.loads(TOPOLOGY.read_text(encoding="utf-8"))
    keep = None
    if a.date:
        d0 = dt.date.fromisoformat(a.date)
        keep = {d0.isoformat(), (d0 - dt.timedelta(days=1)).isoformat()}
    files = sorted(p for p in folder.glob("*/*.json") if keep is None or p.name[:10] in keep)
    stray = sorted(p for p in folder.iterdir() if p.is_file())
    n_err = n_warn = 0
    shown = 0
    for p in stray:
        print(f"WARNING  {p.name}: file at the top level is ignored (files go in <train_no>/ folders)")
        n_warn += 1
    for f in files:
        err, warn = check_file(f, topo)
        n_err += bool(err)
        n_warn += bool(warn)
        for kind, L in (("ERROR  ", err), ("WARNING", warn)):
            for x in L:
                if shown < a.show:
                    print(f"{kind}  {f.parent.name}/{f.name}: {x}")
                shown += 1
    print(f"\n{len(files)} files: {len(files) - n_err} usable, {n_err} with errors, {n_warn} with warnings")
    if not files:
        print("ERROR: no journey files found", file=sys.stderr)
        return 1
    return 1 if n_err else 0


if __name__ == "__main__":
    sys.exit(main())
