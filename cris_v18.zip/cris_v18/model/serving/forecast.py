# -*- coding: utf-8 -*-
"""
serving/forecast.py -- one cris-v18 forecast, end to end.

    python serving/forecast.py --date 2025-09-26 --time 05:00 --out forecast.json

What it does (identical to the release runs: rollout_cris --v14 --midnight --run-id-fix --standing-dep booked):
  1. reads every journey file in model/data_v14/journeys (or --journeys DIR),
  2. replays the day from 00:00 to the forecast moment, one picture every 3 minutes, so the model's memory is
     exactly what it would be in training (the evening before is replayed for station state only),
  3. plays all trains 4 hours forward together (frozen cris_pipeline/rollout_cris.Rollout),
  4. applies the frozen correction (serving/recipe.py),
  5. writes one JSON with a forecast for every corridor station each train reaches within 4 hours.

The frozen release code in cris_pipeline/ is not modified. This file only drives it. rollout_cris.py itself is an
EVALUATION tool: it keeps a forecast only where a real arrival exists to score against, so on live data it would
return nothing. Here the forecasts are read from the forecast world the rollout builds, which holds exactly the
same numbers (serving/verify.py checks this against the official v18 files).

Journey files hold the past only in production (the future has not happened). Research files hold the whole day;
the rollout erases everything after the forecast moment, so the result is the same either way.
"""
from __future__ import annotations

import argparse
import copy
import datetime as dt
import json
import sys
import time
from pathlib import Path

SERVING = Path(__file__).resolve().parent
MODEL = SERVING.parent
sys.path.insert(0, str(MODEL))
sys.path.insert(0, str(SERVING))

import torch  # noqa: E402

from cris_pipeline import build_dataset as BD  # noqa: E402
from cris_pipeline import rollout_cris as R  # noqa: E402
from cris_pipeline.v14 import timeline as TL  # noqa: E402
from cris_pipeline.v14 import settings as S  # noqa: E402
from cris_pipeline.dataset_cris import CrisDataset, match_checkpoint_features  # noqa: E402
from cris_pipeline.model_cris import CorridorNextEventGNN, load_weights, check_feature_dims  # noqa: E402
from cris_pipeline.v14.freight import FreightStore  # noqa: E402
from cris_pipeline.v14.events import EventStore  # noqa: E402
from cris_pipeline.v14.audit_env import _NoDetention  # noqa: E402
from recipe import Recipe  # noqa: E402

ORIGIN = "2025-09-02"        # day 0 of the running clock (as in the release runs); any date works
SCORED_TYPES = ("SUF", "MEX", "VNDB", "DRNT")   # train types v18 and its correction were tested on
TZ = "+05:30"
PACKAGE_VERSION = "cris-v18-serving-1.0"
STALE_MIN = 190.0            # = build_dataset.MAX_REMAINING_DWELL_MIN: a report older than this is not extended


def check_journey_folder(folder: Path, date: str) -> list:
    """Stop with a clear message if the input cannot work; return warnings that do not stop a forecast."""
    folder = Path(folder)
    if not folder.is_dir():
        raise FileNotFoundError(f"journey folder not found: {folder}")
    d0 = dt.date.fromisoformat(date)
    need = [(d0 + dt.timedelta(days=k)).isoformat() for k in (-1, 0)]
    files = [f for f in folder.glob("*/*.json") if f.name[:10] in need + [(d0 - dt.timedelta(days=2)).isoformat(),
                                                                          (d0 + dt.timedelta(days=1)).isoformat()]]
    found = {f.name[:10] for f in files}
    if need[1] not in found:
        raise FileNotFoundError(f"no journey file with corridor date {need[1]} in {folder}")
    warnings = []
    if need[0] not in found:
        warnings.append(f"no journey file for the previous day {need[0]}: trains that entered before midnight "
                        f"and the evening replay are missing")
    bad = []
    for f in files:
        try:
            r = json.loads(f.read_text(encoding="utf-8"))
            if not r.get("stops"):
                bad.append(f"{f.parent.name}/{f.name}: no stops")
        except Exception as e:                       # the frozen loader skips these silently
            bad.append(f"{f.parent.name}/{f.name}: {type(e).__name__}")
    if bad:
        warnings.append(f"{len(bad)} journey file(s) skipped (run serving/validate_journeys.py): " + "; ".join(bad[:10]))
    return warnings


def hold_unknown_until_now(pool: list, t0: float, exempt: set | None = None) -> int:
    """THE ONE PRODUCTION ADAPTATION (not needed on research files, harmless on them).

    A live record holds the past only. For a stop with no real time yet, the frozen builder places the train using
    the delay carried so far (build_dataset._build_instance). That is right for a stop that was passed but never
    reported, and wrong for a stop the train has not reached: a train held at PTWA past its "expected" departure
    would be shown as already running. In the research files the real future departure prevented this.

    Rule, after a train's last reported stop L:
      * its departure from L, if not reported, is not before t0 (it is still standing there) -- unless L is its
        LAST corridor stop: then it is leaving the corridor, and stays as built (as in the release);
      * the next stop that reports (not a block post: GNWA, MDRR, SNRR never report) and every stop after it are
        not before t0. Block posts in between keep their estimate, which may rightly lie in the past.
    Applied only if the last report (or, for a train not yet on the corridor, its estimated entry) is less than
    STALE_MIN old, so a train whose last stops never report does not stay on the corridor for ever.
    verify.py checks it changes nothing on complete research data and reproduces the release from live-like data.

    Known difference from the release: 0.1-0.3% of arrivals never get a departure report (a recording gap). The
    release then used an estimate (arrival + booked stop) and let the train leave; this rule keeps it standing
    until its next report arrives. `exempt` (run ids) skips only the departure hold -- verify.py only, to isolate that case."""
    eps, n = 0.01, 0
    for inst in pool:
        gap = bool(exempt) and inst["instance_id"] in exempt
        st = inst["stops"]
        rep = [k for k, s in enumerate(st) if s["arr_delay"] is not None or s["dep_delay"] is not None]
        if rep:
            L = rep[-1]
            s = st[L]
            last_time = float(s["actual_dep_abs"] if s["dep_delay"] is not None else s["actual_arr_abs"])
            if last_time > t0 or t0 - last_time > STALE_MIN or L == len(st) - 1:
                continue                         # future report (research file), stale, or leaving: as built
            if s["dep_delay"] is None and float(s["actual_dep_abs"]) < t0 and not gap:
                s["actual_dep_abs"] = t0 + eps; n += 1
            start = L + 1
        else:
            if float(st[0]["actual_arr_abs"]) >= t0 or t0 - float(st[0]["actual_arr_abs"]) > STALE_MIN:
                continue
            start = 0
        nxt = next((k for k in range(start, len(st)) if st[k]["is_target"]), len(st))
        for k in range(nxt, len(st)):
            for key in ("actual_arr_abs", "actual_dep_abs"):
                if float(st[k][key]) < t0:
                    st[k][key] = t0 + eps; n += 1
        for k in range(1, len(st)):              # same monotonic rule as the builder
            st[k]["actual_arr_abs"] = max(st[k]["actual_arr_abs"], st[k - 1]["actual_dep_abs"])
            st[k]["actual_dep_abs"] = max(st[k]["actual_dep_abs"], st[k]["actual_arr_abs"])
    return n


class V18Forecaster:
    def __init__(self, checkpoint: Path = MODEL / "checkpoints" / "MNID_s4_practice.pt",
                 journeys: Path = S.JOURNEYS_DIR, habit_journeys: Path = S.JOURNEYS_DIR):
        topo = json.loads(Path(S.PROD_TOPOLOGY).read_text(encoding="utf-8"))
        BD._init_topology(topo)
        ck = torch.load(checkpoint, map_location="cpu", weights_only=False)
        self.model = CorridorNextEventGNN(**ck["config"])
        BD.HONEST_STANDING_DELAY = bool(ck.get("honest_standing_delay", False))
        BD.CLOCK_ETAS = bool(ck.get("clock_etas", False))
        load_weights(self.model, ck["model"])
        self.model.eval()
        self.dep_mode = ck.get("dep_mode", "absolute")
        match_checkpoint_features(ck["config"])
        self.ds = CrisDataset(str(S.DATASET_DIR), str(S.PROD_TOPOLOGY), lazy=True, verbose=False)
        self.ds.compute_labels = False
        check_feature_dims(ck["config"], self.ds)
        pairs = {(int(s["from_id"]), int(s["to_id"])) for s in BD._SECTIONS.values()}
        self.freight, self.disrupt, self.detent = FreightStore.load(), EventStore.load(pairs), _NoDetention()
        TL.RUN_ID_FIX = True
        self.journeys = Path(journeys)
        self.recipe = Recipe(MODEL / "recipe", habit_journeys, self.journeys)
        self.weights = Path(checkpoint).name

    def _iso(self, t_abs: float) -> str:
        x = dt.datetime.fromisoformat(ORIGIN) + dt.timedelta(minutes=float(t_abs))
        return x.replace(microsecond=0).isoformat() + TZ

    def forecast(self, date: str, minute: int, match_eval: bool = False, live: bool = True,
                 only_stops: set | None = None, exempt: set | None = None) -> dict:
        """One forecast at `date` + `minute` (minutes after midnight, multiple of 3).
        match_eval=True keeps only the forecasts the official evaluation scored (stations with a real arrival,
        scored train types); verify.py uses it. Production leaves it False.
        live=True applies hold_unknown_until_now (needed for live records, no effect on research files)."""
        t_start = time.time()
        d_obj = dt.date.fromisoformat(date)              # ValueError on a bad date
        if not 0 <= int(minute) < 1440:
            raise ValueError(f"minute must be 0..1439, got {minute}")
        requested = int(minute)
        minute = requested - requested % BD.TICK_MIN     # the model sees the corridor every 3 minutes
        model, ds = self.model, self.ds
        problems = check_journey_folder(self.journeys, date)
        by_date = BD._load_journeys(self.journeys)
        self.recipe.load_runs(self.journeys)             # runs change through the day in production
        di = TL.day_number(date, ORIGIN)
        day_meta = {"day_of_week": d_obj.weekday()}

        # the world: every run whose corridor time touches this day (plus 4 h), whatever its own date
        pool = []
        for k in (-2, -1, 0, 1):
            pool += TL.build_own(BD, by_date, (d_obj + dt.timedelta(days=k)).isoformat(), ORIGIN)
        lo = di * 1440
        pool = [copy.deepcopy(i) for i in TL.overlapping(pool, lo - R.MIDNIGHT_WARM_MIN, lo + 1440 + R.HORIZON_MIN)]
        for inst in pool:
            inst["detention"] = self.detent.get(inst["train_no"], inst.get("journey_date") or inst["corridor_date"]) or {}
        n_held = hold_unknown_until_now(pool, lo + minute, exempt) if live else 0
        instances = TL.overlapping(pool, lo, lo + 1440 + R.HORIZON_MIN)
        warm = TL.overlapping(pool, lo - R.MIDNIGHT_WARM_MIN, lo)
        truth = {i["instance_id"]: i for i in instances}
        routes = {i["instance_id"]: i["route"] for i in instances}

        # replay: previous evening (station state only), then 00:00 .. forecast moment (memory too)
        st_state, prev_delay = BD._StationState(), {}
        model.reset_memory()
        prev_date = (d_obj - dt.timedelta(days=1)).isoformat()
        prev_meta = {"day_of_week": (d_obj - dt.timedelta(days=1)).weekday()}
        for m in BD.SNAPSHOT_SCHEDULE:
            if m >= 1440 - R.MIDNIGHT_WARM_MIN:
                BD.build_snapshot(di - 1, (di - 1) * 1440 + m, warm, st_state, prev_meta,
                                  prev_delay, self.freight, self.disrupt, prev_date)
        for m in BD.SNAPSHOT_SCHEDULE:
            if m == minute:
                break
            snap = BD.build_snapshot(di, lo + m, instances, st_state, day_meta, prev_delay,
                                     self.freight, self.disrupt, date)
            if not snap["train_nodes"]:
                continue
            data = ds.materialise(snap, truth, routes)
            if data is None or data["train"].x.numel() == 0:
                continue
            with torch.no_grad():
                model(data, update_memory=True)

        t0 = lo + minute
        # each train's delay at the forecast moment (the picture is built on copies: no side effects)
        snap0 = BD.build_snapshot(di, t0, copy.deepcopy(instances), R._state_copy(st_state), day_meta,
                                  dict(prev_delay), self.freight, self.disrupt, date)
        delay_now = {n["instance_id"]: float(n["delay_min"]) for n in snap0["train_nodes"]}

        # play 4 hours forward
        ro = R.Rollout(model, ds, di, date, day_meta, self.freight, self.disrupt, truth, None, self.dep_mode,
                       hurdle_tau=1.0, entry_mode="actual", dep_head="model", standing_dep="booked",
                       hold_rule=None, predictor=None, revise=False, revise_min=0.0, expected_hold=False,
                       sample_seed=None, rules=None)
        ro.bcal, ro.first_date, ro.inject, ro.inject_floor, ro.hold_mod = None, ORIGIN, None, False, None
        world = copy.deepcopy(instances)
        ro.run(t0, world, R._state_copy(st_state), dict(prev_delay))

        # read the forecast world
        cut = t0 + R.HORIZON_MIN + 5000          # unwritten stops sit at t0 + horizon + 10000
        trains = []
        for inst in world:
            iid = inst["instance_id"]
            real = truth[iid]
            pos = BD._find_position(real, t0)
            if pos is None:
                if t0 >= real["stops"][0]["actual_arr_abs"]:
                    continue                      # already left the corridor
                k0, running = 0, False            # not entered yet: enters at its first stop (see README)
            else:
                k0, running = pos["stop_idx"], True
            rows = []
            for k in range(k0 + 1, len(inst["stops"])):
                s = inst["stops"][k]
                if float(s["actual_arr_abs"]) >= cut:
                    break
                if not s["is_target"]:
                    continue                      # block posts are never forecast targets
                if only_stops is not None and (iid, k) not in only_stops:
                    continue                      # verify.py: same stations as the official file
                if match_eval:
                    rs = real["stops"][k]
                    if not (rs["has_actual"] and rs["arr_delay"] is not None):
                        continue
                rows.append({"k": k, "station": s["station_code"], "raw": float(s["arr_delay"]),
                             "lead": float(s["actual_arr_abs"]) - t0,
                             "booked_abs": float(s["sched_arr_abs"])})
            if not rows:
                continue
            ttype = real.get("train_type", "")
            correct = running and real["target_eligible"] and ttype.upper() in SCORED_TYPES
            if match_eval and not (real["target_eligible"] and ttype.upper() in SCORED_TYPES):
                continue
            if correct:
                rows = self.recipe.apply(iid, ttype, delay_now[iid], rows, minute)
            else:
                rows = [{**r, "blended": None, "final": r["raw"]} for r in rows]
            trains.append({
                "run_id": iid, "train_no": real["train_no"], "train_type": ttype,
                "direction": real["direction"], "on_corridor_at_moment": running,
                "delay_now_min": round(delay_now[iid], 2) if iid in delay_now else None,
                "correction_applied": correct,
                "stops": [{"stop_index": r["k"], "station": r["station"],
                           "booked_arrival": self._iso(r["booked_abs"]),
                           "forecast_arrival": self._iso(r["booked_abs"] + r["final"]),
                           "forecast_delay_min": round(r["final"], 2),
                           "model_delay_min": round(r["raw"], 2),
                           "minutes_ahead": round(r["lead"], 1)} for r in rows],
            })
        trains.sort(key=lambda x: x["run_id"])
        return {"model": "cris-v18", "weights": self.weights, "package_version": PACKAGE_VERSION,
                "requested_moment": self._iso(lo + requested),
                "forecast_moment": self._iso(t0), "horizon_min": R.HORIZON_MIN,
                "input_warnings": problems,
                "correction_table": self.recipe.table_for(minute),
                "unreported_times_held_at_moment": n_held,
                "runtime_s": round(time.time() - t_start, 1),
                "n_trains": len(trains), "n_forecasts": sum(len(t["stops"]) for t in trains),
                "trains": trains}


def main() -> int:
    ap = argparse.ArgumentParser(description="cris-v18 forecast for one moment")
    ap.add_argument("--date", required=True, help="YYYY-MM-DD")
    ap.add_argument("--time", required=True, help="HH:MM (rounded down to the model's 3-minute step)")
    ap.add_argument("--journeys", default=str(S.JOURNEYS_DIR), help="folder of journey files (default: September 2025)")
    ap.add_argument("--out", default="forecast.json", help="output file, or - for stdout")
    a = ap.parse_args()
    try:
        hh, mm = (int(x) for x in a.time.split(":"))
        if not (0 <= hh < 24 and 0 <= mm < 60):
            raise ValueError
    except ValueError:
        print(f"ERROR: --time must be HH:MM, got {a.time!r}", file=sys.stderr)
        return 2
    import contextlib
    try:
        with contextlib.redirect_stdout(sys.stderr):    # the frozen code prints progress notes; keep stdout clean
            f = V18Forecaster(journeys=Path(a.journeys))
            res = f.forecast(a.date, hh * 60 + mm)
    except (FileNotFoundError, ValueError) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2
    text = json.dumps(res, indent=1)
    if a.out == "-":
        print(text)
    else:
        tmp = Path(a.out).with_suffix(".tmp")
        tmp.write_text(text, encoding="utf-8")
        tmp.replace(a.out)                               # readers never see a half-written file
    for w in res["input_warnings"]:
        print(f"WARNING: {w}", file=sys.stderr)
    print(f"{res['forecast_moment']}: {res['n_trains']} trains, {res['n_forecasts']} station forecasts, "
          f"{res['runtime_s']} s -> {a.out}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
