# -*- coding: utf-8 -*-
"""
serving/verify.py -- prove this package reproduces the official cris-v18 forecasts.

    python serving/verify.py            # 5 moments on the test days (about 1-2 min each on a laptop CPU)
    python serving/verify.py --quick    # 1 moment

For each moment it runs serving/forecast.py and compares, station by station, with the files the release was
scored from (model/reference/, copied from releases/cris-v18/eval/forecasts/):
  raw model forecast        vs testday_MNID_s4.json / testnight_MNID_s4.json
  final (after correction)  vs holdload_MNIDs4dayT.json / holdload_MNIDs4nightT.json
PASS = the same set of (train, station) forecasts and every value within 0.006 min (values are written rounded to 0.01).
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

SERVING = Path(__file__).resolve().parent
sys.path.insert(0, str(SERVING))
from forecast import V18Forecaster, ORIGIN  # noqa: E402
from cris_pipeline.v14 import timeline as TL  # noqa: E402

REF = SERVING.parent / "reference"
MOMENTS = [("2025-09-26", "05:00"), ("2025-09-28", "12:00"), ("2025-09-30", "18:30"),
           ("2025-09-27", "04:30"), ("2025-09-29", "22:00")]
TOL = 0.006          # forecasts are written rounded to 0.01 min


def load(name):
    out = {}
    for r in json.loads((REF / name).read_text(encoding="utf-8")):
        if r.get("already_running"):
            out[(r["iid"], r["stop_k"], int(round(r["t0"])))] = float(r["pred"])
    return out


LIVE_MOMENTS = [("2025-09-28", "12:00"), ("2025-09-27", "04:30")]


def strip_future(src: Path, dst: Path, date: str, minute: int, keep_entry: bool) -> None:
    """Copy the journey files around `date`, deleting every real time after the forecast moment -- what a live
    record looks like (the train standing at a platform has an arrival but no departure yet).
    keep_entry=True keeps the first corridor stop of trains that have not entered yet: the release was scored
    with their TRUE entry ("entry grant", README), so only then can the result match the official file."""
    import datetime as dt
    d0 = dt.date.fromisoformat(date)
    keep = {(d0 + dt.timedelta(days=k)).isoformat() for k in (-2, -1, 0, 1)}
    for f in src.glob("*/*.json"):
        if f.name[:10] not in keep:
            continue
        r = json.loads(f.read_text(encoding="utf-8"))
        t0_rel = minute + 1440 * TL.day_number(date, r["corridor_date"])
        times = [x for s in r["stops"] for x in (s.get("actual_arr_min"), s.get("actual_dep_min")) if x is not None]
        entered = any(x <= t0_rel for x in times)
        for i, s in enumerate(r["stops"]):
            if keep_entry and not entered and i == 0:
                continue
            for a, dl in (("actual_arr_min", "arr_delay_min"), ("actual_dep_min", "dep_delay_min")):
                if s.get(a) is not None and s[a] > t0_rel:
                    s[a], s[dl] = None, None
            s["has_actual"] = s.get("actual_arr_min") is not None      # = a real ARRIVAL (origin stops have only a departure)
        (dst / f.parent.name).mkdir(parents=True, exist_ok=True)
        (dst / f.parent.name / f.name).write_text(json.dumps(r), encoding="utf-8")


def recording_gaps(src: Path, date: str, minute: int) -> set:
    """Runs whose last report before the moment is an arrival whose departure was NEVER recorded, although a
    later stop did report (a gap in the record, not a train still standing). See hold_unknown_until_now."""
    import datetime as dt
    d0 = dt.date.fromisoformat(date)
    keep = {(d0 + dt.timedelta(days=k)).isoformat() for k in (-2, -1, 0, 1)}
    out = set()
    for f in src.glob("*/*.json"):
        if f.name[:10] not in keep:
            continue
        r = json.loads(f.read_text(encoding="utf-8"))
        t0_rel = minute + 1440 * TL.day_number(date, r["corridor_date"])
        st = r["stops"]
        past = [i for i, s in enumerate(st) if any(s.get(a) is not None and s[a] <= t0_rel
                                                   for a in ("actual_arr_min", "actual_dep_min"))]
        if not past:
            continue
        L = past[-1]
        if st[L].get("actual_dep_min") is None and any(s.get("actual_arr_min") is not None for s in st[L + 1:]):
            out.add(f"{r['train_no']}_{f.stem}")
    return out


def compare(f, raw, fin, date, hhmm, label, **kw):
    hh, mm = (int(x) for x in hhmm.split(":"))
    minute = hh * 60 + mm
    t0 = TL.day_number(date, ORIGIN) * 1440 + minute
    w = f.recipe.table_for(minute)
    want_raw = {k: v for k, v in raw[w].items() if k[2] == t0}
    want_fin = {k: v for k, v in fin[w].items() if k[2] == t0}
    if kw.pop("official_stops", False):
        kw["only_stops"] = {(k[0], k[1]) for k in want_fin}
    res = f.forecast(date, minute, **kw)
    got_raw, got_fin = {}, {}
    for t in res["trains"]:
        if not t["on_corridor_at_moment"]:
            continue                     # the release scores trains already on the corridor
        for s in t["stops"]:
            key = (t["run_id"], s["stop_index"], t0)
            got_raw[key], got_fin[key] = s["model_delay_min"], s["forecast_delay_min"]
    same_keys = set(got_fin) == set(want_fin) and set(got_raw) == set(want_raw)
    d_raw = max((abs(got_raw[k] - want_raw[k]) for k in want_raw if k in got_raw), default=float("nan"))
    d_fin = max((abs(got_fin[k] - want_fin[k]) for k in want_fin if k in got_fin), default=float("nan"))
    ok = bool(want_fin) and same_keys and d_raw <= TOL and d_fin <= TOL
    print(f"{label} {date} {hhmm} [{w:5}] forecasts {len(got_fin):4d} (official {len(want_fin):4d})  "
          f"max diff raw {d_raw:.4f}  final {d_fin:.4f}  {res['runtime_s']:6.1f} s  {'PASS' if ok else 'FAIL'}",
          flush=True)
    return ok


def main() -> None:
    import tempfile
    from cris_pipeline.v14 import settings as S
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    a = ap.parse_args()
    moments = MOMENTS[:1] if a.quick else MOMENTS
    live_moments = LIVE_MOMENTS[:1] if a.quick else LIVE_MOMENTS
    raw = {"day": load("testday_MNID_s4.json"), "night": load("testnight_MNID_s4.json")}
    fin = {"day": load("holdload_MNIDs4dayT.json"), "night": load("holdload_MNIDs4nightT.json")}
    ok_all = True

    print("A. complete September files (as the release was scored)")
    f = V18Forecaster()
    for date, hhmm in moments:
        ok_all &= compare(f, raw, fin, date, hhmm, "  ", match_eval=True)

    print("\nB. live-like files: every real time after the forecast moment deleted (entry of trains not yet on the"
          "\n   corridor kept, as the release was scored)")
    for date, hhmm in live_moments:
        hh, mm = (int(x) for x in hhmm.split(":"))
        with tempfile.TemporaryDirectory() as tmp:
            strip_future(Path(S.JOURNEYS_DIR), Path(tmp), date, hh * 60 + mm, keep_entry=True)
            fl = V18Forecaster(journeys=Path(tmp))
            gaps = recording_gaps(Path(S.JOURNEYS_DIR), date, hh * 60 + mm)
            if gaps:
                print(f"     recording gap (departure never reported), left as the release built it: {sorted(gaps)}")
            ok_all &= compare(fl, raw, fin, date, hhmm, "  ", official_stops=True, exempt=gaps)

    print("\nALL PASS: this package reproduces the official cris-v18 forecasts, also from live-like records."
          if ok_all else "\nFAILED")

    if not a.quick:
        print("\nC. information only: the same, but the future entry of trains not yet on the corridor deleted too"
              "\n   (what production really has). Shows what the release's entry grant is worth; not a pass/fail test.")
        for date, hhmm in live_moments:
            hh, mm = (int(x) for x in hhmm.split(":"))
            minute = hh * 60 + mm
            t0 = TL.day_number(date, ORIGIN) * 1440 + minute
            with tempfile.TemporaryDirectory() as tmp:
                strip_future(Path(S.JOURNEYS_DIR), Path(tmp), date, minute, keep_entry=False)
                fl = V18Forecaster(journeys=Path(tmp))
                w = fl.recipe.table_for(minute)
                want = {k: v for k, v in fin[w].items() if k[2] == t0}
                res = fl.forecast(date, minute, only_stops={(k[0], k[1]) for k in want},
                                  exempt=recording_gaps(Path(S.JOURNEYS_DIR), date, minute))
                got = {(t["run_id"], s["stop_index"], t0): s["forecast_delay_min"]
                       for t in res["trains"] if t["on_corridor_at_moment"] for s in t["stops"]}
                d = [abs(got[k] - want[k]) for k in want if k in got]
                same = sum(x <= TOL for x in d)
                print(f"   {date} {hhmm}: {same} of {len(d)} forecasts unchanged; mean change {sum(d)/max(len(d),1):.2f} min,"
                      f" largest {max(d, default=0):.1f} min")
    sys.exit(0 if ok_all else 1)


if __name__ == "__main__":
    main()
