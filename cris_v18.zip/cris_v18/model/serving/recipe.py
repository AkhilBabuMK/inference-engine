# -*- coding: utf-8 -*-
"""
serving/recipe.py -- the frozen v18 correction, APPLY ONLY.

v18's published forecasts are the model's raw rollout plus two fixed steps:

  1. behaviour blend (recipe/original/c24_blend.py)
       rebuild the forecast path stop by stop; each step =
           w[lead] * model step + (1 - w[lead]) * this train's usual change on that leg
       "usual change" = mean over the TRAINING days (corridor date < 2025-09-21), leaving the forecast's own
       date out, shrunk to the all-train mean of the leg with weight 3.
  2. hold-load (recipe/original/c21_holdload.py)
       add the median leftover error of the group (lead bucket x direction x train type x station), shrunk to the
       wider group with k = 80. The table was fitted on training-day forecasts only.

The original scripts re-fit both steps from files every time they run. This module does exactly the same
arithmetic with the frozen weights and tables (recipe/recipe.json, recipe/holdload_*_table.json), so nothing is
ever fitted in production. serving/verify.py proves the result equals the official v18 forecast files.

"How far ahead" is always measured from the FORECAST arrival (booked + forecast delay - now), never the real one.
"""
from __future__ import annotations

import collections
import json
import os
from pathlib import Path

import numpy as np

LB = (0, 30, 60, 90, 120, 180, 240)          # lead buckets, minutes
TRAIN_END = "2025-09-21"                     # habits come from corridor dates strictly before this


def bucket(lead: float) -> int:
    b = int(np.searchsorted(LB, max(lead, 0.0), side="right") - 1)
    return min(max(b, 0), len(LB) - 2)


def _journey_files(folder: Path):
    # same order as glob.glob on NTFS (names sorted), so a "<date>#2" file is read before "<date>"
    return sorted(Path(folder).glob("*/*.json"), key=lambda p: (p.parent.name, p.name.lower()))


class Recipe:
    def __init__(self, recipe_dir: Path, habit_journeys: Path, run_journeys: Path):
        recipe_dir = Path(recipe_dir)
        cfg = json.loads((recipe_dir / "recipe.json").read_text(encoding="utf-8"))
        self.w = [float(x) for x in cfg["blend_weights"]]
        self.night_minutes = cfg["night_window"]
        self.tables = {}
        for name, fn in cfg["holdload_tables"].items():
            t = json.loads((recipe_dir / fn).read_text(encoding="utf-8"))
            self.tables[name] = {"k": float(t["k"]),
                                 "levels": [{tuple(key.split("|")): (float(v[0]), int(v[1])) for key, v in L.items()}
                                            for L in t["levels"]]}
        # habits: training-day journeys only (identical construction to c24_blend.py)
        self.by_leg = collections.defaultdict(lambda: collections.defaultdict(list))
        legmean = collections.defaultdict(list)
        for f in _journey_files(habit_journeys):
            d = f.name[:10]
            if d >= TRAIN_END:
                continue
            r = json.loads(f.read_text(encoding="utf-8"))
            st = [s for s in r["stops"] if s["has_actual"] and s["arr_delay_min"] is not None]
            for a, b in zip(st, st[1:]):
                inc = b["arr_delay_min"] - a["arr_delay_min"]
                self.by_leg[(r["train_no"], a["station_code"], b["station_code"])][d].append(inc)
                legmean[(a["station_code"], b["station_code"])].append(inc)
        self.LM = {k: float(np.mean(v)) for k, v in legmean.items()}
        self.load_runs(run_journeys)

    def load_runs(self, run_journeys: Path) -> None:
        """Station lists and directions of the runs being forecast (c24 'ST', c21 'DIR')."""
        self.ST, self.DIR = {}, {}
        for f in _journey_files(run_journeys):
            try:
                r = json.loads(f.read_text(encoding="utf-8"))
                r["stops"], r["train_no"]
            except Exception:
                continue                  # unreadable file: the forecast reports it (input_warnings)
            d = f.name[:10]
            self.ST[(r["train_no"], d)] = [s["station_code"] for s in r["stops"]]
            self.DIR[f'{r["train_no"]}_{d}'] = r.get("direction", "?")

    def table_for(self, minute_of_day: int) -> str:
        lo, hi = self.night_minutes
        return "night" if (minute_of_day < lo or minute_of_day >= hi) else "day"

    def _prior_leg(self, tn, a, b, day):
        base = self.LM.get((a, b), 0.0)
        v = [x for dd, L in self.by_leg.get((tn, a, b), {}).items() if dd != day for x in L]
        return (sum(v) + 3.0 * base) / (len(v) + 3.0)

    def _prior(self, tn, cd, k0, k1):
        stl = self.ST.get((tn, cd))
        if not stl:
            return None
        return sum(self._prior_leg(tn, stl[i], stl[i + 1], cd) for i in range(k0, k1))

    def apply(self, run_id: str, train_type: str, delay_now: float, rows: list, minute_of_day: int) -> list:
        """rows: [{"k": stop index, "station": code, "raw": forecast delay, "lead": forecast arrival - now}]
        in stop order, one train, one forecast moment. Returns the same rows with "blended" and "final"."""
        tn, cd = run_id.split("_", 1)
        T = self.tables[self.table_for(minute_of_day)]
        lv, k = T["levels"], T["k"]
        dirn = self.DIR.get(run_id, "?")
        cum, prev, out = delay_now, None, []
        for r in rows:
            if prev is None:
                pinc = r["raw"] - delay_now
                pr = self._prior(tn, cd, r["k"] - 1, r["k"]) if r["k"] >= 1 else None
            else:
                pinc = r["raw"] - prev["raw"]
                pr = self._prior(tn, cd, prev["k"], r["k"])
            wb = self.w[bucket(r["lead"])]
            cum += wb * pinc + (1 - wb) * (pinc if pr is None else pr)
            # hold-load, bucketed on the BLENDED forecast arrival
            b2 = str(bucket(r["lead"] - r["raw"] + cum))
            v0 = lv[0].get((b2,), (0.0, 0))[0]
            m1, n1 = lv[1].get((b2, dirn, train_type), (v0, 0)); v1 = (n1 * m1 + k * v0) / (n1 + k)
            m2, n2 = lv[2].get((b2, dirn, train_type, r["station"]), (v1, 0)); v2 = (n2 * m2 + k * v1) / (n2 + k)
            out.append({**r, "blended": cum, "final": cum + v2})
            prev = r
        return out
