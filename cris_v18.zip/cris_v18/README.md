# cris-v18 forecast package

Train arrival-delay forecasts for the Jabalpur (JBP) - Satna (STA) corridor, 22 stations, up to 4 hours ahead,
for every train on or entering the corridor. This is release **cris-v18** (git tag `cris-v18`), frozen,
packaged to run on any machine, with a check that proves it gives the same numbers as the official release.

```
python model/serving/verify.py          # first: proves this copy reproduces the official v18 forecasts (~3 min)
python model/serving/forecast.py --date 2025-09-28 --time 12:00 --out forecast.json
```

## 1. Install

Python 3.14 (64-bit), CPU only (no GPU needed), about 1-2 GB of disk for the libraries. From the package folder:

```
python -m venv .venv
.venv\Scripts\activate                      (Linux/macOS: source .venv/bin/activate)
pip install torch==2.11.0 --index-url https://download.pytorch.org/whl/cpu
pip install -r requirements.txt
python model/serving/verify.py
```

`verify.py` must end with `ALL PASS`. If it does not, do not use the forecasts: the libraries differ from the ones
v18 was released with (see `requirements.txt`).

## 2. What it does, with one train

At 12:00 on 28 Sep 2025, express train 11071 is heading for Satna, 55 minutes late, 4 minutes before PKRD.
`forecast.py`:

1. reads the journey files (every train's stops: booked times, and real times reported so far);
2. replays the day from 00:00 to 12:00, one picture of the corridor every 3 minutes, so the model's memory of the
   day is exactly what it was in training;
3. plays **all** trains 4 hours forward together, so a train waiting for another one ahead is part of the forecast;
4. applies the frozen v18 correction (each train's usual behaviour on each leg, and the typical leftover error of
   its group);
5. writes, for 11071 and every other train, a forecast arrival at each station it reaches in the next 4 hours.

Real output for 11071 (`python model/serving/forecast.py --date 2025-09-28 --time 12:00`):

```
station  booked  forecast  delay (min)   model alone
PKRD     11:09   12:04     55.5          55.4
UDR      11:15   12:11     56.2          56.1
BUU      11:23   12:20     57.9          57.2
MYR      11:33   12:33     60.9          58.6
UHR      11:46   12:47     61.1          59.2
LGCE     11:52   12:52     60.4          59.7
```

## 3. Accuracy (official release numbers, `releases/cris-v18/README.md`)

Average error of the forecast arrival delay, trains already running at the forecast moment, express and
passenger types SUF / MEX / VNDB / DRNT, test days 26-30 Sep 2025 (never used in training or tuning), this exact
model (seed 4):

| window | average error |
|---|---|
| daytime 05:00-19:00 | **8.87 min** |
| night 21:00-04:30 | **8.53 min** (0-30 min ahead 3.31, 30-60 min 6.23, 1-2 h 9.44, 2-4 h 15.98) |

**These numbers are optimistic for live use** (section 7, entry grant).

## 4. The data inside

All September 2025 (1-30 Sep), official CRIS data:

* **Corridor stops (the 22 stations)**: the two official CRIS ground-truth workbooks,
  `JBP_STA_TRAIN_FULL_RUNNING.xlsx` and `FULL RUNNING ... KTE_BINA_BSP_SGRL` (two halves of one dataset, split at
  Katni). They were converted to CSV and verified (8 checks; seconds kept) before use.
* **Before the corridor** (where each train was and how late, on its way in: the `entry` block of each journey):
  the CRIS running export, because the workbooks cover the corridor only.
* Merged into one journey file per train run: `model/data_v14/journeys/<train>/<corridor date>.json`
  (2,605 runs, 302 trains, every file marked `"data_source": "ground_truth+CRIS"`).
* Goods trains and maintenance blocks: corridor ontology build `20260929T082110Z`
  (`corridor_ontology/objects/...`); temporary speed restrictions and maintenance blocks from the CRIS cleaned
  tables (`model/data_standardized_timestamp_all/...`).
* Corridor layout and train list: `jabalpur_scenario_gnn/data_cris/topology_jbp_sta_cris.json`.

The folder names `jabalpur_scenario_gnn/` and `corridor_ontology/` are kept because the frozen code finds its files
by those relative paths. Nothing in the package reads outside it (checked by recording every file opened).

## 5. Folder layout

```
cris_v18/
  README.md  requirements.txt  MANIFEST.sha256 (sha256 of every file)  BUILD_INFO.json
  model/
    cris_pipeline/            frozen release code, unmodified (releases/cris-v18/code_at_freeze)
    scenario_events.py        frozen release code
    checkpoints/MNID_s4_practice.pt      the v18 weights
    recipe/recipe.json        frozen correction weights + day/night rule
    recipe/holdload_*_table.json         frozen correction tables (day, night)
    recipe/original/          the two release scripts the correction comes from (reference only, not run)
    serving/forecast.py       one forecast (command line, or V18Forecaster in Python)
    serving/recipe.py         the correction, apply only (never re-fitted)
    serving/verify.py         the reproduction check
    serving/validate_journeys.py         checks journey files before forecasting
    data_v14/journeys/        September journey files (input; also the correction's history)
    data_v14/dataset/         29 one-line files naming each day's split (the code asks for them)
    data_v14/baselines.json   per-train reference values the model reads
    data_standardized_timestamp_all/...  speed restrictions, maintenance blocks
    reference/                the official v18 forecast files verify.py compares against
  jabalpur_scenario_gnn/data_cris/topology_jbp_sta_cris.json
  corridor_ontology/objects/20260929T082110Z/   goods trains, disruptions, sections
```

## 6. Using it

**Command line**

```
python model/serving/forecast.py --date YYYY-MM-DD --time HH:MM [--journeys FOLDER] [--out FILE | --out -]
```

* `--time` is rounded down to the model's 3-minute step (12:02 -> 12:00; both are in the output).
* `--journeys` defaults to the September files. For live use, point it at a folder in the same format (section 8).
* Exit code 0 = forecast written; 2 = bad input (message on stderr). Warnings go to stderr and into the JSON.
* The output file is written whole or not at all (written to `.tmp`, then renamed).
* One forecast takes 7-35 s on a laptop CPU (longer late in the day: the day is replayed from 00:00).

**Python**

```python
import sys
from pathlib import Path
sys.path.insert(0, "model/serving")
from forecast import V18Forecaster
f = V18Forecaster(journeys=Path("live_journeys"))      # load once (a few seconds)
result = f.forecast("2025-09-28", 12 * 60)              # then call every 3 minutes
```

The journey folder is re-read on every call, so new reports are picked up without restarting.

**Output** (`forecast.json`)

```
model, weights, package_version, requested_moment, forecast_moment, horizon_min (240),
correction_table ("day" / "night"), input_warnings [..], unreported_times_held_at_moment, runtime_s,
n_trains, n_forecasts,
trains: [ { run_id ("12189_2025-09-28"), train_no, train_type, direction (UP/DN),
            on_corridor_at_moment, delay_now_min, correction_applied,
            stops: [ { stop_index, station, booked_arrival, forecast_arrival, forecast_delay_min,
                       model_delay_min (before the correction), minutes_ahead } ] } ]
```

Times are ISO 8601 with `+05:30`. `forecast_delay_min` is the number to use. The correction is applied to trains on
the corridor of types SUF / MEX / VNDB / DRNT (the ones it was fitted and tested on); for all others
`forecast_delay_min` is the model's own forecast. Block posts (GNWA, MDRR, SNRR) are never forecast targets.

## 7. Read before relying on it

1. **Entry grant.** The official numbers were measured giving trains *not yet on the corridor* their true entry
   time. Live data cannot know it. Here such a train enters at its estimated time (its delay on the way in), never
   before the forecast moment. `verify.py` part C measures how much this moves the forecasts of trains already on the
   corridor: 28 Sep 12:00 on average 0.22 min (largest 1.1); 27 Sep 04:30 on average 2.29 min (largest 28.7), when
   many trains enter at night. The official numbers above do not include this.
2. **The one adaptation for live records.** The frozen code was only ever run on complete days. With live records a
   train standing at a platform has an arrival but no departure yet; the frozen code would estimate a departure and
   could show it as already gone. `forecast.py` keeps it standing until its next report (and places nothing after
   the last report before the forecast moment), unless the last report is older than 190 min. On complete September
   files this changes nothing (part A); on September files cut at the forecast moment it reproduces the release
   (part B). **Known difference:** 0.1-0.3% of arrivals never get a departure report (a recording gap). The release
   let such a train leave on schedule; this package keeps it standing until its next station reports. `verify.py`
   lists these trains and checks everything else.
3. **Day/night correction.** The night table is used for 21:00-05:00 and the day table otherwise. 19:00-21:00 was
   never tested by the release; it uses the day table.
4. **Goods trains, maintenance blocks, speed restrictions** are read from the September files inside the package.
   v18 treats them as known in advance. For live use they need live feeds in the same format; until then forecasts
   outside September run without them.
5. **Unknown trains.** A train missing from the topology (v18 never saw it) gets a generic identity. One case in the
   September data: A17409 (it reads another train's identity row, exactly as in the release run).
   `validate_journeys.py` warns about every such train.
6. **Holds** (a train waiting for another) are forecast on average, not case by case.

## 8. Live input: journey files

Producing journey files from the live feed (e.g. Redis) is **not part of this package**. The format:
`<folder>/<train_no>/<corridor_date>.json` (second run on the same date: `<corridor_date>#2.json`), one file per
train run, fields as in the September files. Times are minutes after 00:00 of `corridor_date`; a time not
reported yet is `null`; `arr_delay_min = actual_arr_min - sched_arr_min`; `has_actual` = arrival reported.

```
python model/serving/validate_journeys.py live_journeys --date 2025-09-28
```

checks every rule (all 2,605 September files pass with 0 errors). Exit code 1 = errors. The forecast also reports
files it had to skip. Keep the folder to the last few days: it is read whole on every forecast.

Required in the folder for a forecast on day D: files for D (else exit code 2) and D-1 (else a warning: trains that
entered before midnight are missing).

## 9. How this package was checked

`python model/serving/verify.py`. Result on the built package, unzipped into an empty folder, with every file
opened recorded (0 outside the package); `MANIFEST.sha256` checked first:

```
A. 2025-09-26 05:00 day    120 / 120 forecasts   max diff 0.005   PASS
   2025-09-28 12:00 day     71 /  71             0.005            PASS
   2025-09-30 18:30 day     99 /  99             0.005            PASS
   2025-09-27 04:30 night   88 /  88             0.005            PASS
   2025-09-29 22:00 night   84 /  84             0.005            PASS
B. 2025-09-28 12:00 day     71 /  71             0.005            PASS
   2025-09-27 04:30 night   88 /  88             0.005            PASS   (recording gap: 11273_2025-09-27)
C. 12:00 mean change 0.22 min (largest 1.1); 04:30 mean change 2.29 min (largest 28.7)   information only
```

What was checked:

* **A.** Five test-day moments (05:00, 12:00, 18:30 day; 04:30, 22:00 night) on the complete September files:
  every forecast equals the official v18 file (`reference/`), before and after the correction, within 0.005 min
  (the files store 2 decimals).
* **B.** The same at 12:00 and 04:30 with every real time after the forecast moment deleted (what a live record
  looks like): equal again.
* **C.** Information only: the cost of the entry grant (section 7.1).

Built from git tag `cris-v18` by `jabalpur_scenario_gnn_v14/deploy/cris_v18_package/build_package.py`.
